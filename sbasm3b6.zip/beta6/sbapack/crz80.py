#------------------------------------------------------------------------------
#
#   crz80.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   Cross Overlay for the Z80 family of processors
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags

    assem.CheckVersions(crossversion, minversion)
    
    dec.Asm.Instructions = {
        'CCF' : (Inherent,int('3F',16),'4'),
        'CPL' : (Inherent,int('2F',16),'4'),
        'DAA' : (Inherent,int('27',16),'4'),
        'DI'  : (Inherent,int('F3',16),'4'),
        'EI'  : (Inherent,int('FB',16),'4'),
        'EXX' : (Inherent,int('D9',16),'4'),
        'HALT': (Inherent,int('76',16),'4'),
        'NOP' : (Inherent,int('00',16),'4'),
        'RLA' : (Inherent,int('17',16),'4'),
        'RLCA': (Inherent,int('07',16),'4'),
        'RRA' : (Inherent,int('1F',16),'4'),
        'RRCA': (Inherent,int('0F',16),'4'),
        'SCF' : (Inherent,int('37',16),'4'),
        'CPD' : (Inherent,int('EDA9',16),'16'),
        'CPDR': (Inherent,int('EDB9',16),'16+'),
        'CPI' : (Inherent,int('EDA1',16),'16'),
        'CPIR': (Inherent,int('EDB1',16),'16+'),
        'IND' : (Inherent,int('EDAA',16),'16'),
        'INDR': (Inherent,int('EDBA',16),'16+'),
        'INI' : (Inherent,int('EDA2',16),'16'),
        'INIR': (Inherent,int('EDB2',16),'16+'),
        'LDD' : (Inherent,int('EDA8',16),'16'),
        'LDDR': (Inherent,int('EDB8',16),'16+'),
        'LDI' : (Inherent,int('EDA0',16),'16'),
        'LDIR': (Inherent,int('EDB0',16),'16+'),
        'NEG' : (Inherent,int('ED44',16),'8'),
        'OTDR': (Inherent,int('EDBB',16),'16+'),
        'OTIR': (Inherent,int('EDB3',16),'16+'),
        'OUTD': (Inherent,int('EDAB',16),'16'),
        'OUTI': (Inherent,int('EDA3',16),'16'),
        'RCF' : (Inherent,int('373F',16),'8'),
        'RETI': (Inherent,int('ED4D',16),'14'),
        'RETN': (Inherent,int('ED45',16),'14'),
        'RLD' : (Inherent,int('ED6F',16),'18'),
        'RRD' : (Inherent,int('ED67',16),'18'),

        'LD'     : (Load,),
        'LD.A'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)','(BC)','(DE)','(M)','I','R'),('7F','78','79','7A','7B','7C','7D','7E','3E','DD7E','FD7E','0A','1A','3A','ED57','ED5F'),('4','4','4','4','4','4','4','7','7','19','19','7','7','13','9','9'),(0,0,0,0,0,0,0,0,1,1,1,0,0,2,0,0)),
        'LD.B'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('47','40','41','42','43','44','45','46','06','DD46','FD46'),('4','4','4','4','4','4','4','7','7','19','19'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.C'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('4F','48','49','4A','4B','4C','4D','4E','0E','DD4E','FD4E'),('4','4','4','4','4','4','4','7','7','19','19'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.D'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('57','50','51','52','53','54','55','56','16','DD56','FD56'),('4','4','4','4','4','4','4','7','7','19','19'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.E'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('5F','58','59','5A','5B','5C','5D','5E','1E','DD5E','FD5E'),('4','4','4','4','4','4','4','7','7','19','19'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.H'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('67','60','61','62','63','64','65','66','26','DD66','FD66'),('4','4','4','4','4','4','4','7','7','19','19'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.L'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('6F','68','69','6A','6B','6C','6D','6E','2E','DD6E','FD6E'),('4','4','4','4','4','4','4','7','7','19','19'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.I'   : (('A',),('ED47',),('9',),(0,)),
        'LD.R'   : (('A',),('ED4F',),('9',),(0,)),
        'LD.(HL)': (('#','A','B','C','D','E','H','L'),('36','77','70','71','72','73','74','75'),('10','7','7','7','7','7','7','7'),(1,0,0,0,0,0,0,0)),
        'LD.(IX)': (('#','A','B','C','D','E','H','L'),('DD36','DD77','DD70','DD71','DD72','DD73','DD74','DD75'),('19','19','19','19','19','19','19','19'),(4,3,3,3,3,3,3,3)),
        'LD.(IY)': (('#','A','B','C','D','E','H','L'),('FD36','FD77','FD70','FD71','FD72','FD73','FD74','FD75'),('19','19','19','19','19','19','19','19'),(4,3,3,3,3,3,3,3)),
        'LD.(BC)': (('A',),('02',),('7',),(0,)),
        'LD.(DE)': (('A',),('12',),('7',),(0,)),
        'LD.(M)' : (('A','BC','DE','HL','SP','IX','IY'),('32','ED43','ED53','22','ED73','DD22','FD22'),('13','20','20','20','20','20','20'),(5,5,5,5,5,5,5)),
        'LD.BC'  : (('#','(M)'),('01','ED4B'),('10','20'),(2,2)),
        'LD.DE'  : (('#','(M)'),('11','ED5B'),('10','20'),(2,2)),
        'LD.HL'  : (('#','(M)'),('21','2A'),('10','16'),(2,2)),
        'LD.SP'  : (('#','(M)','HL','IX','IY'),('31','ED7B','F9','DDF9','FDF9'),('10','20','6','10','10'),(2,2,0,0,0)),
        'LD.IX'  : (('#','(M)'),('DD21','DD2A'),('14','20'),(2,2)),
        'LD.IY'  : (('#','(M)'),('FD21','FD2A'),('14','20'),(2,2)),

        'POP' : (Stack, int('C1',16), ('10','14')),
        'PUSH': (Stack, int('C5',16), ('11','15')),
        
        'ADC' : (Math, ('88','DD8E','FD8E','CE','ED4A'), ('4/7','19','19','7','15')),
        'ADD' : (Math, ('80','DD86','FD86','C6','09','DD09','FD09'), ('4/7','19','19','7','11','15','15')),
        'AND' : (Math, ('A0','DDA6','FDA6','E6'), ('4/7','19','19','7')),
        'CP'  : (Math, ('B8','DDBE','FDBE','FE'), ('4/7','19','19','7')),
        'OR'  : (Math, ('B0','DDB6','FDB6','F6'), ('4/7','19','19','7')),
        'SBC' : (Math, ('98','DD9E','FD9E','DE','ED42'), ('4/7','19','19','7','15')),
        'SUB' : (Math, ('90','DD96','FD96','D6'), ('4/7','19','19','7')),
        'XOR' : (Math, ('A8','DDAE','FDAE','EE'), ('4/7','19','19','7')),
        
        'DEC' : (IncDec, ('05','35','DD35','FD35','0B','DD2B','FD2B'),('4','11','23','23','6','10','10')),
        'INC' : (IncDec, ('04','34','DD34','FD34','03','DD23','FD23'),('4','11','23','23','6','10','10')),

        'CALL': (Jumps, ('CD','C4'),('17','10+')),
        'JP'  : (Jumps, ('C3','C2','E9','DDE9','FDE9'),('10','10','4','8','8')),

        'JR'  : (Branch, ('18','38','30','28','20'),('12','7+','7+','7+','7+')),
        'DJNZ': (Branch, ('10',),('8+',)),

        'RET' : (Returns, ('C9','C0'),('10','5+')),

        'RLC' : (Singles, ('CB00','CB06','06'),('8','15','23')),
        'RL'  : (Singles, ('CB10','CB16','16'),('8','15','23')),
        'RRC' : (Singles, ('CB08','CB0E','0E'),('8','15','23')),
        'RR'  : (Singles, ('CB18','CB1E','1E'),('8','15','23')),
        'SLA' : (Singles, ('CB20','CB26','26'),('8','15','23')),
        'SRA' : (Singles, ('CB28','CB2E','2E'),('8','15','23')),
        'SRL' : (Singles, ('CB38','CB3E','3E'),('8','15','23')),
        'BIT' : (Bits, ('CB40','CB46','46'),('8','12','20')),
        'RES' : (Bits, ('CB80','CB86','86'),('8','15','23')),
        'SET' : (Bits, ('CBC0','CBC6','C6'),('8','15','23')),
        
        'IN'  : (InOut, ('ED40','DB'),('12','11')),
        'OUT' : (InOut, ('ED41','D3'),('12','11')),

        'EX'  : (Exch, ('EB','08','E3','DDE3','FDE3'),('4','4','19','23','23')),
        'IM'  : (IM, ('ED46','ED56','ED5E'),'8'),

        'RST' : (Restart,int('C7',16),'11')
        }

    dec.Asm.Memory = 0
    length = 0

    dec.Asm.Timing_Length = 3

    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = dec.MAX16
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = False
    
    return

#------------------------------------------------------------------------------

def CrossDirective():

    # This cross overlay has no extra/changed directives
    
    return False    # We didn't handle any directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    # This cross overlay does not need any clean up
    
    return

#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm

    if '.' in dec.Asm.Mnemonic:
        # Avoid mnemonics like LD.A from being accepted
        errors.DoError('badopco',False)
        return

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def MissingOperand():

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)

#-----------------------------------------------------------------------------

def Inherent():

    global Asm

    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1]
    Code (opcode)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

#-----------------------------------------------------------------------------

def Load():

    global Asm
    
    if MissingOperand():
        return

    reg1 = GetReg()
    
    if dec.Flags.ErrorInLine:
        # An error was found in parameter 1, no need to continue
        return
        
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    reg2 = GetReg()
    
    firstpar = 'LD.'+reg1[0]
    if firstpar in dec.Asm.Instructions:
        secpar = dec.Asm.Instructions[firstpar][0]
        opcode = dec.Asm.Instructions[firstpar][1]
        timing = dec.Asm.Instructions[firstpar][2]
        extra  = dec.Asm.Instructions[firstpar][3]
        
        index = 0
        for t in secpar:
            if t == reg2[0]:
                # Found 2nd parameter, now let's save it to the target file
                opc = int(opcode[index],16)
                Code(opc)
                dec.Asm.Timing = timing[index]
                if extra[index] == 1:
                    # save one extra byte from operand 2
                    target.CodeByte(reg2[1])
                elif extra[index] == 2:
                    # save two extra bytes from operand 2
                    target.CodeWord(reg2[1])
                elif extra[index] == 3:
                    # save one extra byte from operand 1
                    target.CodeByte(reg1[1])
                elif extra[index] == 4:
                    # save one extra byte from operand 1 and one from operand 2
                    target.CodeByte(reg1[1])
                    target.CodeByte(reg2[1])
                elif extra[index] == 5:
                    # save two extra bytes from operand 1
                    target.CodeWord(reg1[1])
                NoMore()
                return
            index = index + 1

        # This type of parameter was not allowed as second parameter
        errors.DoError('badoper',False)
    else:
        # This type of parameter was not allowed as first parameter
        errors.DoError('badoper',False)
    
#-----------------------------------------------------------------------------

def GetReg():

    """
    Possible parameters:
    Name:       Returns:
    A           ('A',7)
    B           ('B',0)
    C           ('C',1)
    D           ('D',2)
    E           ('E',3)
    H           ('H',4)
    L           ('L',5)
    (HL)        ('(HL)',6)
    Immediate   ('#',value) (value is already shifted)
    (IX+offs)   ('(IX)',offset)
    (IY+offs)   ('(IY)',offset)
    (BC)        ('(BC)',0)
    (DE)        ('(DE)',1)
    (memory)    ('(M)',address)
    I           ('I',0)
    R           ('R',0)
    BC          ('BC',0)
    DE          ('DE',1)
    HL          ('HL',2)
    SP          ('SP',3)
    IX          ('IX',2)
    IY          ('IY',2)
    (C)         ('(C)',0)
    error       ('!',0)
    """
        
    global Asm
    
    pointer = dec.Asm.Parse_Pointer
    param = assem.GetWord().upper()
    
    if len(param) == 0:
        errors.DoError('badoper',False)
        return ('!',0)
    
    if param[0] == '(':
        # It's a memory reference of some sort
        if param[1:3] in ('BC','DE','HL','IX','IY'):
            # It's an index register pair
            if param == '(HL)':
                return (param,6)
            elif param == '(BC)':
                return (param,0)
            elif param == '(DE)':
                return (param,1)
            else:
                # It's (IX+offs) or (IY+offs) now
                index = param[0:3] + ')'
                dec.Asm.Parse_Pointer = pointer + 3
                if assem.NowChar() in '+-':
                    offset = assem.EvalExpr()[0]
                    if assem.NowChar(True) != ')':
                        errors.DoError('badoper',False)
                else:
                    offset = 0
                    if assem.NowChar(True) != ')':
                        errors.DoError('badoper',False)
                if dec.Asm.Pass == 2 and ((offset > 127) or (offset < -128)):
                    errors.DoError('range',False)
                return (index,offset)
        elif param == '(C)':
            # It's (C)
            return (param,0)
        else:
            # It must be absolute memory
            dec.Asm.Parse_Pointer = pointer + 1
            value = assem.EvalExpr()
            if assem.NowChar(True) != ')':
                errors.DoError('badoper',False)
            return ('(M)',value[0])
        
    elif param[0] in '#/=\\':
        # It's immediate data
        dec.Asm.Parse_Pointer = pointer
        prefix = assem.NowChar(True)
        value = assem.EvalExpr()
        if prefix == '#':
            data = value[0]
        elif prefix == '/':
            data = value[0] >> 8
        elif prefix == '=':
            data = value[0] >> 16
        else:
            data = value[0] >> 24
        return ('#',data)
    else:
        # It can only be a register(pair) or immediate data by now
        registers = {'A':7, 'B':0, 'C':1, 'D':2, 'E':3, 'H':4, 'L':5, 'I':0, 'R':0,
                     'BC':0, 'DE':1, 'HL':2, 'SP':3,'IX':2, 'IY':2}    
        if param in registers:
            return (param,registers[param])
        else:
            # It wasn't a register, so it's immediate data
            dec.Asm.Parse_Pointer = pointer
            value = assem.EvalExpr()
            return ('#',value[0])

#-----------------------------------------------------------------------------

def Stack():

    global Asm
    
    if MissingOperand():
        return
        
    pair = assem.GetWord()
    
    if pair in ('BC','DE','HL','AF'):
        if pair == 'DE':
            offset = 16
        elif pair == 'HL':
            offset = 32
        elif pair == 'AF':
            offset = 48
        else:
            offset = 0
        Code(dec.Asm.Instructions[dec.Asm.Mnemonic][1] + offset)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
    elif pair in ('IX','IY'):
        if pair == 'IX':
            prefix = int('DD',16)
        else:
            prefix = int('FD',16)
        Code(prefix)
        Code(dec.Asm.Instructions[dec.Asm.Mnemonic][1] + 32)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
    
    else:
        errors.DoError('badoper',False)
    
    NoMore()

#-----------------------------------------------------------------------------

def Mult():

    global Asm
    
    if MissingOperand():
        return
        
    pair = assem.GetWord()
    
    if pair in ('BC','DE','HL','SP'):
        if pair == 'DE':
            offset = 16
        elif pair == 'HL':
            offset = 32
        elif pair == 'SP':
            offset = 48
        else:
            offset = 0
        Code(dec.Asm.Instructions[dec.Asm.Mnemonic][1] + offset)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    else:
        errors.DoError('badoper',False)
    
    NoMore()

#-----------------------------------------------------------------------------

def Math():

    global Asm
    
    if MissingOperand():
        return
        
    reg1 = GetReg()
    
    if assem.NowChar() != ',':
        # Only one parameter given, assume first to be A
        reg2 = reg1
        reg1 = ('A',7)
    else:
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            return
        reg2 = GetReg()
    
    if reg1[0] == 'A':
        # 8-bit math
        if dec.Asm.Mnemonic != 'TST':
            # Normal Z80 math instructions
            if (reg2[0] in ('A','B','C','D','E','H','L')) or (reg2[0] == '(HL)'):
                # math A,reg
                Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16) + reg2[1])
                timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
                if reg2[0] == '(HL)':
                    dec.Asm.Timing = timing[2]
                else:
                    dec.Asm.Timing = timing[0]
            elif reg2[0] == '(IX)':
                # math A,(IX+offs)
                Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16))
                target.CodeByte(reg2[1])
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
            elif reg2[0] == '(IY)':
                # math A,(IY+offs)
                Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16))
                target.CodeByte(reg2[1])
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
            elif reg2[0] == '#':
                # math A,#
                Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][3],16))
                target.CodeByte(reg2[1])
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][3]
            else:
                errors.DoError('badoper',False)
        else:
            # TST instruction, unique to Z180
            if (reg2[0] in ('A','B','C','D','E','H','L')) or (reg2[0] == '(HL)'):
                # TST A,reg
                Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16) + (reg2[1] << 3))
                timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
                if reg2[0] == '(HL)':
                    dec.Asm.Timing = timing[2:]
                else:
                    dec.Asm.Timing = timing[0]
            elif reg2[0] == '#':
                # TST A,#
                Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][3],16))
                target.CodeByte(reg2[1])
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][3]
            else:
                errors.DoError('badoper',False)

    else:
        # 16-bit math
        # In many documentations about the Z80 instruction set the opcode for
        # ADD IX,nn is often mistakenly printed as $DD49, where it should be
        # $DD09.
        if reg1[0] == 'HL':
            if dec.Asm.Mnemonic in ('ADC','ADD','SBC'):
                opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][4],16) + (reg2[1] << 4)
                Code(opcode)
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][4]
            else:
                errors.DoError('badoper',False)

        elif reg1[0] == 'IX' and dec.Asm.Mnemonic == 'ADD':
            if reg2[0] == 'IY':
                errors.DoError('badoper',False)
                return
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][5],16)
            Code(opcode + (reg2[1] << 4))
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][5]
        
        elif reg1[0] == 'IY' and dec.Asm.Mnemonic == 'ADD':
            if reg2[0] == 'IX':
                errors.DoError('badoper',False)
                return
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][6],16)
            Code(opcode + (reg2[1] << 4))
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][6]
                            
        else:
            errors.DoError('badoper',False)
    
    NoMore()
        
#-----------------------------------------------------------------------------

def IncDec():

    global Asm
    
    if MissingOperand():
        return

    reg1 = GetReg()
    
    if reg1[0] in ('A','B','C','D','E','H','L'):
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16) + (reg1[1] << 3)
        Code(opcode)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
    elif reg1[0] == '(HL)':
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
    elif reg1[0] in ('(IX)','(IY)'):
        index = 2
        if reg1[0] == '(IY)':
            index = 3
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16)
        Code(opcode)
        target.CodeByte(reg1[1])
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
    elif reg1[0] in ('BC','DE','HL','SP'):
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][4],16) + (reg1[1] << 4)
        Code(opcode)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][4]
    elif reg1[0] in ('IX','IY'):
        index = 5
        if reg1[0] == 'IY':
            index = 6
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16)
        Code(opcode)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
    else:
        errors.DoError('badoper',False)    
        
    
    NoMore()
        
#-----------------------------------------------------------------------------

def Jumps():

    global Asm
    
    if MissingOperand():
        return
    
    conditions = {'NZ':0,'Z':1,'NC':2,'C':3,'PO':4,'PE':5,'P':6,'M':7}
    pointer = dec.Asm.Parse_Pointer
    condition = assem.GetWord().upper()
    if condition in conditions and assem.NowChar(True) == ',':
        # Conditional jump or call
        value = assem.EvalExpr()
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16) + (conditions[condition] << 3))
        target.CodeWord(value[0])
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
        if dec.Asm.Pass == 2 and ((value[0] >> 16) != 0):
            errors.DoErrors('range',False)
    elif condition == '(HL)':
        # (HL)
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
    elif condition == '(IX)':
        # (IX)
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][3],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][3]
    elif condition == '(IY)':
        # (IY)
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][4],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][3]
    else:
        # Non conditional
        dec.Asm.Parse_Pointer = pointer
        value = assem.EvalExpr()
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16))
        target.CodeWord(value[0])
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
    
    NoMore()

#-----------------------------------------------------------------------------

def Branch():

    global Asm
    
    if MissingOperand():
        return
    
    conditions = {'C':1,'NC':2,'Z':3,'NZ':4}
    pointer = dec.Asm.Parse_Pointer
    condition = assem.GetWord().upper()
    if dec.Asm.Mnemonic == 'JR' and condition in conditions and assem.NowChar(True) == ',':
        index = conditions[condition]
    else:
        dec.Asm.Parse_Pointer = pointer
        index = 0
        
    value = assem.EvalExpr()
    offset = value[0] - dec.Asm.BOL_Address -2
    
    if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
        errors.DoError('range', False)
    
    Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16))
    target.CodeByte(offset)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]        
    
    NoMore()

#-----------------------------------------------------------------------------

def Returns():

    global Asm
    
    conditions = {'NZ':0,'Z':1,'NC':2,'C':3,'PO':4,'PE':5,'P':6,'M':7}
    if dec.Asm.Optional:
        # Parameter was following within 10 spaces
        condition = assem.GetWord().upper()
        if condition in conditions:
            cond = conditions[condition] << 3
            index = 1
        else:
            cond = 0
            index = 0
    else:
        cond = 0
        index = 0
        
    Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16) + cond)
    dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]

    NoMore()

#-----------------------------------------------------------------------------

def Restart():

    global Asm

    if MissingOperand():
        return

    value = assem.EvalExpr()
    
    if dec.Flags.ErrorInLine:
        # Save dummy bute to keep passes in sync
        target.CodeByte(0)
    else:
        # No errors were found
        vector = value[0]
        if value[1] and dec.Asm.Pass == 1:
            # Don't bother about range in case of forward referenced in pass 1
            vector = 0
        if vector > 8:
            if not vector in (16,24,32,40,48,56):
                errors.DoError('range', False)
                vector = 0
        if vector > 7:
            vector = vector >> 3

        target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (vector << 3))

    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

    NoMore()

#-----------------------------------------------------------------------------

def Singles():

    global Asm

    if MissingOperand():
        return
    
    reg1 = GetReg()
    
    if reg1[0] in ('A','B','C','D','E','H','L'):
        # Normal register
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16) + reg1[1])
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        
    elif reg1[0] == '(HL)':
        # (HL)
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
    
    elif reg1[0] == '(IX)':
        # (IX+offs)
        Code(int('DDCB',16))
        target.CodeByte(reg1[1])
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
        
    elif reg1[0] == '(IY)':
        # (IY+offs)
        Code(int('FDCB',16))
        target.CodeByte(reg1[1])
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
        
    else:
        errors.DoError('badoper',False)
    
    NoMore()

#-----------------------------------------------------------------------------

def Bits():

    global Asm

    if MissingOperand():
        return
        
    value = assem.EvalExpr()
    
    if dec.Asm.Pass == 2 and ((value[0] >> 3) != 0):
        errors.DoError('range',False)
    bits = (value[0] & 7) << 3
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    reg1 = GetReg()
    
    if reg1[0] in ('A','B','C','D','E','H','L'):
        # Normal register
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16) + reg1[1] + bits)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        
    elif reg1[0] == '(HL)':
        # (HL)
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16) + bits)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
    
    elif reg1[0] == '(IX)':
        # (IX+offs)
        Code(int('DDCB',16))
        target.CodeByte(reg1[1])
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16) + bits)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
        
    elif reg1[0] == '(IY)':
        # (IY+offs)
        Code(int('FDCB',16))
        target.CodeByte(reg1[1])
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16) + bits)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
        
    else:
        errors.DoError('badoper',False)
    
    NoMore()

#-----------------------------------------------------------------------------

def InOut():

    global Asm

    if MissingOperand():
        return
        
    reg1 = GetReg()

    if dec.Asm.Mnemonic != 'TSTIO':
        # Normal I/O and Z180 specific I/O
        
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            return
        
        reg2 = GetReg()
        
        if dec.Asm.Mnemonic in ('OUT','OUTO'):
            # Swap parameters, makes it a lot easier
            temp = reg1
            reg1 = reg2
            reg2 = temp
        
        if reg2[0] == '(C)':
            # For Z80 it can be reg,(C)
            if reg1[0] in ('A','B','C','D','E','H','L'):
                Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16) + (reg1[1] << 3))
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
            else:
                errors.DoError('badoper',False)
        elif reg2[0] == '(M)' and dec.Asm.Mnemonic in ('IN','OUT'):
            # reg,(m)
            if reg1[0] == 'A':
                Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16))
                target.CodeByte(reg2[1])
                if reg2[1] < 0 or reg2[1] > 255:
                    errors.DoError('range',False)
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
            else:
                errors.DoError('badoper',False)
        elif reg2[0] == '(M)' and dec.Asm.Mnemonic in ('INO','OUTO'):
            # For Z180 it can be reg,(M)
            if reg1[0] in ('A','B','C','D','E','H','L'):
                Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16) + (reg1[1] << 3))
                target.CodeByte(reg2[1])
                if reg2[1] < 0 or reg2[1] > 255:
                    errors.DoError('range',False)
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
            else:
                errors.DoError('badoper',False)
        else:
            errors.DoError('badoper',False)

    else:
        # TSTIO instruction
        
        if reg1[0] == '#':
            Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16))
            target.CodeByte(reg1[1])
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        else:
            errors.DeoError('badoper',False)
    
    NoMore()

#-----------------------------------------------------------------------------

def Exch():

    global Asm

    if MissingOperand():
        return
        
    reg1 = assem.GetWord().upper()
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    reg2 = assem.GetWord().upper()

    if (reg1 == 'DE') and (reg2 == 'HL'):
        index = 0    
    elif (reg1 == 'AF') and (reg2 == "AF'"):
        index = 1
    elif (reg1 == '(SP)') and (reg2 == 'HL'):
        index = 2
    elif (reg1 == '(SP)') and (reg2 == 'IX'):
        index = 3
    elif (reg1 == '(SP)') and (reg2 == 'IY'):
        index = 4
    else:
        errors.DoError('badoper',False)
        return
    
    Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16))
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
    
    NoMore()

#-----------------------------------------------------------------------------

def IM():

    global Asm

    if MissingOperand():
        return
        
    value = assem.EvalExpr()
    
    if dec.Asm.Pass == 1:
        # Ignore range during pass 1
        value = (0, False)
    
    if value[0] >= 0 and value[0] <= 2:
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][value[0]],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    else:
        errors.DoError('range',False)
    
    NoMore()
        
#-----------------------------------------------------------------------------

def Code(code):

    if code > 255:
        target.CodeByte(code >> 8)
    target.CodeByte(code)

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    

