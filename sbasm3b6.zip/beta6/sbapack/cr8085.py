#------------------------------------------------------------------------------
#
#   cr8085.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   8085 Cross Overlay
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags

    assem.CheckVersions(crossversion, minversion)
    
    # The instructions directory contains a tuple with:
    #   function which handles this opcode,
    #   integer value of opcode
    #   string with cycle time(s) of this instruction on an 8085
    #   string with cycle time(s) of this instruction on an 8080

    dec.Asm.Instructions = {
        'CALL': (Absolute,int('CD',16),'18','17'),
        'CC'  : (Absolute,int('DC',16),'9/18','11/17'),
        'CM'  : (Absolute,int('FC',16),'9/18','11/17'),
        'CNC' : (Absolute,int('D4',16),'9/18','11/17'),
        'CNZ' : (Absolute,int('C4',16),'9/18','11/17'),
        'CP'  : (Absolute,int('F4',16),'9/18','11/17'),
        'CPE' : (Absolute,int('EC',16),'9/18','11/17'),
        'CPO' : (Absolute,int('E4',16),'9/18','11/17'),
        'CZ'  : (Absolute,int('CC',16),'9/18','11/17'),
        'JC'  : (Absolute,int('DA',16),'7/10','10'),
        'JM'  : (Absolute,int('FA',16),'7/10','10'),
        'JMP' : (Absolute,int('C3',16),'7','10'),
        'JNC' : (Absolute,int('D2',16),'7/10','10'),
        'JNZ' : (Absolute,int('C2',16),'7/10','10'),
        'JP'  : (Absolute,int('F2',16),'7/10','10'),
        'JPE' : (Absolute,int('EA',16),'7/10','10'),
        'JPO' : (Absolute,int('E2',16),'7/10','10'),
        'JZ'  : (Absolute,int('CA',16),'7/10','10'),
        'LDA' : (Absolute,int('3A',16),'13','13'),
        'LHLD': (Absolute,int('2A',16),'16','16'),
        'SHLD': (Absolute,int('22',16),'16','16'),
        'STA' : (Absolute,int('32',16),'13','13'),
        
        'CMA' : (Inherent,int('2F',16),'4','4'),
        'CMC' : (Inherent,int('3F',16),'4','4'),
        'DAA' : (Inherent,int('27',16),'4','4'),
        'DI'  : (Inherent,int('F3',16),'4','4'),
        'EI'  : (Inherent,int('FB',16),'4','4'),
        'HLT' : (Inherent,int('76',16),'5','7'),
        'NOP' : (Inherent,int('00',16),'4','4'),
        'PCHL': (Inherent,int('E9',16),'6','5'),
        'RAL' : (Inherent,int('17',16),'4','4'),
        'RAR' : (Inherent,int('1F',16),'4','4'),
        'RC'  : (Inherent,int('D8',16),'6/12','5/11'),
        'RET' : (Inherent,int('C9',16),'10','10'),
        'RIM' : (Inherent,int('20',16),'4',''),
        'RLC' : (Inherent,int('07',16),'4','4'),
        'RM'  : (Inherent,int('F8',16),'6/12','5/11'),
        'RNC' : (Inherent,int('D0',16),'6/12','5/11'),
        'RNZ' : (Inherent,int('C0',16),'6/12','5/11'),
        'RP'  : (Inherent,int('F0',16),'6/12','5/11'),
        'RPE' : (Inherent,int('E8',16),'6/12','5/11'),
        'RPO' : (Inherent,int('E0',16),'6/12','5/11'),
        'RRC' : (Inherent,int('0F',16),'4','4'),
        'RZ'  : (Inherent,int('C8',16),'6/12','5/11'),
        'SIM' : (Inherent,int('30',16),'4',''),
        'SPHL': (Inherent,int('F9',16),'6','5'),
        'STC' : (Inherent,int('37',16),'4','4'),
        'XCHG': (Inherent,int('EB',16),'4','4'),
        'XTHL': (Inherent,int('E3',16),'16','18'),

        'MOV' : (MovInst,int('40',16),'4:7','5:7'),
        
        'ADC' : (Math,int('88',16),'4:7','4:7'),
        'ADD' : (Math,int('80',16),'4:7','4:7'),
        'ANA' : (Math,int('A0',16),'4:7','4:7'),
        'CMP' : (Math,int('B8',16),'4:7','4:7'),
        'DCR' : (Math,int('05',16),'4:10','5:10'),
        'INR' : (Math,int('04',16),'4:10','5:10'),
        'ORA' : (Math,int('B0',16),'4:7','4:7'),
        'SBB' : (Math,int('98',16),'4:7','4:7'),
        'SUB' : (Math,int('90',16),'4:7','4:7'),
        'XRA' : (Math,int('A8',16),'4:7','4:7'),

        'ACI' : (Immediate,int('CE',16),'7','7'),
        'ADI' : (Immediate,int('C6',16),'7','7'),
        'ANI' : (Immediate,int('E6',16),'7','7'),
        'CPI' : (Immediate,int('FE',16),'7','7'),
        'LXI' : (Immediate,int('01',16),'10','10'),
        'MVI' : (Immediate,int('06',16),'7:10','7:10'),
        'ORI' : (Immediate,int('F6',16),'7','7'),
        'SBI' : (Immediate,int('DE',16),'7','7'),
        'SUI' : (Immediate,int('D6',16),'7','7'),
        'XRI' : (Immediate,int('EE',16),'7','7'),

        'IN'  : (InOut,int('DB',16),'10','10'),
        'OUT' : (InOut,int('D3',16),'10','10'),
        
        'DAD' : (RegPair,int('09',16),'10','10'),
        'DCX' : (RegPair,int('0B',16),'6','5'),
        'INX' : (RegPair,int('03',16),'6','5'),
        'POP' : (RegPair,int('C1',16),'10','10'),
        'PUSH': (RegPair,int('C5',16),'12','11'),

        'LDAX': (LdaxStax,int('0A',16),'7','7'),
        'STAX': (LdaxStax,int('02',16),'7','7'),

        'RST' : (Restart,int('C7',16),'12','11')
        }

    dec.Asm.Memory = 0
    length = 0
    if dec.Cross.Name == 'cr8085':
        for i in dec.Asm.Instructions:
            if len(dec.Asm.Instructions[i][2]) > length:
                length = len(dec.Asm.Instructions[i][2])
    else:
        for i in dec.Asm.Instructions:
            if len(dec.Asm.Instructions[i][3]) > length:
                length = len(dec.Asm.Instructions[i][3])

    dec.Asm.Timing_Length = length

    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = dec.MAX16
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = False
    
    return

#------------------------------------------------------------------------------

def CrossDirective():

    # This cross overlay has no extra/changed directives
    
    return False    # We didn't handle any directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    # This cross overlay does not need any clean up
    
    return

#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        if dec.Cross.Name == 'cr8085':
            # Get timing for 8085 processor
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
        else:
            # Get timing for 8080 processor
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][3]
        func()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def MissingOperand():

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)

#-----------------------------------------------------------------------------

def MovInst():

    global Asm
    
    timing = dec.Asm.Timing.split(':')
    
    if MissingOperand():
        return

    registers = 'BCDEHLMA'
        
    reg1 = registers.find(assem.NowChar(True).upper())
    
    if reg1 < 0:
        errors.DoError('badoper', False)
        return
     
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    if assem.NowChar() == ' ':
        errors.DoError('missoper', False)
        return
    
    reg2 = registers.find(assem.NowChar(True).upper())
    
    if reg2 < 0:
        errors.DoError('badoper', False)
        return
        
    if reg1 == 6 and reg2 == 6:
        # mov m,m is not allowed, that's the hlt instruction
        errors.DoError('badoper', False)
        return
    
    NoMore()

    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (reg1 << 3) + reg2
    
    if reg1 == 6 or reg2 == 6:
        dec.Asm.Timing = timing[1]
    else:
        dec.Asm.Timing = timing[0]
    
    target.CodeByte(opcode)

#-----------------------------------------------------------------------------

def Inherent():

    global Asm

    if dec.Cross.Name == 'cr8080':
        # Exclude 2 instructions in case we're assembling for an 8080
        if dec.Asm.Mnemonic in ('RIM', 'SIM'):
            errors.DoError('badopco', False)
            return    
    
    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])

#-----------------------------------------------------------------------------

def Absolute():

    global Asm

    if MissingOperand():
        return
    
    value = assem.EvalExpr()
    
    if dec.Asm.Pass == 2 or (not value[1]):
        # Test range only if in pass 2, or pass 1 if not forward referenced
        if value[0] > dec.Asm.Max_Address or value[0] < 0:
            # It's a range error, simply ignore everything which doesn't fit
            errors.DoError('range', False)
        
    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    target.CodeWord(value[0])
    
    if value[2] == 2:
        errors.DoWarning('eeprom')

    NoMore()

#-----------------------------------------------------------------------------

def Math():

    global Asm
    
    timing = dec.Asm.Timing.split(':')

    if MissingOperand():
        return
        
    registers = 'BCDEHLMA'

    reg = registers.find(assem.NowChar(True).upper())
    
    if reg == 6:
        dec.Asm.Timing = timing[1]
    else:
        dec.Asm.Timing = timing[0]

    if dec.Asm.Mnemonic in ('DCR', 'INR'):
        reg = reg << 3
    
    if reg < 0:
        errors.DoError('badoper', False)
        return
     
    NoMore()

    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1] + reg)

#-----------------------------------------------------------------------------

def Immediate():
    
    global Asm
    
    if MissingOperand():
        return

    if dec.Asm.Mnemonic == 'LXI':
        registers = 'BDHS'
        reg = registers.find(assem.NowChar(True).upper())

        if reg < 0:
            errors.DoError('badoper', False)
            return
        if reg == 3:
            # It was S, so next char must be a P to finish SP
            if assem.NowChar(True).upper() != 'P':
                errors.DoError('badoper', False)
                return
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (reg << 4)
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
    elif dec.Asm.Mnemonic == 'MVI':
        registers = 'BCDEHLMA'
        reg = registers.find(assem.NowChar(True).upper())
        timing = dec.Asm.Timing.split(':')
        if reg == 6:
            dec.Asm.Timing = timing[1]
        else:
            dec.Asm.Timing = timing[0]
        if reg < 0:
            errors.DoError('badoper', False)
            return
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (reg << 3)
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
    else:
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1]
        
    prefix = ''
    if assem.NowChar() in '#/=\\':
        prefix = assem.NowChar(True)
        
    value = assem.EvalExpr()
    
    if not dec.Flags.ErrorInLine:
        target.CodeByte(opcode)

        if dec.Asm.Mnemonic == 'LXI':
            if prefix in ' #':
                target.CodeWord(value[0])
            elif prefix == '/':
                target.CodeWord(value[0] >> 8)
            elif prefix == '=':
                target.CodeWord(value[0] >> 16)
            else:
                target.CodeWord(value[0] >> 24)
        else:
            if prefix in ' #':
                target.CodeByte(value[0])
            elif prefix == '/':
                target.CodeByte(value[0] >> 8)
            elif prefix == '=':
                target.CodeByte(value[0] >> 16)
            else:
                target.CodeByte(value[0] >> 24)
            
    NoMore()

#-----------------------------------------------------------------------------

def InOut():

    global Asm

    if MissingOperand():
        return
        
    value = assem.EvalExpr()
    
    if dec.Flags.ErrorInLine:
        # Save 2 dummy bytes if an error was given
        target.CodeWord(0)
    else:
        # No error was found, no danger of getting sync error
        if dec.Asm.Pass == 2 or (not value[1]):
            # Test range in pass 2 or when not forward referenced
            if value[0] > dec.MAX8 or value[0] < 0:
                # Report error, but ignore everthing which doesn't fit
                errors.DoError('range', False)
        target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
        target.CodeByte(value[0])
        
    NoMore()

#-----------------------------------------------------------------------------

def RegPair():

    global Asm

    if MissingOperand():
        return
        
    registers = 'BDHS'
    if dec.Asm.Mnemonic in ('POP', 'PUSH'):
        registers = 'BDHP'
    
    reg = registers.find(assem.NowChar(True).upper())

    if reg < 0:
        errors.DoError('badoper', False)
        return
        
    if reg == 3:
        wrong = False
        if dec.Asm.Mnemonic in ('POP', 'PUSH'):
            if assem.NowChar(True).upper() != 'S':
                wrong = True
            else:
                if assem.NowChar(True).upper() != 'W':
                    wrong = True
        else:
            if assem.NowChar(True).upper() != 'P':
                    wrong = True
        if wrong:
            errors.DoError('badoper', False)
            return
    
    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (reg << 4))
        
    NoMore()
    
#-----------------------------------------------------------------------------

def LdaxStax():

    global Asm

    if MissingOperand():
        return
        
    reg = assem.NowChar(True).upper()

    if reg == 'B':
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1]
    elif reg == 'D':
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (1 << 4)
    else:
        errors.DoError('badoper', False)
        return
                
    NoMore()
    
    target.CodeByte(opcode)
        
#-----------------------------------------------------------------------------

def Restart():

    global Asm

    if MissingOperand():
        return

    value = assem.EvalExpr()
    
    if dec.Flags.ErrorInLine:
        # Save dummy bute to keep passes in sync
        target.CodeByte(0)
    else:
        # No errors were found
        vector = value[0]
        if value[1] and dec.Asm.Pass == 1:
            # Don't bother about range in case of forward referenced in pass 1
            vector = 0
        if vector > 8:
            if not vector in (16,24,32,40,48,56):
                errors.DoError('range', False)
                vector = 0
        if vector > 7:
            vector = vector >> 3
            
        target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (vector << 3))

    NoMore()

#-----------------------------------------------------------------------------


if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    

