#------------------------------------------------------------------------------
#
#   cr6800.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   Cross Overlay Template
#   This cross overlay will handle the assembling of 6800, 6801 and 6301
#   programs, depending on the calling cross overlay
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    """
    Initialize this cross overlay.
    """

    global Asm, Flags
    
    assem.CheckVersions(crossversion, minversion)

    # Tupple: Handling routine, opcode, 6800 timing, 6801 timing    

    dec.Asm.Instructions = {
        'ABA' : (Implied,int('1B',16),'2','2','1'),
        'ABX' : (Implied,int('3A',16),'0','3','1'),
        'ASLA': (Implied,int('48',16),'2','2','1'),
        'ASLB': (Implied,int('58',16),'2','2','1'),
        'ASLD': (Implied,int('05',16),'0','3','1'),
        'ASRA': (Implied,int('47',16),'2','2','1'),
        'ASRB': (Implied,int('57',16),'2','2','1'),
        'CBA' : (Implied,int('11',16),'2','2','1'),
        'CLC' : (Implied,int('0C',16),'2','2','1'),
        'CLI' : (Implied,int('0E',16),'2','2','1'),
        'CLRA': (Implied,int('4F',16),'2','2','1'),
        'CLRB': (Implied,int('5F',16),'2','2','1'),
        'CLV' : (Implied,int('0A',16),'2','2','1'),
        'COMA': (Implied,int('43',16),'2','2','1'),
        'COMB': (Implied,int('53',16),'2','2','1'),
        'DAA' : (Implied,int('19',16),'2','2','2'),
        'DECA': (Implied,int('4A',16),'2','2','1'),
        'DECB': (Implied,int('5A',16),'2','2','1'),
        'DES' : (Implied,int('34',16),'4','3','1'),
        'DEX' : (Implied,int('09',16),'4','3','1'),
        'INCA': (Implied,int('4C',16),'2','2','1'),
        'INCB': (Implied,int('5C',16),'2','2','1'),
        'INS' : (Implied,int('31',16),'4','3','1'),
        'INX' : (Implied,int('08',16),'4','3','1'),
        'LSLA': (Implied,int('48',16),'2','2','1'),
        'LSLB': (Implied,int('58',16),'2','2','1'),
        'LSLD': (Implied,int('05',16),'0','3','1'),
        'LSRA': (Implied,int('44',16),'2','2','1'),
        'LSRB': (Implied,int('54',16),'2','2','1'),
        'LSRD': (Implied,int('04',16),'0','3','1'),
        'MUL' : (Implied,int('3D',16),'0','10','7'),
        'NEGA': (Implied,int('40',16),'2','2','1'),
        'NEGB': (Implied,int('50',16),'2','2','1'),
        'NOP' : (Implied,int('01',16),'2','2','1'),
        'PSHA': (Implied,int('36',16),'4','3','4'),
        'PSHB': (Implied,int('37',16),'4','3','4'),
        'PSHX': (Implied,int('3C',16),'0','4','5'),
        'PULA': (Implied,int('32',16),'4','4','3'),
        'PULB': (Implied,int('33',16),'4','4','3'),
        'PULX': (Implied,int('38',16),'0','5','4'),
        'ROLA': (Implied,int('49',16),'2','2','1'),
        'ROLB': (Implied,int('59',16),'2','2','1'),
        'RORA': (Implied,int('46',16),'2','2','1'),
        'RORB': (Implied,int('56',16),'2','2','1'),
        'RTI' : (Implied,int('3B',16),'10','10','10'),
        'RTS' : (Implied,int('39',16),'5','5','5'),
        'SBA' : (Implied,int('10',16),'2','2','1'),
        'SEC' : (Implied,int('0D',16),'2','2','1'),
        'SEI' : (Implied,int('0F',16),'2','2','1'),
        'SEV' : (Implied,int('0B',16),'2','2','1'),
        'SLP' : (Implied,int('1A',16),'0','0','4'),
        'SWI' : (Implied,int('3F',16),'12','12','12'),
        'TAB' : (Implied,int('16',16),'2','2','1'),
        'TAP' : (Implied,int('06',16),'2','2','1'),
        'TBA' : (Implied,int('17',16),'2','2','1'),
        'TPA' : (Implied,int('07',16),'2','2','1'),
        'TSTA': (Implied,int('4D',16),'2','2','1'),
        'TSTB': (Implied,int('5D',16),'2','2','1'),
        'TSX' : (Implied,int('30',16),'4','3','1'),
        'TXS' : (Implied,int('35',16),'4','3','1'),
        'WAI' : (Implied,int('3E',16),'9','9','9'),
        'XGDX': (Implied,int('18',16),'0','0','2'),

        'BCC' : (Branch,int('24',16),'4','3','3'),
        'BCS' : (Branch,int('25',16),'4','3','3'),
        'BEQ' : (Branch,int('27',16),'4','3','3'),
        'BGE' : (Branch,int('2C',16),'4','3','3'),
        'BGT' : (Branch,int('2E',16),'4','3','3'),
        'BHI' : (Branch,int('22',16),'4','3','3'),
        'BLE' : (Branch,int('2F',16),'4','3','3'),
        'BLS' : (Branch,int('23',16),'4','3','3'),
        'BLT' : (Branch,int('2D',16),'4','3','3'),
        'BMI' : (Branch,int('2B',16),'4','3','3'),
        'BNE' : (Branch,int('26',16),'4','3','3'),
        'BPL' : (Branch,int('2A',16),'4','3','3'),
        'BRA' : (Branch,int('20',16),'4','3','3'),
        'BRN' : (Branch,int('21',16),'0','3','3'),
        'BSR' : (Branch,int('8D',16),'8','3','3'),
        'BVC' : (Branch,int('28',16),'4','3','3'),
        'BVS' : (Branch,int('29',16),'4','3','3'),
        'BHS' : (Branch,int('24',16),'4','3','3'),
        'BLO' : (Branch,int('25',16),'4','3','3'),

        'ADCA' : (Multi,('89','99','A9','B9'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'ADCB' : (Multi,('C9','D9','E9','F9'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'ADDA' : (Multi,('8B','9B','AB','BB'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'ADDB' : (Multi,('CB','DB','EB','FB'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'ADDD' : (Multi,('C3','D3','E3','F3'),
                        ('0','0','0','0'),
                        ('4','5','6','6'),
                        ('3','4','5','5')),
        'ANDA' : (Multi,('84','94','A4','B4'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'ANDB' : (Multi,('C4','D4','E4','F4'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'ASL'  : (Multi,('00','00','68','78'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','6','6')),
        'ASR'  : (Multi,('00','00','67','77'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','6','6')),
        'BITA' : (Multi,('85','95','A5','B5'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'BITB' : (Multi,('C5','D5','E5','F5'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'CLR'  : (Multi,('00','00','6F','7F'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','5','5')),
        'CMPA' : (Multi,('81','91','A1','B1'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'CMPB' : (Multi,('C1','D1','E1','F1'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'COM'  : (Multi,('00','00','63','73'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','6','6')),
        'CPX'  : (Multi,('8C','9C','AC','BC'),
                        ('3','4','6','5'),
                        ('4','5','6','6'),
                        ('3','4','5','5')),
        'DEC'  : (Multi,('00','00','6A','7A'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','6','6')),
        'EORA' : (Multi,('88','98','A8','B8'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'EORB' : (Multi,('C8','D8','E8','F8'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'INC'  : (Multi,('00','00','6C','7C'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','6','6')),
        'JMP'  : (Multi,('00','00','6E','7E'),
                        ('0','0','4','3'),
                        ('0','0','3','3'),
                        ('0','0','3','3')),
        'JSR'  : (Multi,('00','9D','AD','BD'),
                        ('0','0','8','9'),
                        ('0','5','6','6'),
                        ('0','5','5','6')),
        'LDAA' : (Multi,('86','96','A6','B6'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'LDAB' : (Multi,('C6','D6','E6','F6'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'LDD'  : (Multi,('CC','DC','EC','FC'),
                        ('0','0','0','0'),
                        ('3','4','5','5'),
                        ('3','4','5','5')),
        'LDAD' : (Multi,('CC','DC','EC','FC'),
                        ('0','0','0','0'),
                        ('3','4','5','5'),
                        ('3','4','5','5')),
        'LDS'  : (Multi,('8E','9E','AE','BE'),
                        ('3','4','6','5'),
                        ('3','4','5','5'),
                        ('3','4','5','5')),
        'LDX'  : (Multi,('CE','DE','EE','FE'),
                        ('3','4','6','5'),
                        ('3','4','5','5'),
                        ('3','4','5','5')),
        'LSL'  : (Multi,('00','00','68','78'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','6','6')),
        'LSR'  : (Multi,('00','00','64','74'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','6','6')),
        'NEG'  : (Multi,('00','00','60','70'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','6','6')),
        'ORAA' : (Multi,('8A','9A','AA','BA'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'ORAB' : (Multi,('CA','DA','EA','FA'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'ROL'  : (Multi,('00','00','69','79'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','6','6')),
        'ROR'  : (Multi,('00','00','66','76'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','6','6')),
        'SBCA' : (Multi,('82','92','A2','B2'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'SBCB' : (Multi,('C2','D2','E2','F2'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'STAA' : (Multi,('00','97','A7','B7'),
                        ('0','4','6','5'),
                        ('0','3','4','4'),
                        ('0','3','4','4')),
        'STAB' : (Multi,('00','D7','E7','F7'),
                        ('0','4','6','5'),
                        ('0','3','4','4'),
                        ('0','3','4','4')),
        'STD'  : (Multi,('00','DD','ED','FD'),
                        ('0','0','0','0'),
                        ('0','4','5','5'),
                        ('0','4','5','5')),
        'STAD' : (Multi,('00','DD','ED','FD'),
                        ('0','0','0','0'),
                        ('0','4','5','5'),
                        ('0','4','5','5')),
        'STS'  : (Multi,('00','9F','AF','BF'),
                        ('0','5','7','6'),
                        ('0','4','5','5'),
                        ('0','4','5','5')),
        'STX'  : (Multi,('00','DF','EF','FF'),
                        ('0','5','7','6'),
                        ('0','4','5','5'),
                        ('0','4','5','5')),
        'SUBA' : (Multi,('80','90','A0','B0'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'SUBB' : (Multi,('C0','D0','E0','F0'),
                        ('2','3','5','4'),
                        ('2','3','4','4'),
                        ('2','3','4','4')),
        'SUBD' : (Multi,('83','93','A3','B3'),
                        ('0','0','0','0'),
                        ('4','5','6','6'),
                        ('3','4','5','5')),
        'TST'  : (Multi,('00','00','6D','7D'),
                        ('0','0','7','6'),
                        ('0','0','6','6'),
                        ('0','0','4','4')),
                        
        'AIM'  : (H6301,('71','61'),('6','7')),
        'EIM'  : (H6301,('75','65'),('6','7')),
        'OIM'  : (H6301,('72','62'),('6','7')),
        'TIM'  : (H6301,('7B','6B'),('4','5'))
    }
    
    dec.Asm.Timing_Length = 2

    dec.Asm.Memory = 0
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = dec.MAX16
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = True

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    """
    No extra directives for this Cross overlay
    """

    return False     # return True if we handled the directive

#------------------------------------------------------------------------------

def CrossCleanUp():

    """
    No need to do any cleaning.
    """

    return    
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    """
    Find and decode the current mnemonic.
    """

    global Asm

    if dec.Cross.Name == 'cr6800':
        # In case of 6800 overlay
        index = 2
    elif dec.Cross.Name == 'cr6801':
        # In case of 6801 overlay
        index = 3
    else:
        # Must be 6301 now
        index = 4

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func(index)
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def MissingOperand():

    """
    An operand must follow. Raise an error if it's not.
    """
    
    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    """
    No more operands shoudl follow. Raise a warning if more parameters follow.
    """

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)
        
#-----------------------------------------------------------------------------

def Implied(index):

    """
    Handle implied addressing mode.
    Simply save the opcode and we're done with it.
    """

    global Asm

    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][index]
    if dec.Asm.Timing == 0:
        errros.DoError('badopco', False)
        return
    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])

#-----------------------------------------------------------------------------

def Branch(index):

    """
    Handle branch instructions.
    Displacement is destinaiton - current address - 2
    """

    global Asm

    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][index]
    if dec.Asm.Timing == 0:
        errros.DoError('badopco', False)
        return

    if MissingOperand():
        return

    value = assem.EvalExpr()
    offset = value[0] - dec.Asm.BOL_Address - 2
    
    if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
        errors.DoError('range', False)

    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    target.CodeByte(offset)
    
    NoMore()

#-----------------------------------------------------------------------------

def Multi(index):

    """
    Handle all other mnemonics of the 6502 instructionset.
    Each addressing mode has a separate entry in the opcode tupple.
    If the opcode is '00' the particular instruction is not available.
    If the mnemonic ends in S or X immediate mode will have 16 bit constants
    """

    global Asm

    available = dec.Asm.Instructions[dec.Asm.Mnemonic][index][0] + \
                dec.Asm.Instructions[dec.Asm.Mnemonic][index][1] + \
                dec.Asm.Instructions[dec.Asm.Mnemonic][index][2] + \
                dec.Asm.Instructions[dec.Asm.Mnemonic][index][3] 
    if available == '0000':
        errors.DoError('badopco', False)
        return
    
    if MissingOperand():
        return

    if assem.NowChar() in "#/=\\":
        # Immediate addressing mode
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][index][0]
        if dec.Asm.Timing == 0:
            errors.DoError('badopco', False)
            return
        if opcode == 0:
            errors.DoError('badoper', False)
            return
        prefix = assem.NowChar(True)
        value = assem.EvalExpr()
        if prefix == '#':
            operand = value[0]
        elif prefix == '/':
            operand = value[0] >> 8
        elif prefix == '=':
            operand = value[0] >> 16
        else:
            operand = value[0] >> 24

        if dec.Asm.Mnemonic[-1] in 'SXD':
            target.CodeByte(opcode)
            target.CodeWord(operand)
        else:
            target.CodeByte(opcode)
            target.CodeByte(operand)
        
        NoMore()
        return
        
    indexedX = False
    if dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:].upper()[:2] == 'X ' or assem.NowChar() == ',':
        # LDAA X    and LDAA ,X    are equivalent to the official LDAA 0,X
        value = (0, False)
        if assem.NowChar().upper() == 'X':
            indexedX = True
    else:
        if assem.NowChar() in '<>':
            prefix = assem.NowChar(True)    
        else:
            prefix = ''

        value = assem.EvalExpr()
    
    if indexedX or assem.MoreParameters():
        # It must be ZP,X addressing mode
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][index][2]
        if dec.Asm.Timing == 0:
            errors.DoError('badopco', False)
            return
        
        if assem.NowChar(True).upper() != 'X' or opcode == 0:
            errors.DoError('badoper', False)
            return
        
        if dec.Asm.Pass == 2 and (value[0] >> 8) != 0:
            errors.DoError('range', False)
        target.CodeByte(opcode)
        target.CodeByte(value[0])
        
        NoMore()
        return
     
    opcodezp = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16)
    timingzp = dec.Asm.Instructions[dec.Asm.Mnemonic][index][1]
    opcodeabs = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][3],16)
    timingabs = dec.Asm.Instructions[dec.Asm.Mnemonic][index][3]
    
    if opcodezp == 0:
        zp = False
    elif prefix == '<':
        zp = True
        if dec.Asm.Pass == 2 and (value[0] >> 8) != 0:
            errors.DoError('range', False)
    elif prefix == '>' or value[1]:
        zp = False
    else:
        zp = False
        if (value[0] >> 8) == 0:
            zp = True
    
    if zp:
        # ZP mode is to be used
        if timingzp == 0:
            errors.DoError('badopco', False)
            return
        target.CodeByte(opcodezp)
        target.CodeByte(value[0])
        dec.Asm.Timing = timingzp
    else:
        # ABS mode is to be used
        if timingabs == 0:
            errors.DoError('badopco', False)
            return
        target.CodeByte(opcodeabs)
        target.CodeWord(value[0])
        dec.Asm.Timing = timingabs
        
    NoMore()

#-----------------------------------------------------------------------------

def H6301(index):

    """
    Handle immediate boolean instructions, only known to the Hitachi 6301
    """

    global Asm
    
    if index != 4:
        # These instructions only exist in the 6301
        errors.DoError('badopco', False)
        return
    
    if MissingOperand():
        return
        
    prefix = assem.NowChar(True)
    if not prefix in '#/=\\':
        errors.DoError ('badoper', False)
        return
    
    value = assem.EvalExpr()
    
    if prefix == '#':
        oper1 = value[0]
    elif prefix == '/':
        oper1 = value[0] >> 8
    elif prefix == '=':
        oper1 = value[0] >> 16
    else:
        oper1 = value[0] >> 24
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
        
    prefix = ''
    if assem.NowChar() == '<':
        # Only forced ZP prefix allowed today
        assem.IncParsePointer()
        prefix = '<'
        
    value = assem.EvalExpr()
    
    if dec.Asm.Pass == 2 and prefix == '':
        if value[0] >> 8 != 0:
            errors.DoError('range', False)

    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][0]
    timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
    if assem.MoreParameters():
        if assem.NowChar(True).upper() != 'X':
            errors.DoError('badoper', False)
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][1]
        timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
        
    target.CodeByte(int(opcode,16))
    target.CodeByte(oper1)
    target.CodeByte(value[0])
    dec.Asm.Timing = timing   
        
    NoMore()
    
#-----------------------------------------------------------------------------


if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    
