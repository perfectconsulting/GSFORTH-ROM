#------------------------------------------------------------------------------
#
#   cr6502.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   Cross Overlay for the 6502 devices
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

sweet16 = False         # Sweet16 mode if True
Sweet16_Mnemonics = {}  # Extra instruction set for Sweet16
modelinex = 2

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'
    # instruction length in clock cycles
    # *  add 1 if page boundary is crossed
    # ** add 1 if branch occurs to same page
    #    add 2 if branch occurs to next page
    # The Cmos chips have different timings.
    # Especially if the D flag is set, most data instructions take 1 cycle more
    # Also if indexes cross a page boundary the instruction takes 1 cycle more
    # The document W65C02S contains some errors/inconcistencies regardging timings

#------------------------------------------------------------------------------

def CrossInit():

    """
    Initialize this cross overlay.
    Mainly create two dictionaries. One holding all 6502 instructions and
    one holding the Sweet16 instructions.
    Set default mode to 6502 instructions.
    Also add one extra warning for the 6502 JMP (IND) bug
    """

    global Asm, Flags, Error_List, sweet16, Sweet16_Mnemonics, modelindex
    
    assem.CheckVersions(crossversion, minversion)
    sweet16 = False
    
    if dec.Cross.Name == 'cr6502':
        # Index to 6502 instruction times
        modelindex = 2
    else:
        # Index to 65C02 and 65SC02 instruction times
        modelindex = 3
    
    # The instructions directory contains a tuple with:
    #   function which handles this opcode,
    #   integer value of opcode, or a tupple with opcodes
    #   string or tupple with 6502 cycle time(s)
    #   string or tupple with 65C02 cycle time(s)
    # If the final cycle time is 0 that particular instruction
    # or addressing mode doesn't exist for the selected
    # processor.

    dec.Asm.Instructions = {
        'BRK' : (Implied,int('00',16),'7','7'),
        'CLC' : (Implied,int('18',16),'2','2'),
        'CLD' : (Implied,int('D8',16),'2','2'),
        'CLI' : (Implied,int('58',16),'2','2'),
        'CLV' : (Implied,int('B8',16),'2','2'),
        'DEA' : (Implied,int('3A',16),'0','2'),
        'DEX' : (Implied,int('CA',16),'2','2'),
        'DEY' : (Implied,int('88',16),'2','2'),
        'INA' : (Implied,int('1A',16),'0','2'),
        'INX' : (Implied,int('E8',16),'2','2'),
        'INY' : (Implied,int('C8',16),'2','2'),
        'NOP' : (Implied,int('EA',16),'2','2'),
        'PHA' : (Implied,int('48',16),'3','3'),
        'PHP' : (Implied,int('08',16),'3','3'),
        'PHX' : (Implied,int('DA',16),'0','3'),
        'PHY' : (Implied,int('5A',16),'0','3'),
        'PLA' : (Implied,int('68',16),'4','4'),
        'PLP' : (Implied,int('28',16),'4','4'),
        'PLX' : (Implied,int('FA',16),'0','4'),
        'PLY' : (Implied,int('7A',16),'0','4'),
        'RTI' : (Implied,int('40',16),'6','6'),
        'RTS' : (Implied,int('60',16),'6','6'),
        'SEC' : (Implied,int('38',16),'2','2'),
        'SED' : (Implied,int('F8',16),'2','2'),
        'SEI' : (Implied,int('78',16),'2','2'),
        'STP' : (Implied,int('DB',16),'0','3'),
        'TAX' : (Implied,int('AA',16),'2','2'),
        'TAY' : (Implied,int('A8',16),'2','2'),
        'TSX' : (Implied,int('BA',16),'2','2'),
        'TXA' : (Implied,int('8A',16),'2','2'),
        'TXS' : (Implied,int('9A',16),'2','2'),
        'TYA' : (Implied,int('98',16),'2','2'),
        'WAI' : (Implied,int('CB',16),'0','3'),

        'BCC' : (Branch,int('90',16),'2**','2**'),
        'BCS' : (Branch,int('B0',16),'2**','2**'),
        'BEQ' : (Branch,int('F0',16),'2**','2**'),
        'BMI' : (Branch,int('30',16),'2**','2**'),
        'BNE' : (Branch,int('D0',16),'2**','2**'),
        'BPL' : (Branch,int('10',16),'2**','2**'),
        'BRA' : (Branch,int('80',16),'0',  '2**'),
        'BVC' : (Branch,int('50',16),'2**','2**'),
        'BVS' : (Branch,int('70',16),'2**','2**'),

        # implied, imm, zp, abs, (zp,x) (zp),y, zp,x abs,x zp,y abs,y (zp)

        'ADC' : (Multi,('00','69','65','6D','61','71','75','7D','00','79','72'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','0'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','5')),
        'ADD' : (Multi,('00','69','65','6D','61','71','75','7D','00','79','72'),
                       ('0', '4', '5', '6', '8', '5*','6', '6*','0', '6*','0'),
                       ('0', '4', '5', '6', '8', '5*','6', '6*','0', '6*','5')),
        'AND' : (Multi,('00','29','25','2D','21','31','35','3D','00','39','32'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','0'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','5')),
        'ASL' : (Multi,('0A','00','06','0E','00','00','16','1E','00','00','00'),
                       ('2', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0'),
                       ('2', '0', '5', '6', '0', '0', '6', '6*','0', '0', '0')),
        'BIT' : (Multi,('00','89','24','2C','00','00','34','3C','00','00','00'),
                       ('0', '0', '3', '4', '0', '0', '0', '0', '0', '0', '0'),
                       ('0', '2', '3', '4', '0', '0', '4', '4', '0', '0', '0')),
        'CMP' : (Multi,('00','C9','C5','CD','C1','D1','D5','DD','00','D9','D2'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','0'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','5')),
        'CPX' : (Multi,('00','E0','E4','EC','00','00','00','00','00','00','00'),
                       ('0', '2', '3', '4', '0', '0', '0', '0', '0', '0', '0'),
                       ('0', '2', '3', '4', '0', '0', '0', '0', '0', '0', '0')),
        'CPY' : (Multi,('00','C0','C4','CC','00','00','00','00','00','00','00'),
                       ('0', '2', '3', '4', '0', '0', '0', '0', '0', '0', '0'),
                       ('0', '2', '3', '4', '0', '0', '0', '0', '0', '0', '0')),
        'DEC' : (Multi,('3A','00','C6','CE','00','00','D6','DE','00','00','00'),
                       ('0', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0'),
                       ('2', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0')),
        'EOR' : (Multi,('00','49','45','4D','41','51','55','5D','00','59','52'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','0'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','5')),
        'INC' : (Multi,('1A','00','E6','EE','00','00','F6','FE','00','00','00'),
                       ('0', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0'),
                       ('2', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0')),
        'JMP' : (Multi,('00','00','00','4C','7C','00','00','00','00','00','6C'),
                       ('0', '0', '0', '3', '0', '0', '0', '0', '0', '0', '5'),
                       ('0', '0', '0', '3', '6', '0', '0', '0', '0', '0', '6')),
        'JSR' : (Multi,('00','00','00','20','00','00','00','00','00','00','00'),
                       ('0', '0', '0', '6', '0', '0', '0', '0', '0', '0', '0'),
                       ('0', '0', '0', '6', '0', '0', '0', '0', '0', '0', '0')),
        'LDA' : (Multi,('00','A9','A5','AD','A1','B1','B5','BD','00','B9','B2'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','0'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','5')),
        'LDX' : (Multi,('00','A2','A6','AE','00','00','00','00','B6','BE','00'),
                       ('0', '2', '3', '4', '0', '0', '0', '0', '4', '4*','0'),
                       ('0', '2', '3', '4', '0', '0', '0', '0', '4', '4*','0')),
        'LDY' : (Multi,('00','A0','A4','AC','00','00','B4','BC','00','00','00'),
                       ('0', '2', '3', '4', '0', '0', '4', '4*','0', '0', '0'),
                       ('0', '2', '3', '4', '0', '0', '4', '4*','0', '0', '0')),
        'LSR' : (Multi,('4A','00','46','4E','00','00','56','5E','00','00','00'),
                       ('2', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0'),
                       ('2', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0')),
        'ORA' : (Multi,('00','09','05','0D','01','11','15','1D','00','19','12'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','0'),
                       ('0', '2',' 3', '4', '6', '5*','4', '4*','0', '4*','5')),
        'ROL' : (Multi,('2A','00','26','2E','00','00','36','3E','00','00','00'),
                       ('2', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0'),
                       ('2', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0')),
        'ROR' : (Multi,('6A','00','66','6E','00','00','76','7E','00','00','00'),
                       ('2', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0'),
                       ('2', '0', '5', '6', '0', '0', '6', '7', '0', '0', '0')),
        'SBC' : (Multi,('00','E9','E5','ED','E1','F1','F5','FD','00','F9','F2'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','0'),
                       ('0', '2', '3', '4', '6', '5*','4', '4*','0', '4*','5')),
        'SUB' : (Multi,('00','E9','E5','ED','E1','F1','F5','FD','00','F9','F2'),
                       ('0', '4', '5', '6', '8', '7*','6', '6*','0', '6*','0'),
                       ('0', '4', '5', '6', '8', '7*','6', '6*','0', '6*','5')),
        'STA' : (Multi,('00','00','85','8D','81','91','95','9D','00','99','92'),
                       ('0', '0', '2', '4', '6', '6', '4', '5' ,'0', '5', '0'),
                       ('0', '0', '3', '4', '6', '6', '4', '5' ,'0', '5', '5')),
        'STX' : (Multi,('00','00','86','8E','00','00','00','00','96','00','00'),
                       ('0', '0', '3', '4', '0', '0', '0', '0', '4', '0', '0'),
                       ('0', '0', '3', '4', '0', '0', '0', '0', '4', '0', '0')),
        'STY' : (Multi,('00','00','84','8C','00','00','94','00','00','00','00'),
                       ('0', '0', '3', '4', '0', '0', '4', '0', '0', '0', '0'),
                       ('0', '0', '3', '4', '0', '0', '4', '0', '0', '0', '0')),
        'STZ' : (Multi,('00','00','64','9C','00','00','74','9E','00','00','00'),
                       ('0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
                       ('0', '0', '3', '4', '0', '0', '4', '5', '0', '0', '0')),
        'TRB' : (Multi,('00','00','14','1C','00','00','94','00','00','00','00'),
                       ('0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
                       ('0', '0', '5', '6', '0', '0', '4', '0', '0', '0', '0')),
        'TSB' : (Multi,('00','00','04','0C','00','00','94','00','00','00','00'),
                       ('0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
                       ('0', '0', '5', '6', '0', '0', '4', '0', '0', '0', '0')),
                       
        'BBR0': (BitMan, int('0F',16), '5'),
        'BBR1': (BitMan, int('1F',16), '5'),
        'BBR2': (BitMan, int('2F',16), '5'),
        'BBR3': (BitMan, int('3F',16), '5'),
        'BBR4': (BitMan, int('4F',16), '5'),
        'BBR5': (BitMan, int('5F',16), '5'),
        'BBR6': (BitMan, int('6F',16), '5'),
        'BBR7': (BitMan, int('7F',16), '5'),
        'BBR' : (BitMan, int('0F',16), '5'),
        'BBS0': (BitMan, int('8F',16), '5'),
        'BBS1': (BitMan, int('9F',16), '5'),
        'BBS2': (BitMan, int('AF',16), '5'),
        'BBS3': (BitMan, int('BF',16), '5'),
        'BBS4': (BitMan, int('CF',16), '5'),
        'BBS5': (BitMan, int('DF',16), '5'),
        'BBS6': (BitMan, int('EF',16), '5'),
        'BBS7': (BitMan, int('FF',16), '5'),
        'BBS' : (BitMan, int('8F',16), '5'),
        'RMB0': (BitMan, int('07',16), '5'),
        'RMB1': (BitMan, int('17',16), '5'),
        'RMB2': (BitMan, int('27',16), '5'),
        'RMB3': (BitMan, int('37',16), '5'),
        'RMB4': (BitMan, int('47',16), '5'),
        'RMB5': (BitMan, int('57',16), '5'),
        'RMB6': (BitMan, int('67',16), '5'),
        'RMB7': (BitMan, int('77',16), '5'),
        'RMB' : (BitMan, int('07',16), '5'),
        'SMB0': (BitMan, int('87',16), '5'),
        'SMB1': (BitMan, int('97',16), '5'),
        'SMB2': (BitMan, int('A7',16), '5'),
        'SMB3': (BitMan, int('B7',16), '5'),
        'SMB4': (BitMan, int('C7',16), '5'),
        'SMB5': (BitMan, int('D7',16), '5'),
        'SMB6': (BitMan, int('E7',16), '5'),
        'SMB7': (BitMan, int('F7',16), '5'),
        'SMB' : (BitMan, int('87',16), '5')
    }

    Sweet16_Mnemonics = {
        'BK'  : (Single16,'0A'),
        'RS'  : (Single16,'0B'),
        'RTN' : (Single16,'00'),

        'BR'  : (Branch16,'01'),
        'BNC' : (Branch16,'02'),
        'BC'  : (Branch16,'03'),
        'BP'  : (Branch16,'04'),
        'BM'  : (Branch16,'05'),
        'BZ'  : (Branch16,'06'),
        'BNZ' : (Branch16,'07'),
        'BM1' : (Branch16,'08'),
        'BNM1': (Branch16,'09'),
        'BS'  : (Branch16,'0C'),

        'SET' : (Sweet16,'10','00'),
        'LD'  : (Sweet16,'20','40'),
        'ST'  : (Sweet16,'30','50'),
        'LDD' : (Sweet16,'00','60'),
        'STD' : (Sweet16,'00','70'),
        'POP' : (Sweet16,'00','80'),
        'STP' : (Sweet16,'00','90'),
        'ADD' : (Sweet16,'A0','00'),
        'SUB' : (Sweet16,'B0','00'),
        'POPD': (Sweet16,'00','C0'),
        'CPR' : (Sweet16,'D0','00'),
        'INR' : (Sweet16,'E0','00'),
        'DCR' : (Sweet16,'F0','00')
    }

    dec.Asm.Timing_Length = 3   # Maximum length of instruction time

    errors.Error_List['6502bug'] = '6502 JMP (IND) bug at $xxFF'

    dec.Asm.Memory = 0
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = dec.MAX16
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = False

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    """
    No extra directives for this Cross overlay
    """

    return False     # We didn't handle any directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    """
    No need to do any cleaning.
    """
    
    return
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    """
    Find and decode the current mnemonic.
    This may be a normal 6502 instruction, or a Sweet16 instruction depending
    on the current mode.
    JSR SWEET16 switches mode from 6502 to Sweet16, regardless of the value
    of the lable SWEET16.
    RTN switches mode back from Sweet16 to 6502.
    """

    global Asm

    if not sweet16:
        # Parse normal 6502 mnemonics
        if dec.Asm.Mnemonic in dec.Asm.Instructions:
            func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
            func()
        else:
            errors.DoError('badopco', False)
    else:
        # Parse Sweet16 mnemonics
        if dec.Asm.Mnemonic in Sweet16_Mnemonics:
            func = Sweet16_Mnemonics[dec.Asm.Mnemonic][0]
            dec.Asm.Timing = '?'
            func()
        else:
            errors.DoError('badopco', False)
    
#-----------------------------------------------------------------------------

def MissingOperand():

    """
    An operand must follow. Raise an error if it's not.
    """
    
    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    """
    No more operands shoudl follow. Raise a warning if more parameters follow.
    """

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)
        
#-----------------------------------------------------------------------------

def Implied():

    """
    Handle implied addressing mode.
    Simply save the opcode and we're done with it.
    """

    global Asm

    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][modelindex]
    if dec.Asm.Timing != '0':
        target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def Branch():

    """
    Handle branch instructions.
    Displacement is destinaiton - current address - 2
    """

    global Asm

    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][modelindex]
    if dec.Asm.Timing != '0':
        if MissingOperand():
            return

        value = assem.EvalExpr()
        offset = value[0] - dec.Asm.BOL_Address - 2

        if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
            errors.DoError('range', False)

        target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
        target.CodeByte(offset)
        
        NoMore()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def Multi():

    """
    Handle all other mnemonics of the 6502 instructionset.
    Each addressing mode has a separate entry in the opcode tupple.
    If the opcode is '00' the particular instruction is not available
    on the selected model.
    If the cycle length is '0' the particular addressing mode is not
    supported.
    The model is selected by calling either the 6502 overlay, or the
    65c02 or 65sc02 overlays.
    """

    global Asm, sweet16
    
    if modelindex == 2 and (dec.Asm.Mnemonic in ('STZ', 'TRB', 'TSB')):
        errors.DoError('badopco', False)
        return

    instructions = dec.Asm.Instructions[dec.Asm.Mnemonic][1]
    ctimes = dec.Asm.Instructions[dec.Asm.Mnemonic][modelindex]
    operandbegin = dec.Asm.Parse_Pointer
    
    # Does implied addressing exist for this instruction?
    optional = dec.Asm.Optional
    pointer = dec.Asm.Parse_Pointer
    if instructions[0] != '00' and ctimes[0] != '0':
        if optional and (dec.Asm.Parse_Line[operandbegin:operandbegin+2].upper() == "A "):
            optional = False
        if optional == False:
            # No operand followed, use implied addressing mode
            dec.Asm.Timing = ctimes[0]
            target.CodeByte(int(instructions[0],16))
            return

    if MissingOperand():
        return
    
    # There are two compound instructions, save prefix for them first
    if dec.Asm.Mnemonic == 'ADD':
        target.CodeByte(int('18',16))
    if dec.Asm.Mnemonic == 'SUB':
        target.CodeByte(int('38',16))
        
    nowchar = assem.NowChar().upper()
    
    # Is it immediate addressing mode?
    if nowchar in '#/=\\':
        if instructions[1] == '00' or ctimes[1] == '0':
            errors.DoError('badoper',False)
            return
        prefix = assem.NowChar(True)
        value = assem.EvalExpr()
        dec.Asm.Timing = ctimes[1]
        if prefix == '#':
            operand = value[0]
        elif prefix == '/':
            operand = value[0] >> 8
        elif prefix == '=':
            operand = value[0] >> 16
        else:
            operand = value[0] >> 24
        target.CodeByte(int(instructions[1],16))
        target.CodeByte(operand)
        return
        
    # Is it some kind if indirect mode?
    if nowchar == '(':
        assem.IncParsePointer()
        value = assem.EvalExpr()
        if assem.NowChar() == ')':
            # It must be (ZP),Y mode now, or is it JMP (IND) ?
            # On the CMOS models it can also be (ZP)
            assem.IncParsePointer()
            if assem.MoreParameters():
                # It must be (zp),y now
                opcode = int(instructions[5],16)
                if (opcode != 0) and (assem.NowChar(True).upper() == 'Y'):
                    dec.Asm.Timing = ctimes[5]
                    target.CodeByte(opcode)
                    target.CodeByte(value[0])
                    if dec.Asm.Pass == 2 and ((value[0] >> 8) != 0):
                        errors.DoError('range',False)
                    NoMore()
                    return
                else:
                    errors.DoError('badoper',False)
                
            else:
                # It is (zp), or (abs) in case of JMP now
                opcode = int(instructions[10],16)
                dec.Asm.Timing = ctimes[10]
                if dec.Asm.Mnemonic == "JMP":
                    # It's JMP (IND)
                    target.CodeByte(opcode)
                    target.CodeWord(value[0])
                    if dec.Asm.Pass == 2 and ((value[0] >> 16) != 0):
                        errors.DoError('range', False)
                    if ((value[0] & 255) == 255) and modelindex == 2:
                        # Give warning to user about the 6502 JMP (IND) bug
                        errors.DoWarning('6502bug', False)
                    NoMore()
                    return
                else:
                    # It's (zp) now
                    if ctimes[10] == '00':
                        errors.DoError('badoper', False)
                        return
                    target.CodeByte(opcode)
                    target.CodeByte(value[0])
                    if dec.Asm.Pass == 2 and ((value[0] >> 8) != 0):
                        errors.DoError('range', False)
                    NoMore()
                    return
            return

        # It must be (ZP,X) mode now
        opcode = int(instructions[4],16)
        if (opcode != 0 and ctimes[4] != '0') and assem.MoreParameters() and (assem.NowChar(True).upper() == 'X') and (assem.NowChar(True).upper() == ')'):
            dec.Asm.Timing = ctimes[4]
            target.CodeByte(opcode)
            if dec.Asm.Mnemonic == "JMP":
                target.CodeWord(value[0])
                if dec.Asm.Pass == 2 and ((value[0] >> 16) != 0):
                    errors.DoError('range',False)
            else:
                target.CodeByte(value[0])
                if dec.Asm.Pass == 2 and ((value[0] >> 8) != 0):
                    errors.DoError('range',False)
            NoMore()
        else:
            errors.DoError('badoper',False)
        return
    
    # May now be ZP, ABS, ZP,X ABS,X ZP,Y or ABS,Y
    
    if nowchar in '<>':
        # Forced ZP or ABS prefix given
        prefix = nowchar
        assem.IncParsePointer()
    else:
        prefix = ''     # We have no preference, let the assembler decide

    value = assem.EvalExpr()
    if prefix == '':
        if value[1]:
            # A forward referenced label is used, force absolute mode
            prefix = '>'
        else:
            # Now decide if ZP is still possible
            if (value[0] >> 8) == 0:
                prefix = '<'
            else:
                prefix = '>'
    
    if not (assem.MoreParameters()):
        # It's normal ZP or ABS addressing mode
        if prefix == '<':
            index = 2
        else:
            index = 3
    else:
        # It's ZP or ABS indexed with X or Y now
        nowchar = assem.NowChar(True).upper()
        if nowchar == 'X':
            index = 6
        elif nowchar == 'Y':
            index = 8
        else:
            errors.DoError('badoper',False)
            return
        if prefix == '>':
             index = index + 1

    if prefix == '<' and instructions[index] == '00':
        # ZP wanted, but doesn't exist, use ABS instead
        prefix = '>'
        index = index + 1
        
    if instructions[index] == '00' or ctimes[index] == '0':
        errors.DoError('badoper', False)
        return
        
    target.CodeByte(int(instructions[index],16))
    dec.Asm.Timing = ctimes[index]

    if prefix == '<':
        target.CodeByte(value[0])
        address = value[0] >> 8
    else:
        target.CodeWord(value[0])
        address = value[0] >> 16
        
    if dec.Asm.Mnemonic == 'JSR':
        # See if it's JSR SWEET16
        if dec.Asm.Parse_Line[operandbegin:operandbegin+8].upper() == 'SWEET16 ':
            sweet16 = True
     
    if dec.Asm.Pass == 2 and address != 0:
        errors.DoError('range',False)
    NoMore()
    return

#-----------------------------------------------------------------------------

def BitMan():

    """
    The Bit Manipulation instructions are unique to the CMOS devices.
    Even so, not all devices know them.
    It's up to the user to make sure the device supports these instructions
    or not.
    Two syntax versions exist. One where the bit number is part of the
    mnemonic, and one where the bit number is the first parameter in the
    parameter field.
    """

    global Asm
    
    if modelindex == 2 and (dec.Asm.Mnemonic in ('STZ', 'TRB', 'TSB')):
        errors.DoError('badopco', False)
        return

    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1]
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
    if MissingOperand():
        return

    if len(dec.Asm.Mnemonic) == 3:
        # Alternative syntax used, with separate bit number
        value = assem.EvalExpr()
        if dec.Asm.Pass == 2 and (value[0] >> 3) != 0:
            errors.DoError('range', False)
        opcode = opcode + ((value[0] & 7) << 4)
        
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            return
    
    value = assem.EvalExpr()
    
    if dec.Asm.Pass == 2 and (value[0] >> 8) != 0:
        errors.DoError('range', False)
    
    address = value[0]
    
    if dec.Asm.Mnemonic[0] == 'B':
        # Branch instructions
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            return
        value = assem.EvalExpr()
        offset = value[0] - dec.Asm.BOL_Address - 3

        if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
            errors.DoError('range', False)

        target.CodeByte(opcode)
        target.CodeByte(address)
        target.CodeByte(offset)
        
    else:
        # Set/Reset memory bit instructions
        target.CodeByte(opcode)
        target.CodeByte(address)
        
    NoMore()
        
#-----------------------------------------------------------------------------

def Single16():

    """
    Handle Implied Sweet16 instructions.
    The only difference is that RTN terminates Sweet16 mode.
    """

    global Asm, sweet16
    
    target.CodeByte(int(Sweet16_Mnemonics[dec.Asm.Mnemonic][1],16))
    if dec.Asm.Mnemonic == 'RTN':
        sweet16 = False

#-----------------------------------------------------------------------------

def Branch16():

    """
    Handle branch instructions.
    Displacement is destinaiton - current address - 2
    """

    global Asm

    if MissingOperand():
        return

    value = assem.EvalExpr()
    offset = value[0] - dec.Asm.BOL_Address - 2

    if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
        errors.DoError('range', False)

    target.CodeByte(int(Sweet16_Mnemonics[dec.Asm.Mnemonic][1],16))
    target.CodeByte(offset)
    
    NoMore()
    
#-----------------------------------------------------------------------------

def Sweet16():

    """
    Handle remaining Sweet16 instructions. They all expect a register number,
    some accept an indirect register number. Only the SET instruction also
    expects a 16 bit target address.
    Registers are numbered from 0 to 15. If you want to use R0 to R15 instead
    assign labels to the 16 register numbers.
    """

    global Asm

    if MissingOperand():
        return
    
    if assem.NowChar() == '@':
        assem.IncParsePointer()
        opcode = int(Sweet16_Mnemonics[dec.Asm.Mnemonic][2],16)
    else:
        opcode = int(Sweet16_Mnemonics[dec.Asm.Mnemonic][1],16)
    
    if opcode == 0:
        errors.DoError('badopco', False)
        return
    
    value = assem.EvalExpr()
    if dec.Asm.Pass == 2 and (value[0] >> 4) !=0:
        errors.DoError('range', False)
        
    opcode = opcode + (value[0] & 15)
    
    target.CodeByte(opcode)
    
    if dec.Asm.Mnemonic == 'SET':
        if assem.MoreParameters():
            value = assem.EvalExpr()
            target.CodeWord(value[0])
        else:
            errors.DoError('missoper', False)
            
    NoMore()
      
#-----------------------------------------------------------------------------


if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    

