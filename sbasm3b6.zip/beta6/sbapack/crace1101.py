#------------------------------------------------------------------------------
#
#   crace1101.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   This cross overlay will handle the assembling of ace1101
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target
import crace1202

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags
    
    assem.CheckVersions(crossversion, minversion)
    
    dec.Asm.Instructions = {
        'IFC'   : (crace1202.Inherent, int('19',16), '1'),
        'IFNC'  : (crace1202.Inherent, int('1F',16), '1'),
        'INTR'  : (crace1202.Inherent, int('00',16), '5'),
        'INVC'  : (crace1202.Inherent, int('12',16), '1'),
        'NOP'   : (crace1202.Inherent, int('1C',16), '1'),
        'RC'    : (crace1202.Inherent, int('1E',16), '1'),
        'RET'   : (crace1202.Inherent, int('17',16), '5'),
        'RETI'  : (crace1202.Inherent, int('18',16), '5'),
        'SC'    : (crace1202.Inherent, int('1D',16), '1'),

        'JP'    : (crace1202.Relative, int('C0',16), '1'),
        
        'JMP'   : (crace1202.Jumps, ('24','00'), ('4','')),
        'JSR'   : (crace1202.Jumps, ('23','00'), ('5','')),

        'CLR'   : (crace1202.Singles, ('16','0F','7D'), ('1','1','2')),
        'DEC'   : (crace1202.Singles, ('1A','0C','7B'), ('1','1','2')),
        'INC'   : (crace1202.Singles, ('1B','0D','7C'), ('1','1','2')),
        'RLC'   : (crace1202.Singles, ('15','00','79'), ('1','','2')),
        'RRC'   : (crace1202.Singles, ('13','00','7A'), ('1','','2')),

        'ADC'   : (crace1202.Multiple, ('60','42','02','00','00','00','00'),('2','2','1','','','','')),
        'ADD'   : (crace1202.Multiple, ('66','43','03','00','00','00','00'),('2','2','1','','','','')),
        'AND'   : (crace1202.Multiple, ('61','50','04','00','00','00','00'),('2','2','1','','','','')),
        'IFEQ'  : (crace1202.Multiple, ('65','56','09','00','26','20','00'),('2','2','1','','3','3','')),
        'IFGT'  : (crace1202.Multiple, ('67','55','0A','00','27','00','00'),('2','2','1','','3','','')),
        'IFLT'  : (crace1202.Multiple, ('00','00','00','00','28','00','00'),('','','','','','','')),
        'IFNE'  : (crace1202.Multiple, ('57','54','0B','00','00','00','00'),('2','2','1','','','','')),
        'LD'    : (crace1202.Multiple, ('51','46','0E','52','25','21','22'),('2','2','1','3','3','3','3')),
        'OR'    : (crace1202.Multiple, ('62','44','05','00','00','00','00'),('2','2','1','','','','')),
        'ST'    : (crace1202.Multiple, ('00','47','11','40','00','00','00'),('','2','2','3','','','')),
        'SUBC'  : (crace1202.Multiple, ('63','53','06','00','00','00','00'),('2','2','1','','','','')),
        'XOR'   : (crace1202.Multiple, ('64','45','07','00','00','00','00'),('2','2','1','','','','')),

        'IFBIT' : (crace1202.Bits, ('A0','58','00'),('1','2','')),
        'LDC'   : (crace1202.Bits, ('00','80','00'),('','2','')),
        'RBIT'  : (crace1202.Bits, ('00','68','B8'),('','2','2')),
        'SBIT'  : (crace1202.Bits, ('00','48','B0'),('','2','2')),
        'STC'   : (crace1202.Bits, ('00','88','00'),('','2',''))
        
    }

    dec.Asm.Timing_Length = 1

    dec.Asm.Memory = 0              # Select code memory as default
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = (1 << 12) - 1
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = False
    
    dec.Ace_Maxjmp = int('0FFF',16)
    dec.Ace_Minjmp = int('0C00',16)

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    return False     # No extra directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    return
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)
    
#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    
