#------------------------------------------------------------------------------
#
#   cr68hc08.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   This cross overlay will handle the assembling of 68HC08
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    """
    Initialize this cross overlay.
    """

    global Asm, Flags
    
    assem.CheckVersions(crossversion, minversion)

    dec.Asm.Instructions = {
        'ASLA' : (Implied,'48','1'),
        'ASLX' : (Implied,'58','1'),
        'ASRA' : (Implied,'47','1'),
        'ASRX' : (Implied,'57','1'),
        'CLC'  : (Implied,'98','1'),
        'CLI'  : (Implied,'9A','2'),
        'CLRA' : (Implied,'4F','1'),
        'CLRX' : (Implied,'5F','1'),
        'CLRH' : (Implied,'8C','1'),
        'COMA' : (Implied,'43','1'),
        'COMX' : (Implied,'53','1'),
        'DAA'  : (Implied,'72','2'),
        'DECA' : (Implied,'4A','1'),
        'DECX' : (Implied,'5A','1'),
        'DEX'  : (Implied,'5A','1'),
        'DIV'  : (Implied,'52','7'),
        'INCA' : (Implied,'4C','1'),
        'INCX' : (Implied,'5C','1'),
        'INX'  : (Implied,'5C','1'),
        'LSLA' : (Implied,'48','1'),
        'LSLX' : (Implied,'58','1'),
        'LSRA' : (Implied,'44','1'),
        'LSRX' : (Implied,'54','1'),
        'MUL'  : (Implied,'42','5'),
        'NEGA' : (Implied,'40','1'),
        'NEGX' : (Implied,'50','1'),
        'NOP'  : (Implied,'9D','1'),
        'NSA'  : (Implied,'62','3'),
        'PSHA' : (Implied,'87','2'),
        'PSHH' : (Implied,'8B','2'),
        'PSHX' : (Implied,'89','2'),
        'PULA' : (Implied,'86','2'),
        'PULH' : (Implied,'8A','2'),
        'PULX' : (Implied,'88','2'),
        'ROLA' : (Implied,'49','1'),
        'ROLX' : (Implied,'59','1'),
        'RORA' : (Implied,'46','1'),
        'RORX' : (Implied,'56','1'),
        'RSP'  : (Implied,'9C','1'),
        'RTI'  : (Implied,'80','7'),
        'RTS'  : (Implied,'81','4'),
        'SEC'  : (Implied,'99','1'),
        'SEI'  : (Implied,'9B','2'),
        'STOP' : (Implied,'8E','1'),
        'SWI'  : (Implied,'83','9'),
        'TAP'  : (Implied,'84','2'),
        'TAX'  : (Implied,'97','1'),
        'TPA'  : (Implied,'85','1'),
        'TSTA' : (Implied,'4D','1'),
        'TSTX' : (Implied,'5D','1'),
        'TSX'  : (Implied,'95','2'),
        'TXA'  : (Implied,'9F','1'),
        'TXS'  : (Implied,'94','2'),
        'WAIT' : (Implied,'8F','1'),

        'BCC'  : (Branch,'24','3'),
        'BCS'  : (Branch,'25','3'),
        'BEQ'  : (Branch,'27','3'),
        'BGE'  : (Branch,'90','3'),
        'BGT'  : (Branch,'92','3'),
        'BHCC' : (Branch,'28','3'),
        'BHCS' : (Branch,'29','3'),
        'BHI'  : (Branch,'22','3'),
        'BHS'  : (Branch,'24','3'),
        'BIH'  : (Branch,'2F','3'),
        'BIL'  : (Branch,'2E','3'),
        'BLE'  : (Branch,'93','3'),
        'BLO'  : (Branch,'25','3'),
        'BLS'  : (Branch,'23','3'),
        'BLT'  : (Branch,'91','3'),
        'BMC'  : (Branch,'2C','3'),
        'BMI'  : (Branch,'2B','3'),
        'BMS'  : (Branch,'2D','3'),
        'BNE'  : (Branch,'26','3'),
        'BPL'  : (Branch,'2A','3'),
        'BRA'  : (Branch,'20','3'),
        'BRN'  : (Branch,'21','3'),
        'BSR'  : (Branch,'AD','6'),
        'DBNZA': (Branch,'4B','3'),
        'DBNZX': (Branch,'5B','3'),

        'ADC'  : (Multi,('A9','B9','C9','F9','E9','D9','9EE9','9ED9'),('2','3','4','2','3','4','4','5'),False),
        'ADD'  : (Multi,('AB','BB','CB','FB','EB','DB','9EEB','9EDB'),('2','3','4','2','3','4','4','5'),False),
        'AND'  : (Multi,('A4','B4','C4','F4','E4','D4','9EE4','9ED4'),('2','3','4','2','3','4','4','5'),False),
        'AIS'  : (Multi,('A7','00','00','00','00','00','00','00'),('2','','','','','','',''),False),
        'AIX'  : (Multi,('AF','00','00','00','00','00','00','00'),('2','','','','','','',''),False),
        'ASL'  : (Multi,('00','38','00','78','68','00','9E68','00'),('','4','','3','4','','5',''),False),
        'ASR'  : (Multi,('00','37','00','77','67','00','9E67','00'),('','4','','3','4','','5',''),False),
        'BIT'  : (Multi,('A5','B5','C5','F5','E5','D5','9EE5','9ED5'),('2','3','4','2','3','4','4','5'),False),
        'CLR'  : (Multi,('00','3F','00','7F','6F','00','9E6F','00'),('','3','','2','3','','4',''),False),
        'CMP'  : (Multi,('A1','B1','C1','F1','E1','D1','9EE1','9ED1'),('2','3','4','2','3','4','4','5'),False),
        'COM'  : (Multi,('00','33','00','73','63','00','9E63','00'),('','4','','3','4','','5',''),False),
        'CPHX' : (Multi,('65','75','00','00','00','00','00','00'),('3','4','','','','','',''),True),
        'CPX'  : (Multi,('A3','B3','C3','F3','E3','D3','9EE3','9ED3'),('2','3','4','2','3','4','4','5'),False),
        'DEC'  : (Multi,('00','3A','00','7A','6A','00','9E6A','00'),('','4','','3','4','','5',''),False),
        'EOR'  : (Multi,('A8','B8','C8','F8','E8','D8','9EE8','9ED8'),('2','3','4','2','3','4','4','5'),False),
        'INC'  : (Multi,('00','3C','00','7C','6C','00','9E6C','00'),('','4','','3','4','','5',''),False),
        'JMP'  : (Multi,('00','BC','CC','FC','EC','DC','00','00'),('','2','3','2','3','4','',''),False),
        'JSR'  : (Multi,('00','BD','CD','FD','ED','DD','00','00'),('','4','5','4','5','6','',''),False),
        'LDA'  : (Multi,('A6','B6','C6','F6','E6','D6','9EE6','9ED6'),('2','3','4','2','3','4','4','5'),False),
        'LDHX' : (Multi,('45','55','00','00','00','00','00','00'),('3','4','','','','','',''),True),
        'LDX'  : (Multi,('AE','BE','CE','FE','EE','DE','9EEE','9EDE'),('2','3','4','2','3','4','4','5'),False),
        'LSL'  : (Multi,('00','38','00','78','68','00','9E68','00'),('','4','','3','4','','5',''),False),
        'LSR'  : (Multi,('00','34','00','74','64','00','9E64','00'),('','4','','3','4','','5',''),False),
        'NEG'  : (Multi,('00','30','00','70','60','00','9E60','00'),('','4','','3','4','','5',''),False),
        'ORA'  : (Multi,('AA','BA','CA','FA','EA','DA','9EEA','9EDA'),('2','3','4','2','3','4','4','5'),False),
        'ROL'  : (Multi,('00','39','00','79','69','00','9E69','00'),('','4','','3','4','','5',''),False),
        'ROR'  : (Multi,('00','36','00','76','66','00','9E66','00'),('','4','','3','4','','5',''),False),
        'SBC'  : (Multi,('A2','B2','C2','F2','E2','D2','9EE2','9ED2'),('2','3','4','2','3','4','4','5'),False),
        'STA'  : (Multi,('00','B7','C7','F7','E7','D7','9EE7','9ED7'),('','3','4','2','3','4','4','5'),False),
        'STHX' : (Multi,('00','35','00','00','00','00','00','00'),('','4','','','','','',''),False),
        'STX'  : (Multi,('00','BF','CF','FF','EF','DF','9EEF','9EDF'),('','3','4','2','3','4','4','5'),False),
        'SUB'  : (Multi,('A0','B0','C0','F0','E0','D0','9EE0','9ED0'),('2','3','4','2','3','4','4','5'),False),
        'TST'  : (Multi,('00','3D','00','7D','6D','00','9E6D','00'),('','3','','2','3','','4',''),False),

        'BCLR' : (Bits,'11','4'),
        'BSET' : (Bits,'10','4'),
        'BRCLR': (Bits,'01','5'),
        'BRSET': (Bits,'00','5'),
        
        'MOV'  : (Move,('6E','4E','7E','5E'),('4','5','4','4')),

        'CBEQ' : (CompBranch, ('31','71','61','9E61'),('5','4','5','6')),
        'CBEQA': (CompBranch, '41','4'),
        'CBEQX': (CompBranch, '51','4'),
        'DBNZ' : (CompBranch, ('3B','7B','6B','9E6B'),('5','4','5','6'))
    }

    dec.Asm.Timing_Length = 1

    dec.Asm.Memory = 0
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = dec.MAX16
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = True

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    """
    No extra directives for this Cross overlay
    """

    return False     # We didn't handle any directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    """
    No need to do any cleaning.
    """

    return    
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    """
    Find and decode the current mnemonic.
    """

    global Asm

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def MissingOperand():

    """
    An operand must follow. Raise an error if it's not.
    """
    
    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    """
    No more operands shoudl follow. Raise a warning if more parameters follow.
    """

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)
        
#-----------------------------------------------------------------------------

def Implied():

    """
    Handle implied addressing mode.
    Simply save the opcode and we're done with it.
    """

    global Asm

    opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16)
    Code(opcode)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

#-----------------------------------------------------------------------------

def Branch():

    """
    Handle branch instructions.
    Displacement is destinaiton - current address - 2
    """

    global Asm

    if MissingOperand():
        return

    value = assem.EvalExpr()
    offset = value[0] - dec.Asm.BOL_Address - 2
    
    if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
        errors.DoError('range', False)

    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16))
    target.CodeByte(offset)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
    NoMore()

#-----------------------------------------------------------------------------

def Multi():

    """
    Handle multiple operand type instructions
    - Immediate mode
    - Direct page mode
    - Extended mode
    - 0,X mode
    - Direct,X mode
    - Extended,X mode
    - Direct,SP mode
    - Extended,SP mode
    """
    
    global Asm

    if MissingOperand():
        return

    if assem.NowChar() in '#/=\\':
        # It is direct addressing mode
        prefix = assem.NowChar(True)
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][0]
        if opcode == '00':
            errors.DoError('badoper', False)
            return
        
        value = assem.EvalExpr()[0]
        if prefix == '/':
            value = value >> 8
        elif prefix == '=':
            value = value >> 16
        elif prefix == '\\':
            value = value >> 24
        
        Code(int(opcode,16))
        if dec.Asm.Instructions[dec.Asm.Mnemonic][3]:
            target.CodeWord(value)
        else:
            target.CodeByte(value)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        
        NoMore()
        return
    
    if assem.NowChar() == ',':
        # zero offset indexed mode
        value = 0
        length = 0
        assem.MoreParameters()
        indexreg = assem.GetWord().upper()
        if indexreg == 'X':
            # Use 0 offset X mode
            index = 3
        elif indexreg == 'SP':
            # Use 8 bit offset SP mode
            index = 6
            length = 1
        else:
            errors.DoError('badoper', False)
            return

    elif dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper() == 'X ':
        # Zero offset indexed X mode
        value = 0
        length = 0
        index = 3
        assem.IncParsePointer()
        
    elif dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+3].upper() == 'SP ':
        # Zero offset indexed Y mode
        value = 0
        length = 1
        index = 6
        dec.Asm.Parse_Pointer = dec.Asm.Parse_Pointer + 2

    else:
        # Can be direct mode, extended mode or offset,indexed mode from here
        prefix = ''
        if assem.NowChar() in '<>':
            prefix = assem.NowChar(True)
        
        dest = assem.EvalExpr()
        value = dest[0]
        
        if assem.MoreParameters():
            # Handle indexed mode
            indexreg = assem.GetWord().upper()
            if indexreg == 'X':
                index = 4
            elif indexreg == 'SP':
                index = 6
            else:
                errors.DoError('badoper', False)
                return

            if prefix == '>':
                # Forced extended mode
                if dec.Asm.Instructions[dec.Asm.Mnemonic][1][index+1] == '00':
                    # Extended mode doesn't exist, use direct mode instead
                    length = 1
                else:
                    index = index + 1
                    length = 2
            elif prefix == '<':
                # Forced direct mode
                length = 1
            else:
                # Let the assembler deside whether it's direct or extended
                if dest[1]:
                    # Forward referenced label used, use extended
                    if dec.Asm.Instructions[dec.Asm.Mnemonic][1][index+1] == '00':
                        # Extended mode doesn't exist, use direct mode instead
                        length = 1
                    else:
                        length = 2
                        index = index + 1
                else:
                   if value == 0 and index == 4:
                       # 0 offset and X index, use special opcode if it exists
                       if dec.Asm.Instructions[dec.Asm.Mnemonic][1][index-1] == '00':
                           # Sorry, doesn't exist
                           length = 1
                       else:
                           length = 0
                           index = index - 1
                   elif value > 255:
                       # We should use extended indexed mode
                       if dec.Asm.Instructions[dec.Asm.Mnemonic][1][index+1] == '00':
                           # But that doesn't exist
                           errors.DoError('range', False)
                           return
                       index = index + 1
                       length = 2
                   else:
                       # We can use Direct mode
                       length = 1
                                
        else:
            # Direct or extended mode
            if prefix == '>':
                # Forced extended mode
                if dec.Asm.Instructions[dec.Asm.Mnemonic][1][2] == '00':
                    # Extended mode doesn't exist, use direct mode instead
                    index = 1
                    length = 1
                else:
                    # Extended mode exists, feel free to use it
                    index = 2
                    length = 2
            elif prefix == '<':
                # Forced direct mode
                index = 1
                length = 1
            else:
                # Let the assembler deside whether it's direct or extended
                if dest[1]:
                    # Forward referenced label used, use extended
                    if dec.Asm.Instructions[dec.Asm.Mnemonic][1][2] == '00':
                        # Extended mode doesn't exist, use direct mode instead
                        index = 1
                        length = 1
                    else:
                        # Extended mode does exist, feel free to use it
                        index = 2
                        length = 2
                else:
                    if value > 255:
                        index = 2
                        length = 2
                    else:
                        index = 1
                        length = 1

            if dec.Asm.Pass == 2 and length == 1:
                # We are using direct mode, does the value fit?
                if value >= 255:
                    errors.DoError('range', False)
            if dec.Asm.Pass == 2 and value < 0:
                # Negative numbers not allowed
                errors.DoError('range', False)

    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][index]
    if opcode == '00':
        errors.DoError('badoper', False)
        return
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
    Code(int(opcode,16))
    
    if length == 1:
        target.CodeByte(value)
    elif length == 2:
        target.CodeWord(value)
        
    NoMore()

#-----------------------------------------------------------------------------

def Bits():

    """
    Handle Bit instructions
    Both bit set/clr as well as branch bit set/clr instructions are handled
    by this routine.
    """

    global Asm

    if MissingOperand():
        return
        
    bitno = assem.EvalExpr()[0]
    opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16) + ((bitno & 7) << 1)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
    if not assem.MoreParameters():
        # We expected more parameters        errors.DoError('missoper', False)
        return

    mem = assem.EvalExpr()[0]
    
    if dec.Asm.Mnemonic[1] == 'R':
        # It's a branch instruction
        if not assem.MoreParameters():
            # We expected more parameters            errors.DoError('missoper', False)            return

        dest = assem.EvalExpr()[0]
        offset = dest - dec.Asm.BOL_Address - 3
        
        target.CodeByte(opcode)
        target.CodeByte(mem)
        target.CodeByte(offset)
        if dec.Asm.Pass == 2 and (offset < -128 or offset > +127):
            errors.DoError('range',False)
    
    else:
        # It wasn't a branch instruction
        target.CodeByte(opcode)
        target.CodeByte(mem)
    
    if dec.Asm.Pass == 2:
        if (bitno < 0 or bitno > 7) or (mem < 0 or mem > 255):
            errors.DoError('range',False)
        
    NoMore()

#-----------------------------------------------------------------------------
def Move():

    """
    MOV instruction
    - #,dir
    - dir,dir
    - X+,dir
    - dir,X+
    """
    
    global Asm
    
    if MissingOperand():
        return

    if assem.NowChar() in '#/=\\':
        # It is direct addressing mode
        prefix = assem.NowChar(True)
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        
        value = assem.EvalExpr()[0]
        if prefix == '/':
            value = value >> 8
        elif prefix == '=':
            value = value >> 16
        elif prefix == '\\':
            value = value >> 24

        if not assem.MoreParameters():
            # We expected more parameters            errors.DoError('missoper', False)
            return
        
        dest = assem.EvalExpr()[0]
        
        Code(opcode)
        target.CodeByte(value)
        target.CodeByte(dest)
        
    elif dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+3].upper() == 'X+,':
        # X+,dir
        assem.GetWord()
        assem.MoreParameters()
        
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
        
        dest = assem.EvalExpr()[0]
        
        Code(opcode)
        target.CodeByte(dest)

    else:
        # Can now be dir,dir or dir,X+
        source = assem.EvalExpr()[0]

        if not assem.MoreParameters():
            # We expected more parameters            errors.DoError('missoper', False)
            return

        if dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+3].upper() == 'X+ ':
            # It is dir,X+
            assem.GetWord()
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][3],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][3]
            
            dest = source
            
            Code(opcode)
            target.CodeByte(dest)
        else:
            # It is dir,dir
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
            dest = assem.EvalExpr()[0]
            
            Code(opcode)
            target.CodeByte(source)
            target.CodeByte(dest)
        
    if dec.Asm.Pass == 2 and (dest < 0 or dest > 255):
        errors.DoError('range', False)
        
    NoMore()

#-----------------------------------------------------------------------------
def CompBranch():

    """
    Compare and Branch instructions
    - dir,rel
    - X+,rel
    - dir,X+,rel
    - dir,SP,rel
    """
    
    global Asm

    if MissingOperand():
        return
        
    if dec.Asm.Mnemonic[0] == 'D':
        indexreg = 'X,'
    else:
        indexreg = 'X+,'

    if len(dec.Asm.Mnemonic) == 5:
        if not assem.NowChar() in '#/=\\':
            # Should start with immediate prefix
            errors.DoError('badoper', False)
            return

        prefix = assem.NowChar(True)
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
        
        value = assem.EvalExpr()[0]
        if prefix == '/':
            value = value >> 8
        elif prefix == '=':
            value = value >> 16
        elif prefix == '\\':
            value = value >> 24

        if not assem.MoreParameters():
            # We expected more parameters            errors.DoError('missoper', False)
            return
        
        dest = assem.EvalExpr()[0]
        offset = dest - dec.Asm.BOL_Address - 3
        
        Code(opcode)
        target.CodeByte(value)
        target.CodeByte(offset)
        
        value = 0
        
    elif dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+len(indexreg)].upper() == indexreg:
        # It is X+,rel now

        assem.GetWord()

        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
        
        if not assem.MoreParameters():
            # We expected more parameters            errors.DoError('missoper', False)
            return
        
        dest = assem.EvalExpr()[0]
        offset = dest - dec.Asm.BOL_Address - 2
        
        Code(opcode)
        target.CodeByte(offset)
        
        value = 0
    
    else:
        value = assem.EvalExpr()[0]
        
        if not assem.MoreParameters():
            # We expected more parameters            errors.DoError('missoper', False)
            return
        
        if dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+len(indexreg)].upper() == indexreg:
            # It is dir,X+,rel
            assem.GetWord()
            if not assem.MoreParameters():
                # We expected more parameters
                errors.DoError('missoper', False)
                return
            
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
        
            dest = assem.EvalExpr()[0]
            offset = dest - dec.Asm.BOL_Address - 3

        elif dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+3].upper() == 'SP,':
            # It is dir,SP,rel
            assem.GetWord()
            if not assem.MoreParameters():
                # We expected more parameters
                errors.DoError('missoper', False)
                return
            
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][3],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][3]

            dest = assem.EvalExpr()[0]
            offset = dest - dec.Asm.BOL_Address - 4

        else:
            # It is dir,rel now
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        
            dest = assem.EvalExpr()[0]
            offset = dest - dec.Asm.BOL_Address - 3

        Code(opcode)
        target.CodeByte(value)        
        target.CodeByte(offset)

    if dec.Asm.Pass == 2 and (offset < -128 or offset > +127 or value < 0 or value > 255):
        # Range error if offset too big or not direct page address
        errors.DoError('range', False)
    
    NoMore()
        
#-----------------------------------------------------------------------------

def Code(opcode):

    """
    Write an opcode to the target file.
    If the opcode > 255 then a pre-byte must be saved first
    """
    
    if opcode > 255:
        target.CodeByte(opcode >> 8)
    target.CodeByte(opcode)

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    
