#------------------------------------------------------------------------------
#
#   crst7.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   ST7 Cross Overlay
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags
    
    assem.CheckVersions(crossversion, minversion)
    
    dec.Asm.Instructions = {
    
    # Inherent operand instructions
    'HALT'  : (Inherent, int('8E',16), '2'),
    'IRET'  : (Inherent, int('80',16), '9'),
    'NOP'   : (Inherent, int('9D',16), '2'),
    'RCF'   : (Inherent, int('98',16), '2'),
    'RET'   : (Inherent, int('81',16), '6'),
    'RIM'   : (Inherent, int('9A',16), '2'),
    'RSP'   : (Inherent, int('9C',16), '2'),
    'SCF'   : (Inherent, int('99',16), '2'),
    'SIM'   : (Inherent, int('9B',16), '2'),
    'TRAP'  : (Inherent, int('83',16), '10'),
    'WFI'   : (Inherent, int('8F',16), '2'),

    # 0=#             1=short        2=long          3=(X)       4=(short,X)     5=(long,X)
    # 6=(Y)           7=(short,Y)    8=(long,Y)      9=[short]   10=[long.w]     11=([short],X)
    # 12=([long.w],X) 13=([short],Y) 14=([long.w],Y) 15=A        16=X            17=Y   18=S
    'ADC'   : (Accu,('00A9','00B9','00C9','00F9','00E9','00D9','90F9','90E9','90D9','92B9','92C9','92E9','92D9','91E9','91D9'),
                     ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'6'   ,'7'   ,'6'   ,'7')),
    'ADD'   : (Accu,('00AB','00BB','00CB','00FB','00EB','00DB','90FB','90EB','90DB','92BB','92CB','92EB','92DB','91EB','91DB'),
                     ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'6'   ,'7'   ,'6'   ,'7')),
    'AND'   : (Accu,('00A4','00B4','00C4','00F4','00E4','00D4','90F4','90E4','90D4','92B4','92C4','92E4','92D4','91E4','91D4'),
                     ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'6'   ,'7'   ,'6'   ,'7')),
    'BCP'   : (Accu,('00A5','00B5','00C5','00F5','00E5','00D5','90F5','90E5','90D5','92B5','92C5','92E5','92D5','91E5','91D5'),
                     ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'6'   ,'7'   ,'6'   ,'7')),
    'OR'    : (Accu,('00AA','00BA','00CA','00FA','00EA','00DA','90FA','90EA','90DA','92BA','92CA','92EA','92DA','91EA','91DA'),
                     ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'6'   ,'7'   ,'6'   ,'7')),
    'SBC'   : (Accu,('00A2','00B2','00C2','00F2','00E2','00D2','90F2','90E2','90D2','92B2','92C2','92E2','92D2','91E2','91D2'),
                     ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'6'   ,'7'   ,'6'   ,'7')),
    'SUB'   : (Accu,('00A0','00B0','00C0','00F0','00E0','00D0','90F0','90E0','90D0','92B0','92C0','92E0','92D0','91E0','91D0'),
                     ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'6'   ,'7'   ,'6'   ,'7')),
    'XOR'   : (Accu,('00A8','00B8','00C8','00F8','00E8','00D8','90F8','90E8','90D8','92B8','92C8','92E8','92D8','91E8','91D8'),
                     ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'6'   ,'7'   ,'6'   ,'7')),
   
    'CALL'  : (Single,('0000','00BD','00CD','00FD','00ED','00DD','90FD','90ED','90DD','92BD','92CD','92ED','92DD','91ED','91DD','0000','0000','0000'),
                      ('0'   ,'5'   ,'6'   ,'5'   ,'6'   ,'7'   ,'6'   ,'7'   ,'8'   ,'7'   ,'8'   ,'8'   ,'9'   ,'8'   ,'9'   ,'0'   ,'0'   ,'0')),
    'CLR'   : (Single,('0000','003F','00FF','007F','006F','00FF','907F','906F','00FF','923F','00FF','926F','00FF','916F','00FF','004F','005F','905F'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'CPL'   : (Single,('0000','0033','00FF','0073','0063','00FF','9073','9063','00FF','9233','00FF','9263','00FF','9163','00FF','0043','0053','9053'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'DEC'   : (Single,('0000','003A','00FF','007A','006A','00FF','907A','906A','00FF','923A','00FF','926A','00FF','916A','00FF','004A','005A','905A'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'INC'   : (Single,('0000','003C','00FF','007C','006C','00FF','907C','906C','00FF','923C','00FF','926C','00FF','916C','00FF','004C','005C','905C'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'JP'    : (Single,('0000','00BC','00CC','00FC','00EC','00DC','90FC','90EC','90DC','92BC','92CC','92EC','92DC','91EC','91DC','0000','0000','0000'),
                      ('0'   ,'2'   ,'3'   ,'2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'5'   ,'6'   ,'5'   ,'6'   ,'0'   ,'0'   ,'0')),
    'NEG'   : (Single,('0000','0030','00FF','0070','0060','00FF','9070','9060','00FF','9230','00FF','9260','00FF','9160','00FF','0040','0050','9050'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'RLC'   : (Single,('0000','0039','00FF','0079','0069','00FF','9079','9069','00FF','9239','00FF','9269','00FF','9169','00FF','0049','0059','9059'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'RRC'   : (Single,('0000','0036','00FF','0076','0066','00FF','9076','9066','00FF','9236','00FF','9266','00FF','9166','00FF','0046','0056','9056'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'SLA'   : (Single,('0000','0038','00FF','0078','0068','00FF','9078','9068','00FF','9238','00FF','9268','00FF','9168','00FF','0048','0058','9058'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'SLL'   : (Single,('0000','0038','00FF','0078','0068','00FF','9078','9068','00FF','9238','00FF','9268','00FF','9168','00FF','0048','0058','9058'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'SRA'   : (Single,('0000','0037','00FF','0077','0067','00FF','9077','9067','00FF','9237','00FF','9267','00FF','9167','00FF','0047','0057','9057'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'SRL'   : (Single,('0000','0034','00FF','0074','0064','00FF','9074','9064','00FF','9234','00FF','9264','00FF','9164','00FF','0044','0054','9054'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'SWAP'  : (Single,('0000','003E','00FF','007E','006E','00FF','907E','906E','00FF','923E','00FF','926E','00FF','916E','00FF','004E','005E','905E'),
                      ('0'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'7'   ,'0'   ,'7'   ,'0'   ,'8'   ,'0'   ,'8'   ,'0'   ,'3'   ,'3'   ,'4')),
    'TNZ'   : (Single,('0000','003D','00FF','007D','006D','00FF','907D','906D','00FF','923D','00FF','926D','00FF','916D','00FF','004D','005D','905D'),
                      ('0'   ,'4'   ,'0'   ,'4'   ,'5'   ,'0'   ,'5'   ,'6'   ,'0'   ,'6'   ,'0'   ,'7'   ,'0'   ,'7'   ,'0'   ,'3'   ,'3'   ,'4')),
    
    'LD'    : (LdInst,0),
    
    'CP'    : (CpInst,0),
    
    'BRES'  : (BitInst,('0011','9211'),('5','7')),
    'BSET'  : (BitInst,('0010','9210'),('5','7')),
    'BTJF'  : (BitInst,('0001','9201'),('5','7')),
    'BTJT'  : (BitInst,('0000','9200'),('5','7')),

    'CALLR' : (Branch,('00AD','92AD'),('6','8')),
    'JRA'   : (Branch,('0020','9220'),('3','5')),
    'JRC'   : (Branch,('0025','9225'),('3','5')),
    'JREQ'  : (Branch,('0027','9227'),('3','5')),
    'JRF'   : (Branch,('0021','9221'),('3','5')),
    'JRH'   : (Branch,('0029','9229'),('3','5')),
    'JRIH'  : (Branch,('002F','922F'),('3','5')),
    'JRIL'  : (Branch,('002E','922E'),('3','5')),
    'JRM'   : (Branch,('002D','922D'),('3','5')),
    'JRMI'  : (Branch,('002B','922B'),('3','5')),
    'JRNC'  : (Branch,('0024','9224'),('3','5')),
    'JRNE'  : (Branch,('0026','9226'),('3','5')),
    'JRNH'  : (Branch,('0028','9228'),('3','5')),
    'JRNM'  : (Branch,('002C','922C'),('3','5')),
    'JRPL'  : (Branch,('002A','922A'),('3','5')),
    'JRT'   : (Branch,('0020','9220'),('3','5')),
    'JRUGE' : (Branch,('0024','9224'),('3','5')),
    'JRUGT' : (Branch,('0022','9222'),('3','5')),
    'JRULE' : (Branch,('0023','9223'),('3','5')),
    'JRULT' : (Branch,('0025','9225'),('3','5')),
 
    'POP'   : (Stack,('0084','0085','9085','0086'),('4','4','5','4')),
    'PUSH'  : (Stack,('0088','0089','9089','008A'),('3','3','4','3')),
    
    'MUL'   : (Multiply,('0042','9042'),('11','12'))
    }

    dec.Asm.Timing_Length = 2

    dec.Asm.Memory = 0    
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = dec.MAX16
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = True

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    return False     # No extra directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    return
        
#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)
    
#-----------------------------------------------------------------------------

def MissingOperand():

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)

#-----------------------------------------------------------------------------

def Inherent():

    global Asm

    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
#-----------------------------------------------------------------------------

def Accu():

    global Asm

    if MissingOperand():
        return
        
    if GetOperand()[0] != 15:
        errors.DoError('badoper', False)
        return

    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    operand = GetOperand()
    if operand[0] > 14:
        errors.DoError('badoper', False)
        return

    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][operand[0]]
    timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][operand[0]]
    prebyte = int(opcode[0:2],16)
    opcbyte = int(opcode[2:4],16)
    
    if prebyte != 0:
        target.CodeByte(prebyte)
    target.CodeByte(opcbyte)
    
    if operand[0] in (0,1,4,7,9,10,11,12,13,14):
        target.CodeByte(operand[1])
    elif operand[0] in (2,5,8):
        target.CodeWord(operand[1])
    
    dec.Asm.Timing = timing
    
    NoMore()
    
#-----------------------------------------------------------------------------

def Single():

    global Asm

    if MissingOperand():
        return
        
    operand = GetOperand()
    if operand[0] == 0 or operand[0] > 17:
        errors.DoError('badoper', False)
        return

    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][operand[0]]
    timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][operand[0]]
    prebyte = int(opcode[0:2],16)
    opcbyte = int(opcode[2:4],16)
    dec.Asm.Timing = timing
    
    if opcbyte == 0:
        # Illegal operand
        errors.DoError('badoper', False)
        return
        
    if opcbyte == 255:
        # Range error because LONG is not supported
        errors.DoError('range', False)
        return

    SaveAll(prebyte, opcbyte, operand)
    
#-----------------------------------------------------------------------------

def CpInst():

    global Asm

    if MissingOperand():
        return
        
    operand1 = GetOperand()

    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    operand2 = GetOperand()

    if operand1[0] == 15:
        # CP A,something

        opcode = ('00A1','00B1','00C1','00F1','00E1','00D1','90F1','90E1','90D1','92B1','92C1','92E1','92D1','91E1','91D1')
        timing = ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'6'   ,'7'   ,'6'   ,'7')
    
    elif operand1[0] == 16:
        # CP X,something

        opcode = ('00A3','00B3','00C3','00F3','00E3','00D3','0000','0000','0000','92B3','92C3','92E3','92D3','0000','0000')
        timing = ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'0'   ,'0'   ,'0'   ,'5'   ,'6'   ,'6'   ,'7'   ,'0'   ,'0')
    
    elif operand1[0] == 17:
        # CP Y,something

        opcode = ('90A3','90B3','90C3','0000','0000','0000','90F3','90E3','90D3','91B3','91C3','0000','0000','91E3','91D3')
        timing = ('3'   ,'4'   ,'5'   ,'0'   ,'0'   ,'0'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'0'   ,'0'   ,'6'   ,'7')
        
    else:
        errors.DoError('badoper', False)
        return
        
    if operand2[0] > 14:
        errors.DoError('badoper', False)
        return
    
    prebyte = int(opcode[operand2[0]][0:2],16)
    opcbyte = int(opcode[operand2[0]][2:4],16)
    dec.Asm.Timing = timing[operand2[0]]

    SaveAll(prebyte, opcbyte, operand2)
    
#-----------------------------------------------------------------------------

def LdInst():

    global Asm

    if MissingOperand():
        return
        
    operand1 = GetOperand()

    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    operand2 = GetOperand()

    if operand1[0] == 15:
        # LD A,something
        opcode = ('00A6','00B6','00C6','00F6','00E6','00D6','90F6','90E6','90D6','92B6','92C6','92E6','92D6','91E6','91D6','0000','009F','909F','009E')
        timing = ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'6'   ,'7'   ,'6'   ,'7'   ,'0'   ,'2'   ,'3'   ,'2')

        operand = operand2

    elif operand2[0] == 15:
        # LD something,A
        
        opcode = ('0000','00B7','00C7','00F7','00E7','00D7','90F7','90E7','90D7','92B7','92C7','92E7','92D7','91E7','91D7','0000','0097','9097','0095')
        timing = ('0'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'7'   ,'6'   ,'7'   ,'7'   ,'8'   ,'7'   ,'8'   ,'0'   ,'2'   ,'3'   ,'2')

        operand = operand1

    elif operand1[0] == 16:
        # LD X,something
        
        opcode = ('00AE','00BE','00CE','00FE','00EE','00DE','0000','0000','0000','92BE','92CE','92EE','92DE','0000','0000','0097','0000','0093','0096')
        timing = ('2'   ,'3'   ,'4'   ,'3'   ,'4'   ,'5'   ,'0'   ,'0'   ,'0'   ,'5'   ,'6'   ,'6'   ,'7'   ,'0'   ,'0'   ,'2'   ,'0'   ,'2'   ,'2')

        operand = operand2

    elif operand2[0] == 16:
        # LD something,X
        
        opcode = ('0000','00BF','00CF','00FF','00EF','00DF','0000','0000','0000','92BF','92CF','92EF','92DF','0000','0000','009F','0000','9093','0094')
        timing = ('0'   ,'4'   ,'5'   ,'4'   ,'5'   ,'6'   ,'0'   ,'0'   ,'0'   ,'6'   ,'7'   ,'7'   ,'8'   ,'0'   ,'0'   ,'2'   ,'0'   ,'3'   ,'2')
        
        operand = operand1
    
    elif operand1[0] == 17:
        # LD Y,something
        
        opcode = ('90AE','90BE','90CE','0000','0000','0000','90FE','90EE','90DE','91BE','91CE','0000','0000','91EE','91DE','9097','0093','0000','9096')
        timing = ('3'   ,'4'   ,'5'   ,'0'   ,'0'   ,'0'   ,'4'   ,'5'   ,'6'   ,'5'   ,'6'   ,'0'   ,'0'   ,'6'   ,'7'   ,'3'   ,'2'   ,'0'   ,'3')
        
        operand = operand2
    
    elif operand2[0] == 17:
        # LD something,Y
        
        opcode = ('0000','90BF','90CF','0000','0000','0000','90FF','90EF','90DF','91BF','91CF','0000','0000','91EF','91DF','909F','0093','0000','9094')
        timing = ('0'   ,'5'   ,'6'   ,'0'   ,'0'   ,'0'   ,'5'   ,'6'   ,'7'   ,'6'   ,'7'   ,'0'   ,'0'   ,'7'   ,'8'   ,'3'   ,'2'   ,'0'   ,'3')
        
        operand = operand1
        
    # Don't bother about LD S,something and LD something,S because those have been done by the others

    prebyte = int(opcode[operand[0]][0:2],16)
    opcbyte = int(opcode[operand[0]][2:4],16)
    dec.Asm.Timing = timing[operand[0]]

    SaveAll (prebyte, opcbyte, operand)

#-----------------------------------------------------------------------------

def BitInst():

    global Asm

    if MissingOperand():
        return

    operand1 = GetOperand()

    if operand1[0] != 1 and operand1[0] != 9:
        errors.DoError('badoper', False)
        return
    
    if operand1[0] == 1:
        # Bit SHORT, something
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][0]
        timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        
    else:
        # Bit [IND], something
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][1]
        timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]

    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    operand2 = GetOperand()
    
    if operand2[0] != 0:
        errors.DoError('badoper', False)
        return
        
    if dec.Asm.Pass == 2 and operand2[1] >> 3 != 0:
        errors.DoError('range', False)

    prebyte = int(opcode[0:2],16)
    opcbyte = int(opcode[2:4],16)
    dec.Asm.Timing = timing
    
    if opcode[2] == '1':
        # It's not a BIT test/branch instruction
        if prebyte != 0:
            target.CodeByte(prebyte)
        target.CodeByte(opcbyte + ((operand2[1] & 7) << 1))
        target.CodeByte(operand1[1])
    
    else:
        # It's a BIT test/branch instruction, get operand 3
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            return
        
        operand3 = GetOperand()
        
        if operand3[0] != 1 and operand3[0] != 2:
            errors.DoError('badoper', False)
            return

        if prebyte == 0:
            offset = operand3[1] - dec.Asm.BOL_Address - 3
        else:
            offset = operand3[1] - dec.Asm.BOL_Address - 4

        if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
            errors.DoError('range', False)
        
        if prebyte != 0:
            target.CodeByte(prebyte)
        target.CodeByte(opcbyte + ((operand2[1] & 7) << 1))
        target.CodeByte(operand1[1])
        target.CodeByte(offset)
        
    NoMore()

#-----------------------------------------------------------------------------

def Branch():

    global Asm

    if MissingOperand():
        return
        
    operand = GetOperand()
    
    if operand[0] == 1 or operand[0] == 2:
        # Branch relative
        offset = operand[1] - dec.Asm.BOL_Address - 2

        if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
            errors.DoError('range', False)
        
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16))
        target.CodeByte(offset)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
    
    elif operand[0] == 9:
        # Branch [indirect]
        
        target.CodeWord(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16))
        target.CodeByte(operand[1])
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
    
    else:
        errors.DoError('badoper', False)
        return

    NoMore()

#-----------------------------------------------------------------------------

def Stack():

    global Asm

    if MissingOperand():
        return

    operand = assem.GetWord().upper()

    if operand == 'A':
        index = 0
    elif operand == 'X':
        index = 1
    elif operand == 'Y':
        index = 2
    elif operand == 'CC':
        index = 3
    else:
        errors.DoError('badoper', False)
        return
            
    opcode = (int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16))
    if opcode > 255:
        target.CodeWord(opcode)
    else:
        target.CodeByte(opcode)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
        
    NoMore()

#-----------------------------------------------------------------------------

def Multiply():

    global Asm
    
    if MissingOperand():
        return

    operand1 = assem.GetWord().upper()
    
    if not operand1 in 'XY':
        errors.DoError('badoper', False)
        return
        
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    if assem.NowChar(True).upper() != 'A':
        errors.DoError('badoper', False)
        return
        
    if operand1 == 'X':
        target.CodeByte (int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
    else:
        target.CodeWord (int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
        
    NoMore()

#-----------------------------------------------------------------------------

def SaveAll(prebyte, opcode, operand):

    if opcode == 0:
        errors.DoError('badoper', False)
        return

    if prebyte != 0:
        target.CodeByte(prebyte)
    target.CodeByte(opcode)
    
    if operand[0] in (0,1,4,7,9,10,11,12,13,14):
        target.CodeByte(operand[1])
    elif operand[0] in (2,5,8):
        target.CodeWord(operand[1])
    
    NoMore()

#-----------------------------------------------------------------------------

def GetOperand():

    """
    Get an operand. This can get complicated.
    Operand can be:
    Index =  0: #
    Index =  1: SHORT
    Index =  2: LONG
    Index =  3: (X)
    Index =  4: (SHORT,X)
    Index =  5: (LONG,X)
    Index =  6: (Y)
    Index =  7: (SHORT,Y)
    Index =  8: (LONG,Y)
    Index =  9: [SHORT]
    Index = 10: [LONG.W]
    Index = 10: {LONG}
    Index = 11: ([SHORT],X)
    Index = 12: ([LONG.W],X)
    Index = 12: ({LONG},X)
    Index = 13: ([SHORT],Y)
    Index = 14: ([LONG.W],Y)
    Index = 14: ({LONG},Y)
    Index = 15: A
    Index = 16: X
    Index = 17: Y
    Index = 18: S
    """

    global Asm
    
    pntr = dec.Asm.Parse_Pointer
    
    operand = assem.GetWord().upper()
    if operand == 'A':
        return (15, 0)
    if operand == 'X':
        return (16, 0)
    if operand == 'Y':
        return (17, 0)
    if operand == 'S':
        return (18, 0)
    if operand == '(X)':
        return (3, 0)
    if operand == '(Y)':
        return (6, 0)
        
    dec.Asm.Parse_Pointer = pntr
    
#----------
        
    if operand[0] in '#/=\\':
        # Immediate value
        mode = assem.NowChar(True)
        value = assem.EvalExpr()
        if mode == '#':
            return (0, value[0])
        if mode == '/':
            return (0, value[0] >> 8)
        if mode == '=':
            return (0, value[0] >> 16)
        return (0, value[0] >> 24)
    
#----------
        
    if operand[0:2] == '([':
        # Some form of Indexed Indirect mode
        
        assem.IncParsePointer()
        assem.IncParsePointer()
        
        pntr = dec.Asm.Parse_Pointer
        line = dec.Asm.Parse_Line
        operand = assem.GetWord('','',']').upper()
        endpnt = dec.Asm.Parse_Pointer
        dec.Asm.Parse_Pointer = pntr
        short = True
        if operand[-2:] == '.W':
            short = False
            dec.Asm.Parse_Line = line[:endpnt-2] + ' '
        
        value = assem.EvalExpr()
        dec.Asm.Parse_Line = line
        dec.Asm.Parse_Pointer = endpnt
        
        if assem.NowChar(True) != ']':
            errors.DoError('badoper', False)
            
        if not assem.MoreParameters():
            errors.DoError('missoper', False)

        nowchar = assem.NowChar(True).upper()
        if nowchar == 'X':
            xymode = 11
        elif nowchar == 'Y':
            xymode = 13
        else:
            xymode = 11
            errors.DoError('badoper', False)
            
        if assem.NowChar(True) != ')':
            errors.DoError('badoper', False)
        
        if dec.Asm.Pass == 2 and (value[0] >> 8 != 0):
            errors.DoError('range', False)
              
        if short:
            return (xymode+0,value[0])
        else:
            return (xymode+1,value[0])
        
#----------
        
    if operand[0:2] == '({':
        # Indexed Indirect long mode

        assem.IncParsePointer()
        assem.IncParsePointer()
        value = assem.EvalExpr()
        if assem.NowChar(True) != '}':
            errors.DoError('badoper', False)

        if not assem.MoreParameters():
            errors.DoError('missoper', False)

        nowchar = assem.NowChar(True).upper()
        if nowchar == 'X':
            xymode = 12
        elif nowchar == 'Y':
            xymode = 14
        else:
            xymode = 12
            errors.DoError('badoper', False)
            
        if assem.NowChar(True) != ')':
            errors.DoError('badoper', False)

        if dec.Asm.Pass == 2 and (value[0] >> 8 != 0):
            errors.DoError('range', False)
        
        return (xymode,value[0])

#----------
        
    if operand[0] == '(':
        # Some form of indexed mode.
        # It can be short or long, followed by ,X) or ,Y)
        
        assem.IncParsePointer()

        prefix = ''
        if operand[0] in '<>':
            # It's forced long or short
            prefix = assem.NowChar(True)
        
        value = assem.EvalExpr()

        if prefix == '<':
            short = True
            if dec.Asm.Pass == 2 and (value[0] >> 8) != 0:
                errors.DoError('range', False)
        elif prefix == '>' or value[1]:
            short = False
        else:
            short = False
            if (value[0] >> 8) == 0:
                short = True

        if not assem.MoreParameters():
            errors.DoError('missoper', False)
        
        nowchar = assem.NowChar(True).upper()
        if nowchar == 'X':
            xymode = 4
        elif nowchar == 'Y':
            xymode = 7
        else:
            xymode = 4
            errors.DoError('badoper', False)
            
        if assem.NowChar(True) != ')':
            errors.DoError('badoper', False)

        if short:
            return (xymode+0,value[0])
        else:
            return (xymode+1,value[0])

#----------
       
    if operand[0] == '[':
        # Some form of indirect mode, could be [short] or [long.w]
        
        assem.IncParsePointer()
        pntr = dec.Asm.Parse_Pointer
        line = dec.Asm.Parse_Line
        operand = assem.GetWord('','',']').upper()
        endpnt = dec.Asm.Parse_Pointer
        dec.Asm.Parse_Pointer = pntr
        short = True
        if operand[-2:] == '.W':
            short = False
            dec.Asm.Parse_Line = line[:endpnt-2] + ' '
        
        value = assem.EvalExpr()
        dec.Asm.Parse_Line = line
        dec.Asm.Parse_Pointer = endpnt
        
        if assem.NowChar(True) != ']':
            errors.DoError('badoper', False)
            
        if dec.Asm.Pass == 2 and (value[0] >> 8 != 0):
            errors.DoError('range', False)
              
        if short:
            return (9,value[0])
        else:
            return (10,value[0])
        
#----------
        
    if operand[0] == '{':
        # Indirect LONG mode
        
        assem.IncParsePointer()
        value = assem.EvalExpr()
        if assem.NowChar(True) != '}':
            errors.DoError('badoper', False)
        
        if dec.Asm.Pass == 2 and (value[0] >> 8 != 0):
            errors.DoError('range', False)
              
        return (10,value[0])
        
#----------
        
    # Here only short or long mode option left.
    # Must decide whether to use short or long, depending on address size
    
    prefix = ''
    if operand[0] in '<>':
        # It's forced long or short
        prefix = assem.NowChar(True)
    
    value = assem.EvalExpr()

    if prefix == '<':
        short = True
        if dec.Asm.Pass == 2 and (value[0] >> 8) != 0:
            errors.DoError('range', False)
    elif prefix == '>' or value[1]:
        short = False
    else:
        short = False
        if (value[0] >> 8) == 0:
            short = True

    if short:
        return (1,value[0])
    else:
        return (2,value[0])

#-----------------------------------------------------------------------------


if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    
#-----------------------------------------------------------------------------

