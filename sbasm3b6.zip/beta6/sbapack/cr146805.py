#------------------------------------------------------------------------------
#
#   cr146805.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   This cross overlay will handle the assembling of 146805
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target
import cr68hc05

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    """
    Initialize this cross overlay.
    """

    global Asm, Flags
    
    assem.CheckVersions(crossversion, minversion)

    dec.Asm.Instructions = {
        'ASLA' : (cr68hc05.Implied,'48','3'),
        'ASLX' : (cr68hc05.Implied,'58','3'),
        'ASRA' : (cr68hc05.Implied,'47','3'),
        'ASRX' : (cr68hc05.Implied,'57','3'),
        'CLC'  : (cr68hc05.Implied,'98','2'),
        'CLI'  : (cr68hc05.Implied,'9A','2'),
        'CLRA' : (cr68hc05.Implied,'4F','3'),
        'CLRX' : (cr68hc05.Implied,'5F','3'),
        'COMA' : (cr68hc05.Implied,'43','3'),
        'COMX' : (cr68hc05.Implied,'53','3'),
        'DECA' : (cr68hc05.Implied,'4A','3'),
        'DECX' : (cr68hc05.Implied,'5A','3'),
        'DEX'  : (cr68hc05.Implied,'5A','3'),
        'INCA' : (cr68hc05.Implied,'4C','3'),
        'INCX' : (cr68hc05.Implied,'5C','3'),
        'INX'  : (cr68hc05.Implied,'5C','3'),
        'LSLA' : (cr68hc05.Implied,'48','3'),
        'LSLX' : (cr68hc05.Implied,'58','3'),
        'LSRA' : (cr68hc05.Implied,'44','3'),
        'LSRX' : (cr68hc05.Implied,'54','3'),
        'NEGA' : (cr68hc05.Implied,'40','3'),
        'NEGX' : (cr68hc05.Implied,'50','3'),
        'NOP'  : (cr68hc05.Implied,'9D','2'),
        'ROLA' : (cr68hc05.Implied,'49','3'),
        'ROLX' : (cr68hc05.Implied,'59','3'),
        'RORA' : (cr68hc05.Implied,'46','3'),
        'RORX' : (cr68hc05.Implied,'56','3'),
        'RSP'  : (cr68hc05.Implied,'9C','2'),
        'RTI'  : (cr68hc05.Implied,'80','9'),
        'RTS'  : (cr68hc05.Implied,'81','6'),
        'SEC'  : (cr68hc05.Implied,'99','2'),
        'SEI'  : (cr68hc05.Implied,'9B','2'),
        'STOP' : (cr68hc05.Implied,'8E','2'),
        'SWI'  : (cr68hc05.Implied,'83','10'),
        'TAX'  : (cr68hc05.Implied,'97','2'),
        'TSTA' : (cr68hc05.Implied,'4D','3'),
        'TSTX' : (cr68hc05.Implied,'5D','3'),
        'TXA'  : (cr68hc05.Implied,'9F','2'),
        'WAIT' : (cr68hc05.Implied,'8F','2'),

        'BCC'  : (cr68hc05.Branch,'24','3'),
        'BCS'  : (cr68hc05.Branch,'25','3'),
        'BEQ'  : (cr68hc05.Branch,'27','3'),
        'BHCC' : (cr68hc05.Branch,'28','3'),
        'BHCS' : (cr68hc05.Branch,'29','3'),
        'BHI'  : (cr68hc05.Branch,'22','3'),
        'BHS'  : (cr68hc05.Branch,'24','3'),
        'BIH'  : (cr68hc05.Branch,'2F','3'),
        'BIL'  : (cr68hc05.Branch,'2E','3'),
        'BLO'  : (cr68hc05.Branch,'25','3'),
        'BLS'  : (cr68hc05.Branch,'23','3'),
        'BMC'  : (cr68hc05.Branch,'2C','3'),
        'BMI'  : (cr68hc05.Branch,'2B','3'),
        'BMS'  : (cr68hc05.Branch,'2D','3'),
        'BNE'  : (cr68hc05.Branch,'26','3'),
        'BPL'  : (cr68hc05.Branch,'2A','3'),
        'BRA'  : (cr68hc05.Branch,'20','3'),
        'BRN'  : (cr68hc05.Branch,'21','3'),
        'BSR'  : (cr68hc05.Branch,'AD','6'),

        'ADC'  : (cr68hc05.Multi,('A9','B9','C9','F9','E9','D9'),('2','3','4','3','4','5')),
        'ADD'  : (cr68hc05.Multi,('AB','BB','CB','FB','EB','DB'),('2','3','4','3','4','5')),
        'AND'  : (cr68hc05.Multi,('A4','B4','C4','F4','E4','D4'),('2','3','4','3','4','5')),
        'ASL'  : (cr68hc05.Multi,('00','38','00','78','68','00'),('','3','','5','6','')),
        'ASR'  : (cr68hc05.Multi,('00','37','00','77','67','00'),('','3','','5','6','')),
        'BIT'  : (cr68hc05.Multi,('A5','B5','C5','F5','E5','D5'),('2','3','4','3','4','5')),
        'CLR'  : (cr68hc05.Multi,('00','3F','00','7F','6F','00'),('','5','','5','6','')),
        'CMP'  : (cr68hc05.Multi,('A1','B1','C1','F1','E1','D1'),('2','3','4','3','4','5')),
        'COM'  : (cr68hc05.Multi,('00','33','00','73','63','00'),('','5','','5','6','')),
        'CPX'  : (cr68hc05.Multi,('A3','B3','C3','F3','E3','D3'),('2','3','4','3','4','5')),
        'DEC'  : (cr68hc05.Multi,('00','3A','00','7A','6A','00'),('','5','','5','6','')),
        'EOR'  : (cr68hc05.Multi,('A8','B8','C8','F8','E8','D8'),('2','3','4','3','4','5')),
        'INC'  : (cr68hc05.Multi,('00','3C','00','7C','6C','00'),('','5','','5','6','')),
        'JMP'  : (cr68hc05.Multi,('00','BC','CC','FC','EC','DC'),('','2','3','2','3','4')),
        'JSR'  : (cr68hc05.Multi,('00','BD','CD','FD','ED','DD'),('','5','6','5','6','7')),
        'LDA'  : (cr68hc05.Multi,('A6','B6','C6','F6','E6','D6'),('2','3','4','3','4','5')),
        'LDX'  : (cr68hc05.Multi,('AE','BE','CE','FE','EE','DE'),('2','3','4','3','4','5')),
        'LSL'  : (cr68hc05.Multi,('00','38','00','78','68','00'),('','5','','5','6','')),
        'LSR'  : (cr68hc05.Multi,('00','34','00','74','64','00'),('','5','','5','6','')),
        'NEG'  : (cr68hc05.Multi,('00','30','00','70','60','00'),('','5','','5','6','')),
        'ORA'  : (cr68hc05.Multi,('AA','BA','CA','FA','EA','DA'),('2','3','4','3','4','5')),
        'ROL'  : (cr68hc05.Multi,('00','39','00','79','69','00'),('','5','','5','6','')),
        'ROR'  : (cr68hc05.Multi,('00','36','00','76','66','00'),('','5','','5','6','')),
        'SBC'  : (cr68hc05.Multi,('A2','B2','C2','F2','E2','D2'),('2','3','4','3','4','5')),
        'STA'  : (cr68hc05.Multi,('00','B7','C7','F7','E7','D7'),('','4','5','4','5','6')),
        'STX'  : (cr68hc05.Multi,('00','BF','CF','FF','EF','DF'),('','4','5','4','5','6')),
        'SUB'  : (cr68hc05.Multi,('A0','B0','C0','F0','E0','D0'),('2','3','4','3','4','5')),
        'TST'  : (cr68hc05.Multi,('00','3D','00','7D','6D','00'),('','4','','4','5','')),

        'BCLR' : (cr68hc05.Bits,'11','5'),
        'BSET' : (cr68hc05.Bits,'10','5'),
        'BRCLR': (cr68hc05.Bits,'01','5'),
        'BRSET': (cr68hc05.Bits,'00','5')        
    }

    dec.Asm.Timing_Length = 2

    dec.Asm.Memory = 0
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = (1 << 13)-1
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = True

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    """
    No extra directives for this Cross overlay
    """

    return False     # We didn't handle any directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    """
    No need to do any cleaning.
    """

    return    
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    cr68hc05.CrossMnemonic()
    
#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    
