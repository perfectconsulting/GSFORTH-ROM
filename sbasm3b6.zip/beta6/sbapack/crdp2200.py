#------------------------------------------------------------------------------
#
#   crdp2200.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   dp2200 Cross Overlay
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags
    
    assem.CheckVersions(crossversion, minversion)
    
    dec.Asm.Instructions = {
    
    # Inherent operand instructions
    'LAA'   : (Inherent, 'C0', '0'),
    'LAB'   : (Inherent, 'C1', '0'),
    'LAC'   : (Inherent, 'C2', '0'),
    'LAD'   : (Inherent, 'C3', '0'),
    'LAE'   : (Inherent, 'C4', '0'),
    'LAH'   : (Inherent, 'C5', '0'),
    'LAL'   : (Inherent, 'C6', '0'),
    'LAM'   : (Inherent, 'C7', '0'),
    'LBA'   : (Inherent, 'C8', '0'),
    'LBB'   : (Inherent, 'C9', '0'),    # Not defined, probably NOP
    'LBC'   : (Inherent, 'CA', '0'),
    'LBD'   : (Inherent, 'CB', '0'),
    'LBE'   : (Inherent, 'CC', '0'),
    'LBH'   : (Inherent, 'CD', '0'),
    'LBL'   : (Inherent, 'CE', '0'),
    'LBM'   : (Inherent, 'CF', '0'),
    'LCA'   : (Inherent, 'D0', '0'),
    'LCB'   : (Inherent, 'D1', '0'),
    'LCC'   : (Inherent, 'D2', '0'),    # Not defined, probably NOP
    'LCD'   : (Inherent, 'D3', '0'),
    'LCE'   : (Inherent, 'D4', '0'),
    'LCH'   : (Inherent, 'D5', '0'),
    'LCL'   : (Inherent, 'D6', '0'),
    'LCM'   : (Inherent, 'D7', '0'),
    'LDA'   : (Inherent, 'D8', '0'),
    'LDB'   : (Inherent, 'D9', '0'),
    'LDC'   : (Inherent, 'DA', '0'),
    'LDD'   : (Inherent, 'DB', '0'),    # Not defined, probably NOP
    'LDE'   : (Inherent, 'DC', '0'),
    'LDH'   : (Inherent, 'DD', '0'),
    'LDL'   : (Inherent, 'DE', '0'),
    'LDM'   : (Inherent, 'DF', '0'),
    'LEA'   : (Inherent, 'E0', '0'),
    'LEB'   : (Inherent, 'E1', '0'),
    'LEC'   : (Inherent, 'E2', '0'),
    'LED'   : (Inherent, 'E3', '0'),
    'LEE'   : (Inherent, 'E4', '0'),    # Not defined, probably NOP
    'LEH'   : (Inherent, 'E5', '0'),
    'LEL'   : (Inherent, 'E6', '0'),
    'LEM'   : (Inherent, 'E7', '0'),
    'LHA'   : (Inherent, 'E8', '0'),
    'LHB'   : (Inherent, 'E9', '0'),
    'LHC'   : (Inherent, 'EA', '0'),
    'LHD'   : (Inherent, 'EB', '0'),
    'LHE'   : (Inherent, 'EC', '0'),
    'LHH'   : (Inherent, 'ED', '0'),    # Not defined, probably NOP
    'LHL'   : (Inherent, 'EE', '0'),
    'LHM'   : (Inherent, 'EF', '0'),
    'LLA'   : (Inherent, 'F0', '0'),
    'LLB'   : (Inherent, 'F1', '0'),
    'LLC'   : (Inherent, 'F2', '0'),
    'LLD'   : (Inherent, 'F3', '0'),
    'LLE'   : (Inherent, 'F4', '0'),
    'LLH'   : (Inherent, 'F5', '0'),
    'LLL'   : (Inherent, 'F6', '0'),    # Not defined, probably NOP
    'LLM'   : (Inherent, 'F7', '0'),
    'LMA'   : (Inherent, 'F8', '0'),
    'LMB'   : (Inherent, 'F9', '0'),
    'LMC'   : (Inherent, 'FA', '0'),
    'LMD'   : (Inherent, 'FB', '0'),
    'LME'   : (Inherent, 'FC', '0'),
    'LMH'   : (Inherent, 'FD', '0'),
    'LML'   : (Inherent, 'FE', '0'),
    'ACA'   : (Inherent, '88', '0'),
    'ACB'   : (Inherent, '89', '0'),
    'ACC'   : (Inherent, '8A', '0'),
    'ACD'   : (Inherent, '8B', '0'),
    'ACE'   : (Inherent, '8C', '0'),
    'ACH'   : (Inherent, '8D', '0'),
    'ACL'   : (Inherent, '8E', '0'),
    'ACM'   : (Inherent, '8F', '0'),
    'ADA'   : (Inherent, '80', '0'),
    'ADB'   : (Inherent, '81', '0'),
    'ADC'   : (Inherent, '82', '0'),
    'ADD'   : (Inherent, '83', '0'),
    'ADE'   : (Inherent, '84', '0'),
    'ADH'   : (Inherent, '85', '0'),
    'ADL'   : (Inherent, '86', '0'),
    'ADM'   : (Inherent, '87', '0'),
    'SBA'   : (Inherent, '98', '0'),
    'SBB'   : (Inherent, '99', '0'),
    'SBC'   : (Inherent, '9A', '0'),
    'SBD'   : (Inherent, '9B', '0'),
    'SBE'   : (Inherent, '9C', '0'),
    'SBH'   : (Inherent, '9D', '0'),
    'SBL'   : (Inherent, '9E', '0'),
    'SBM'   : (Inherent, '9F', '0'),
    'SUA'   : (Inherent, '90', '0'),
    'SUB'   : (Inherent, '91', '0'),
    'SUC'   : (Inherent, '92', '0'),
    'SUD'   : (Inherent, '93', '0'),
    'SUE'   : (Inherent, '94', '0'),
    'SUH'   : (Inherent, '95', '0'),
    'SUL'   : (Inherent, '96', '0'),
    'SUM'   : (Inherent, '97', '0'),
    'NDA'   : (Inherent, 'A0', '0'),
    'NDB'   : (Inherent, 'A1', '0'),
    'NDC'   : (Inherent, 'A2', '0'),
    'NDD'   : (Inherent, 'A3', '0'),
    'NDE'   : (Inherent, 'A4', '0'),
    'NDH'   : (Inherent, 'A5', '0'),
    'NDL'   : (Inherent, 'A6', '0'),
    'NDM'   : (Inherent, 'A7', '0'),
    'XRA'   : (Inherent, 'A8', '0'),
    'XRB'   : (Inherent, 'A9', '0'),
    'XRC'   : (Inherent, 'AA', '0'),
    'XRD'   : (Inherent, 'AB', '0'),
    'XRE'   : (Inherent, 'AC', '0'),
    'XRH'   : (Inherent, 'AD', '0'),
    'XRL'   : (Inherent, 'AE', '0'),
    'XRM'   : (Inherent, 'AF', '0'),
    'ORA'   : (Inherent, 'B0', '0'),
    'ORB'   : (Inherent, 'B1', '0'),
    'ORC'   : (Inherent, 'B2', '0'),
    'ORD'   : (Inherent, 'B3', '0'),
    'ORE'   : (Inherent, 'B4', '0'),
    'ORH'   : (Inherent, 'B5', '0'),
    'ORL'   : (Inherent, 'B6', '0'),
    'ORM'   : (Inherent, 'B7', '0'),
    'CPA'   : (Inherent, 'B8', '0'),
    'CPB'   : (Inherent, 'B9', '0'),
    'CPC'   : (Inherent, 'BA', '0'),
    'CPD'   : (Inherent, 'BB', '0'),
    'CPE'   : (Inherent, 'BC', '0'),
    'CPH'   : (Inherent, 'BD', '0'),
    'CPL'   : (Inherent, 'BE', '0'),
    'CPM'   : (Inherent, 'BF', '0'),
    'NOP'   : (Inherent, 'C0', '0'),
    'SLC'   : (Inherent, '02', '0'),
    'SRC'   : (Inherent, '0A', '0'),
    'HALT'  : (Inherent, '00', '0'),
    'RETURN': (Inherent, '07', '0'),
    'RFC'   : (Inherent, '03', '0'),
    'RFZ'   : (Inherent, '0B', '0'),
    'RFS'   : (Inherent, '13', '0'),
    'RFP'   : (Inherent, '1B', '0'),
    'RTC'   : (Inherent, '23', '0'),
    'RTZ'   : (Inherent, '2B', '0'),
    'RTS'   : (Inherent, '33', '0'),
    'RTP'   : (Inherent, '3B', '0'),
    'INPUT' : (Inherent, '41', '0'),
    'ALPHA' : (Inherent, '18', '0'),
    'BETA'  : (Inherent, '10', '0'),
    'PUSH'  : (Inherent, '38', '0'),
    'POP'   : (Inherent, '30', '0'),
    'DI'    : (Inherent, '20', '0'),
    'EI'    : (Inherent, '28', '0'),
    
    # Immediate address instructions
    'LA' : (Immediate, '06', '0'),
    'LB' : (Immediate, '0E', '0'),
    'LC' : (Immediate, '16', '0'),
    'LD' : (Immediate, '1E', '0'),
    'LE' : (Immediate, '26', '0'),
    'LH' : (Immediate, '2E', '0'),
    'LL' : (Immediate, '36', '0'),
    'AC' : (Immediate, '0C', '0'),
    'AD' : (Immediate, '04', '0'),
    'SB' : (Immediate, '1C', '0'),
    'SU' : (Immediate, '14', '0'),
    'ND' : (Immediate, '24', '0'),
    'XR' : (Immediate, '2C', '0'),
    'OR' : (Immediate, '34', '0'),
    'CP' : (Immediate, '3C', '0'),
    
    # Jump instructions
    'JMP' : (Jumps, '44', '0'),
    'JFC' : (Jumps, '40', '0'),
    'JFZ' : (Jumps, '48', '0'),
    'JFS' : (Jumps, '50', '0'),
    'JFP' : (Jumps, '58', '0'),
    'JTC' : (Jumps, '60', '0'),
    'JTZ' : (Jumps, '68', '0'),
    'JTS' : (Jumps, '70', '0'),
    'JTP' : (Jumps, '78', '0'),
    'CALL': (Jumps, '46', '0'),
    'CFC' : (Jumps, '42', '0'),
    'CFZ' : (Jumps, '4A', '0'),
    'CFS' : (Jumps, '52', '0'),
    'CFP' : (Jumps, '5A', '0'),
    'CTC' : (Jumps, '62', '0'),
    'CTZ' : (Jumps, '6A', '0'),
    'CTS' : (Jumps, '72', '0'),
    'CTP' : (Jumps, '7A', '0'),
    
    # Output instruction
    'EX'  : (Output, '00', '0')
    
    }

    dec.Asm.Timing_Length = 0       # No timing information available.

    dec.Asm.Memory = 0              # Select code memory as default
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = (1 << 14)-1
    dec.Asm.PP_TA_Factor = 1        # Set the actual factor between PP and TA
    dec.Flags.BigEndian = False     # Set actual value

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    # Nothing to do here

    return False     # return True if we handled the directive

#------------------------------------------------------------------------------

def CrossCleanUp():

    # Nothing to do here either

    return
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)
    
#-----------------------------------------------------------------------------

def MissingOperand():

    """
    A useful function which raises an error if no operand is given.
    """

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    """
    A useful function which tests if no more parameters are given when we
    don't expect any more at the end of the operand parsing.
    """

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)

#-----------------------------------------------------------------------------

def Inherent():

    global Asm

    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16))
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

#-----------------------------------------------------------------------------

def Immediate():

    global Asm

    if MissingOperand():
        return
    
    prefix = assem.NowChar()
    
    if prefix in '#/=\\':
        prefix = assem.NowChar(True)
    else:
        prefix = '#'
        
    value = assem.EvalExpr()
    
    if prefix == '#':
        byte = value[0]
    elif prefix == '/':
        byte = value[0] >> 8
    elif prefix == '=':
        byte = value[0] >> 16
    else:
        byte = value[0] >> 24
        
    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16))
    target.CodeByte(byte)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
    NoMore()

#-----------------------------------------------------------------------------

def Jumps():

    global Asm
    
    if MissingOperand():
        return    
        
    dest = assem.EvalExpr()

    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16))
    target.CodeWord(dest[0])
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
    if dec.Asm.Pass == 2 and (dest[0] >> 14) != 0:
        errors.DoError('range', False)
    
    NoMore()

#-----------------------------------------------------------------------------

def Output():

    global Asm
    
    if MissingOperand():
        return
        
    operand = assem.GetWord().upper()
    
    outputlist = {
    'ADR'    : '51',
    'STATUS' : '53',
    'DATA'   : '55',
    'WRITE'  : '57',
    'COM1'   : '59',
    'COM2'   : '5B',
    'COM3'   : '5D',
    'COM4'   : '5F',
    
    'BEEP'   : '69',
    'CLICK'  : '6B',
    'DECK1'  : '6D',
    'DECK2'  : '6F',
    'RBK'    : '71',
    'WBK'    : '73',
    
    'BSP'    : '77',
    'SF'     : '79',
    'SB'     : '7B',
    'REWIND' : '7D',
    'TSTOP'  : '7F'
    }
    
    if operand in outputlist:
        target.CodeByte(int(outputlist[operand],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    else:
        errors.DoError('badoper', False)
        
    NoMore()

#-----------------------------------------------------------------------------


if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    
