#------------------------------------------------------------------------------
#
#   cr8048.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   Cross Overlay for the 8048 family of processors
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags, Error_List

    assem.CheckVersions(crossversion, minversion)
    
    # Declare the tuples for the MOV instruction seperately, otherwise the line gets sooooooo long
    movparams  = ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','R0,A','R1,A','R2,A','R3,A','R4,A','R5,A','R6,A','R7,A','@R0,A','@R1,A','A,#','R0,#','R1,#','R2,#','R3,#','R4,#','R5,#','R6,#','R7,#','@R0,#','@R1,#','A,PSW','PSW,A','A,T','T,A')
    movopcodes = ('F8',  'F9',  'FA',  'FB',  'FC',  'FD',  'FE',  'FF',  'F0',   'F1',   'A8',  'A9',  'AA',  'AB',  'AC',  'AD',  'AE',  'AF',  'A0',   'A1',   '23', 'B8',  'B9',  'BA',  'BB',  'BC'  ,'BD',  'BE',  'BF',  'B0',   'B1',   'C7',   'D7',   '42', '62')
    movtimes   = ('1',   '1',   '1',   '1',   '1',   '1',   '1',   '1',   '1',    '1',    '1',   '1',   '1',   '1',   '1',   '1',   '1',   '1',   '1',    '1',    '2',  '2',   '2',   '2',   '2',   '2',   '2',   '2',   '2',   '2',    '2',    '1',    '1',    '1',  '1')
    
    dec.Asm.Instructions = {
    'JB0'  : (Branch, int('12',16),'2'),
    'JB1'  : (Branch, int('32',16),'2'),
    'JB2'  : (Branch, int('52',16),'2'),
    'JB3'  : (Branch, int('72',16),'2'),
    'JB4'  : (Branch, int('92',16),'2'),
    'JB5'  : (Branch, int('B2',16),'2'),
    'JB6'  : (Branch, int('D2',16),'2'),
    'JB7'  : (Branch, int('F2',16),'2'),
    'JC'   : (Branch, int('F6',16),'2'),
    'JF0'  : (Branch, int('B6',16),'2'),
    'JF1'  : (Branch, int('76',16),'2'),
    'JNC'  : (Branch, int('E6',16),'2'),
    'JNI'  : (Branch, int('86',16),'2'),
    'JNT0' : (Branch, int('26',16),'2'),
    'JNT1' : (Branch, int('46',16),'2'),
    'JNZ'  : (Branch, int('96',16),'2'),
    'JTF'  : (Branch, int('16',16),'2'),
    'JT0'  : (Branch, int('36',16),'2'),
    'JT1'  : (Branch, int('56',16),'2'),
    'JZ'   : (Branch, int('c6',16),'2'),

    'CLR'  : (Singles, ('A','C','F0','F1'),('27','97','85','A5'),('1','1','1','1')),
    'CPL'  : (Singles, ('A','C','F0','F1'),('37','A7','95','B5'),('1','1','1','1')),
    'DA'   : (Singles, ('A',),('57',),('1',)),    
    'DEC'  : (Singles, ('A','R0','R1','R2','R3','R4','R5','R6','R7'),('07','C8','C9','CA','CB','CC','CD','CE','CF'),('1','1','1','1','1','1','1','1','1')),    
    'INC'  : (Singles, ('A','R0','R1','R2','R3','R4','R5','R6','R7','@R0','@R1'),('17','18','19','1A','1B','1C','1D','1E','1F','10','11'),('1','1','1','1','1','1','1','1','1','1','1')),    
    'RL'   : (Singles, ('A',),('E7',),('1',)),
    'RLC'  : (Singles, ('A',),('F7',),('1',)),
    'RR'   : (Singles, ('A',),('77',),('1',)),
    'RRC'  : (Singles, ('A',),('67',),('1',)),
    'SWAP' : (Singles, ('A',),('47',),('1',)),
    'DIS'  : (Singles, ('I','TCNTI'),('15','35'),('1','1')),
    'EN'   : (Singles, ('I','TCNTI'),('05','25'),('1','1')),
    'ENT0' : (Singles, ('CLK',),('75',),('1',)),
    'JMPP' : (Singles, ('@A',),('B3',),('2',)),
    'SEL'  : (Singles, ('MB0','MB1','RB0','RB1'),('E5','F5','C5','D5'),('1','1','1','1')),
    'STOP' : (Singles, ('TCNT',),('65',),('1',)),
    'STRT' : (Singles, ('T','CNT'),('55','45'),('1','1')),

    'ADD'  : (Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','A,#'),('68','69','6A','6B','6C','6D','6E','6F','60','61','03'),('1','1','1','1','1','1','1','1','1','1','2')),
    'ADDC' : (Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','A,#'),('78','79','7A','7B','7C','7D','7E','7F','70','71','13'),('1','1','1','1','1','1','1','1','1','1','2')),
    'ANL'  : (Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','A,#','BUS,#','P1,#','P2,#'),('58','59','5A','5B','5C','5D','5E','5F','50','51','53','98','99','9A'),('1','1','1','1','1','1','1','1','1','1','2','2','2','2')),
    'ORL'  : (Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','A,#','BUS,#','P1,#','P2,#'),('48','49','4A','4B','4C','4D','4E','4F','40','41','43','88','89','8A'),('1','1','1','1','1','1','1','1','1','1','2','2','2','2')),
    'XCH'  : (Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1'),('28','29','2A','2B','2C','2D','2E','2F','20','21'),('1','1','1','1','1','1','1','1','1','1')),
    'XCHD' : (Pairs, ('A,@R0','A,@R1'),('30','31'),('1','1')),
    'XRL'  : (Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','A,#'),('D8','D9','DA','DB','DC','DD','DE','DF','D0','D1','D3'),('1','1','1','1','1','1','1','1','1','1','2')),
    'MOV'  : (Pairs, movparams, movopcodes, movtimes),
    'ANLD' : (Pairs, ('P4,A','P5,A','P6,A','P7,A'),('9C','9D','9E','9F'),('2','2','2','2')),
    'IN'   : (Pairs, ('A,P1','A,P2'),('09','0A'),('2','2')),
    'INS'  : (Pairs, ('A,BUS',),('08',),('2',)),
    'MOVP' : (Pairs, ('A,@A',),('A3',),('2',)),
    'MOVP3': (Pairs, ('A,@A',),('E3',),('2',)),
    'ORLD' : (Pairs, ('P4,A','P5,A','P6,A','P7,A'),('8C','8D','8E','8F'),('1','1','1','1')),
    'OUTL' : (Pairs, ('BUS,A','P1,A','P2,A'),('02','39','3A'),('2','2','2')),
    'MOVD' : (Pairs, ('A,P4','A,P5','A,P6','A,P7','P4,A','P5,A','P6,A','P7,A'),('0C','0D','0E','0F','3C','3D','3E','3F'),('2','2','2','2','2','2','2','2')),
    'MOVX' : (Pairs, ('A,@R0','A,@R1','@R0,A','@R1,A'),('80','81','90','91'),('2','2','2','2')),
    
    
    'NOP'  : (Implied, int('00',16),'1'),
    'RET'  : (Implied, int('83',16),'2'),
    'RETR' : (Implied, int('93',16),'2'),
    
    'CALL' : (Absolute, int('14',16),'2'),
    'JMP'  : (Absolute, int('04',16),'2'),
    
    'DJNZ' : (Djnz, (int('E8',16),int('00',16)),'2')
    }

    dec.Asm.Timing_Length = 1
    
    errors.Error_List[dec.Cross.Name + 'tcrossed'] = 'Table crossed page boundary'
 
    dec.Asm.Memory = 0
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = (1 << 11)-1
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = False
    
    dec.Asm.Table8048 = -1

    return

#------------------------------------------------------------------------------

def CrossDirective():

    """
    Two new directives are added by this cross overlay
    .OT and .CT are used to check if a table doesn't cross a page boundary.
    """

    global Asm

    if len(dec.Asm.Mnemonic) > 1:
        directive = dec.Asm.Mnemonic[1:3].upper()
    else:
        directive = dec.Asm.Mnemonic
    
    if directive == 'CT':
        DirCT()
        return True
        
    if directive == 'OT':
        DirOT()
        return True
        
    return False

#------------------------------------------------------------------------------

def CrossCleanUp():

    """
    No need to do any cleaning.
    """

    return    
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    """
    Jump to the mnemonic handling routine.
    """

    global Asm
    
    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def MissingOperand():

    """
    An operand is mandatory, so it's an error if one is missing.
    Returns True if the operand is indeed missing.
    """

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------

def NoMore():

    """
    This must be the end of the line. Raise an error if it's not. Or a warning
    if more parameters follow.
    """

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)

#-----------------------------------------------------------------------------

def Branch():
    
    """
    Handle the simple branch instructions.
    """
     
    global Asm
        
    if MissingOperand():
        return

    value = assem.EvalExpr()

    if dec.Asm.Pass == 2:
        temp = (dec.Asm.BOL_Address + 1) >> 8
        dest = value[0] >> 8
        if temp != dest:
            # Destination is not in the same memory page
            errors.DoError('range', False)

    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    target.CodeByte(value[0])
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
    NoMore()

#-----------------------------------------------------------------------------

def Singles():
    
    """
    Handle single operand instructions.
    """
     
    global Asm
        
    if MissingOperand():
        return

    regname = assem.GetWord().upper()
    
    registers = dec.Asm.Instructions[dec.Asm.Mnemonic][1]
    opcodes   = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    times     = dec.Asm.Instructions[dec.Asm.Mnemonic][3]

    if regname in registers:
        index = 0
        for t in registers:
            if t == regname:
                break
            index = index + 1
        target.CodeByte(int(opcodes[index],16))
        dec.Asm.Timing = times[index]
    else:
        errors.DoError('badoper',False)

    NoMore()

#-----------------------------------------------------------------------------

def Pairs():
    
    """
    Handle paired operand instructions.
    """
     
    global Asm
        
    if MissingOperand():
        return

    reg1 = assem.GetWord().upper()
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    if assem.NowChar() == ' ':
        errors.DoError('missoper', False)
        return
    
    if assem.NowChar() in '#/=\\':
        reg2 = '#'
    else:
        reg2 = assem.GetWord().upper()
    
    operand = reg1 + ',' + reg2    
    
    operands = dec.Asm.Instructions[dec.Asm.Mnemonic][1]
    opcodes  = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    times    = dec.Asm.Instructions[dec.Asm.Mnemonic][3]

    if operand in operands:
        index = 0
        for t in operands:
            if t == operand:
                break
            index = index + 1
        target.CodeByte(int(opcodes[index],16))
        dec.Asm.Timing = times[index]
        if reg2 == '#':
            prefix = assem.NowChar(True)
            value = assem.EvalExpr()
            if prefix == '#':
                target.CodeByte(value[0])
            elif prefix == '/':
                target.CodeByte(value[0] >> 8)
            elif prefix == '=':
                target.CodeByte(value[0] >> 16)
            else:
                target.CodeByte(value[0] >> 24)
    else:
        errors.DoError('badoper',False)

    NoMore()

#-----------------------------------------------------------------------------

def Implied():

    global Asm

    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    
    dec.Asm.Timing = (dec.Asm.Instructions[dec.Asm.Mnemonic][2])

#-----------------------------------------------------------------------------

def Absolute():

    global Asm

    if MissingOperand():
        return

    dest = assem.EvalExpr()
    
    hibits = (dest[0] >> 8) & 7

    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (hibits << 5))
    target.CodeByte(dest[0])
    
    if (dest[0] >> 11) != 0:
        errors.DoError('range', False)
    
    dec.Asm.Timing = (dec.Asm.Instructions[dec.Asm.Mnemonic][2])

#-----------------------------------------------------------------------------

def Djnz():
    
    """
    Handle DJNZ.
    DJNZ has two opcodes in the instruction table. The first one is for
    DJNZ Rx,dest. The second entry is for DJNZ @Rn,dest.
    If indirect mode doesn't exist the opcode for it should be 00.
    """
     
    global Asm
        
    if MissingOperand():
        return
    
    registers = ('R0','R1','R2','R3','R4','R5','R6','R7','@R0','@R1')
    regname = assem.GetWord().upper()
    
    if regname in registers:
        index = 0
        for t in registers:
            if t == regname:
                break
            index = index + 1
        if index < 8:
            # direct addressing mode
            opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][0] + index
        else:
            # indirect addressing mode
            opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][1]
            if opcode == 0:
                errors.DoError('badoper', False)
                return
            opcode = opcode + (index & 1)
    else:
        errors.DoError('badoper',False)
        return    
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    value = assem.EvalExpr()

    if dec.Asm.Pass == 2:
        temp = (dec.Asm.BOL_Address + 1) >> 8
        dest = value[0] >> 8
        if temp != dest:
            # Destination is not in the same memory page
            errors.DoError('range', False)

    target.CodeByte(opcode)
    target.CodeByte(value[0])
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
    NoMore()

#-----------------------------------------------------------------------------

def DirCT():

    """
    Check if the table is still in the same memory page as when it was opened.
    Generate an error if it is not.
    Test only during pass 2
    """

    global Asm

    if (dec.Asm.Pass == 2) and (dec.Asm.Table8048 != -1):
        # The beginning was set, otherwise ignore this directive
        if dec.Asm.Table8048 != (dec.Asm.BOL_Address >> 8):
            # Oops, not the same page
            # Our last hope is that we're on the first location of the next
            # page, because then the table had ended just in time.
            if dec.Asm.Table8048 != ((dec.Asm.BOL_Address - 1) >> 8):
                # Nope, we've definately crossed the page!
                errors.DoError(dec.Cross.Name + 'tcrossed', False)
    
    # Now clear the beginning address
    dec.Asm.Table8048 = -1

#-----------------------------------------------------------------------------

def DirOT():

    """
    Open table. Mark the beginning of a new table so we can check if the
    table has crossed a page boundary when we close the table.
    """

    global Asm
    
    # Close the previous table, if it's still open
    DirCT()

    # Set new begin of table address page
    dec.Asm.Table8048 = dec.Asm.BOL_Address >> 8

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print

