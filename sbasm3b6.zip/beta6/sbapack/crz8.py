#------------------------------------------------------------------------------
#
#   crz8.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   Cross Overlay for the Z8 family of processors
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags

    assem.CheckVersions(crossversion, minversion)
    
    dec.Asm.Instructions = {
        'LD'  : (Load,),
        
        'ADC' : (Math, ('12','13','14','15','16','17'),('6','6','10','10','10','10')),
        'ADD' : (Math, ('02','03','04','05','06','07'),('6','6','10','10','10','10')),
        'AND' : (Math, ('52','53','54','55','56','57'),('6','6','10','10','10','10')),
        'CP'  : (Math, ('A2','A3','A4','A5','A6','A7'),('6','6','10','10','10','10')),
        'SBC' : (Math, ('32','33','34','35','36','37'),('6','6','10','10','10','10')),
        'SUB' : (Math, ('22','23','24','25','26','27'),('6','6','10','10','10','10')),
        'TCM' : (Math, ('62','63','64','65','66','67'),('6','6','10','10','10','10')),
        'OR'  : (Math, ('42','43','44','45','46','47'),('6','6','10','10','10','10')),
        'TM'  : (Math, ('72','73','74','75','76','77'),('6','6','10','10','10','10')),
        'XOR' : (Math, ('B2','B3','B4','B5','B6','B7'),('6','6','10','10','10','10')),

        'CLR' : (Single, ('B0','B1'),('6','6')),
        'COM' : (Single, ('60','61'),('6','6')),
        'DA'  : (Single, ('40','41'),('8','8')),
        'DEC' : (Single, ('00','01'),('6','6')),
        'INC' : (Single, ('20','21'),('6','6')), # One special opcode for r
        'RL'  : (Single, ('90','91'),('6','6')),
        'RLC' : (Single, ('10','11'),('6','6')),
        'RR'  : (Single, ('E0','E1'),('6','6')),
        'RRC' : (Single, ('C0','C1'),('6','6')),
        'SRA' : (Single, ('D0','D1'),('6','6')),
        'SWAP': (Single, ('F0','F1'),('6','6')),
        'POP' : (Single, ('50','51'),('10','10')),
        'PUSH': (Single, ('70','71'),('10+','10')),
        'SRP' : (Single, ('31',),('6')),
        'DECW': (SingleW,('80','81'),('10','10')),
        'INCW': (SingleW,('A0','A1'),('10','10')),

        'CCF' : (Implied, 'EF','6'),
        'DI'  : (Implied, '8F','6'),
        'EI'  : (Implied, '9F','6'),
        'HALT': (Implied, '7F','6'),
        'IRET': (Implied, 'BF','16'),
        'NOP' : (Implied, 'FF','6'),
        'RCF' : (Implied, 'CF','6'),
        'RET' : (Implied, 'AF','14'),
        'SCF' : (Implied, 'DF','6'),
        'STOP': (Implied, '6F','6'),
        'WDH' : (Implied, '4F','6'),
        'WDT' : (Implied, '5F','6'),

        'DJNZ': (Branch, 10, '10+'),
        'JR'  : (Branch, 11, '10+'),
        
        'CALL': (Jumps, ('D6','D4'), ('20','20')),
        'JP'  : (Jumps, ('8D','30'), ('12','8')),
        
        'LDC' : (Memory, ('C2','D2'),('12','12')),
        'LDCI': (Memory, ('C3','D3'),('18','18')),
        'LDE' : (Memory, ('82','92'),('12','12')),
        'LDEI': (Memory, ('83','93'),('18,''18'))

        }

    dec.Asm.Memory = 0
    length = 0

    dec.Asm.Timing_Length = 3

    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = dec.MAX16
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = True
    
    dec.Asm.Z8rp = 0
    
    return

#------------------------------------------------------------------------------

def CrossDirective():

    # This cross overlay has one extra directive

    if len(dec.Asm.Mnemonic) > 1:
        directive = dec.Asm.Mnemonic[1:3].upper()
    else:
        directive = dec.Asm.Mnemonic
    
    if directive == 'RP':
        DirRP()
        return True

    return False    # We didn't handle any directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    # This cross overlay does not need any clean up
    
    return

#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def MissingOperand():

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)

#-----------------------------------------------------------------------------

def Implied():

    global Asm

    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16))
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

#-----------------------------------------------------------------------------

def Load():

    global Asm
    
    if MissingOperand():
        return

    reg1 = GetReg()
    
    if dec.Flags.ErrorInLine:
        # An error was found in parameter 1, no need to continue
        return
        
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    reg2 = GetReg()
    
    if dec.Flags.ErrorInLine:
        # An error was found in parameter 1, no need to continue
        return

    if reg2[0] == '#':
        # It's some form of immediate mode
        if reg1[0] == 'r':
            target.CodeByte((reg1[1] << 4) + 12)
            target.CodeByte(reg2[1])
            dec.Asm.Timing = '6'
        elif reg1[0] == 'R':
            target.CodeByte(int('E6',16))
            target.CodeByte(reg1[1])
            target.CodeByte(reg2[1])
            dec.Asm.Timing = '10'
        elif reg1[0] == '@R' or reg1[0] == '@r':
            target.CodeByte(int('E7',16))
            target.CodeByte(reg1[1])
            target.CodeByte(reg2[1])
            dec.Asm.Timing = '10'
        else:
            errors.DoError('badoper',False)
    
    elif reg1[0] == 'r':
        # First operand is a 4-bit register
        if reg2[0] == 'r' or reg2[0] == 'R':
            # Second is a 4 or 8 bit register
            target.CodeByte((reg1[1] << 4) + 8)
            target.CodeByte(reg2[1])
            dec.Asm.Timing = '6'
        elif reg2[0] == '@r':
            # Second operand is 4-bit indirect
            target.CodeByte(int('E3',16))
            target.CodeByte((reg1[1] << 4) + (reg2[1] & 15))
            dec.Asm.Timing = '6'
        elif reg2[0] == '@R':
            # Second operand is 8-bit indirect
            target.CodeByte(int('E5',16))
            target.CodeByte(reg2[1])
            target.CodeByte(reg1[1])
            dec.Asm.Timing = '10'
        elif reg2[0] == 'X':
            target.CodeByte(int('C7',16))
            target.CodeByte((reg1[1] << 4) + (reg2[1] & 15))
            target.CodeByte(reg2[2])
            dec.Asm.Timing = '10'
        else:
            errors.DoError('badoper',False)
            
    elif reg1[0] == 'R':
         # First operand is an 8 bit register
         if reg2[0] == 'r':
             # Second is a 4 bit register
            target.CodeByte((reg2[1] << 4) + 9)
            target.CodeByte(reg1[1])
            dec.Asm.Timing = '6'
         elif reg2[0] == 'R':
            # Second is also an 8 bit register
            target.CodeByte(int('E4',16))
            target.CodeByte(reg2[1])
            target.CodeByte(reg1[1])
            dec.Asm.Timing = '10'
         elif reg2[0] == '@R':
            # Second is also an 8 bit register
            target.CodeByte(int('E5',16))
            target.CodeByte(reg2[1])
            target.CodeByte(reg1[1])
            dec.Asm.Timing = '10'
         else:
             errors.DoError('badoper',False)

    elif reg1[0] == '@r':
        # First operand is indirect 4 bit register
        if reg2[0] == 'r':
            # Second is a 4 bit register
            target.CodeByte(int('F3',16))
            target.CodeByte((reg1[1] << 4) + (reg2[1] & 15))
            dec.Asm.Timing = '6'
        elif reg2[0] == 'R':
            # Second is an 8 bit register
            target.CodeByte(int('F5',16))
            target.CodeByte(reg2[1])
            target.CodeByte(reg1[1])
            dec.Asm.Timing = '10'
        else:
            errors.DoError('badoper',False)
    
    elif reg1[0] == '@R':
        # First operand is indirect 8 bit register
        if reg2[0] == 'r' or reg2[0] == 'R':
            target.CodeByte(int('F5',16))
            target.CodeByte(reg2[1])
            target.CodeByte(reg1[1])
            dec.Asm.Timing = '10'
        else:
            errors.DoError('badoper',False)
    
    elif reg1[0] == 'X':
        # First operand is indexed mode
        if reg2[0] == 'r':
            # Second is indeed a 4 bit register
            target.CodeByte(int('D7',16))
            target.CodeByte((reg2[1] << 4) + (reg1[1] & 15))
            target.CodeByte(reg1[2])
            dec.Asm.Timing = '10'
        else:
            errors.DoError('badoper',False)

    else:
        errors.DoError('badoper',False)

    NoMore()
    
#-----------------------------------------------------------------------------

def Math():

    global Asm
    
    if MissingOperand():
        return

    reg1 = GetReg()
    
    if dec.Flags.ErrorInLine:
        # An error was found in parameter 1, no need to continue
        return
        
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    reg2 = GetReg()
    
    if dec.Flags.ErrorInLine:
        # An error was found in parameter 1, no need to continue
        return
    
    if reg1[0] == 'r':
        # First operand is 4 bit register
        if reg2[0] == 'r':
            # Second is also 4 bit register
            index = 0
        elif reg2[0] == '@r':
            # Second is indirect 4 bit register
            index = 1
        elif reg2[0] == 'R':
            # Second is 8 bit register
            index = 2
        elif reg2[0] == '@R':
            # Second is indirect 8 bit register
            index = 3
        elif reg2[0] == '#':
            # Second is immediate mode
            index = 4
        else:
            errors.DoError('badoper',False)
            return
    
    elif reg1[0] == 'R':
        # First operand is 8 bit register
        if reg2[0] == 'r' or reg2[0] == 'R':
            # Second is 4 or 8 bit register
            index = 2
        elif reg2[0] == '@r' or reg2[0] == '@R':
            # Second is indirect register
            index = 3
        elif reg2[0] == '#':
            # Second is immediate
            index = 4
        else:
            errors.DoError('badoper',False)
            return
    
    elif reg1[0] == '@r' or reg1[0] == '@R':
        # First operand is indirect register
        if reg2[0] == '#':
            # Immediate mode is only one allowed        
            index = 5
        else:
            errors.DoError('badoper',False)
            return
        
    else:
        errors.DoError('badoper',False)
        return
        
    if index == 0 or index == 1:
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16))
        target.CodeByte((reg1[1] << 4) + (reg2[1] & 15))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
    elif index == 2 or index == 3:
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16))
        target.CodeByte(reg2[1])
        target.CodeByte(reg1[1])
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
    elif index == 4 or index == 5:
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16))
        target.CodeByte(reg1[1])
        target.CodeByte(reg2[1])
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
        
    NoMore()

#-----------------------------------------------------------------------------

def Single():

    global Asm
    
    if MissingOperand():
        return

    reg1 = GetReg()
    
    if dec.Flags.ErrorInLine:
        # An error was found in parameter 1, no need to continue
        return

    if dec.Asm.Mnemonic == 'SRP':
        # This one allows only immediate data
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16))
        target.CodeByte(reg1[1])
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]

    else:
        if reg1[0] == 'r' or reg1[0] == 'R':
            # It's a register
            if dec.Asm.Mnemonic == 'INC' and reg1[0] == 'r':
                # There's one little exception to the general rule
                target.CodeByte((reg1[1] << 4) + 14)
            else:
                target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16))
                target.CodeByte(reg1[1])
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        elif reg1[0] == '@r' or reg1[0] == '@R':
            # It's an indirect register
            target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16))
            target.CodeByte(reg1[1])
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
        else:
            errors.DoError('badoper',False)

    NoMore()
        
#-----------------------------------------------------------------------------

def SingleW():

    global Asm
    
    if MissingOperand():
        return

    reg1 = GetReg()
    
    if dec.Flags.ErrorInLine:
        # An error was found in parameter 1, no need to continue
        return

    if reg1[0] == 'rr' or reg1[0] == 'R' or reg1[0] == 'r':
        # Operand is register pair
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16))
        target.CodeByte(reg1[1])
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        if dec.Asm.Pass == 2 and (reg1[1] & 1) != 0:
            errors.DoError('range',False)
    elif reg1[0] == '@r' or reg1[0] == '@R':
        # Operand is indirect register pair
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16))
        target.CodeByte(reg1[1])
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
    else:
        errors.DoError('badoper',False)        

    NoMore()
        
#-----------------------------------------------------------------------------

def Branch():

    global Asm
    
    if MissingOperand():
        return

    if dec.Asm.Mnemonic == 'DJNZ':
        # DJNZ

        reg1 = GetReg()

        if dec.Flags.ErrorInLine:
            # An error was found in parameter 1, no need to continue
            return

        if reg1[0] != 'r':
            errors.DoError('badoper',False)
            return

        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            return
        
        cc = reg1[1] << 4
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
        
    else:
        # JR
        
        conditions = {'F':'00','C':'70','NC':'F0','Z':'60','NZ':'E0','PL':'D0','MI':'50','OV':'40','NOV':'C0','EQ':'60',
                      'NE':'E0','GE':'90','LT':'10','GT':'A0','LE':'20','UGE':'F0','ULT':'70','UGT':'B0','ULE':'30'}
                
        pointer = dec.Asm.Parse_Pointer
        cond = assem.GetWord().upper()

        if cond in conditions and assem.NowChar() == ',':
            # A legal condition code was given
            cc = int(conditions[cond],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
            if not assem.MoreParameters():
                errors.DoError('missoper', False)
                return
        else:
            # No condition was given
            dec.Asm.Parse_Pointer = pointer
            dec.Asm.Timing = '12'
            cc = int('80',16)
        
    dest = assem.EvalExpr()

    offset = dest[0] - dec.Asm.BOL_Address - 2
        
    if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
        errors.DoError('range', False)
 
    target.CodeByte(cc + dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    target.CodeByte(offset)

    NoMore()

#-----------------------------------------------------------------------------

def Jumps():

    global Asm
    
    if MissingOperand():
        return

    if assem.NowChar() == '@':
        # It is an indirect jump
        
        reg1 = GetReg()
        
        if reg1[0] == '@rr' or reg1[0] == '@R':
            target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16))
            target.CodeByte(reg1[1])
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
            if reg1[1] & 1 != 0:
                errors.DoError('range',False)
        else:
           errors.DoError('badoper',False)
    else:
        # It's not an indirect jump
        if dec.Asm.Mnemonic == 'CALL':
            # It's a CALL instruction
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
            
        else:
            # It's JP instruction
            conditions = {'F':'00','C':'70','NC':'F0','Z':'60','NZ':'E0','PL':'D0','MI':'50','OV':'40','NOV':'C0','EQ':'60',
                          'NE':'E0','GE':'90','LT':'10','GT':'A0','LE':'20','UGE':'F0','ULT':'70','UGT':'B0','ULE':'30'}
                
            pointer = dec.Asm.Parse_Pointer
            cond = assem.GetWord().upper()

            if cond in conditions and assem.NowChar() == ',':
                # A legal condition code was given
                opcode = int(conditions[cond],16) + 13
                dec.Asm.Timing = '10+'
                if not assem.MoreParameters():
                    errors.DoError('missoper', False)
                    return
            else:
                # No condition was given
                dec.Asm.Parse_Pointer = pointer
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
                opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16)
            
        dest = assem.EvalExpr()
        
        target.CodeByte(opcode)
        target.CodeWord(dest[0])
        if dec.Asm.Pass == 2 and (dest[0] >> 16) != 0:
            errors.DoError('range',False)

            
            
    NoMore()
    
#-----------------------------------------------------------------------------

def Memory():

    global Asm
    
    if MissingOperand():
        return

    reg1 = GetReg()
    
    if dec.Flags.ErrorInLine:
        # An error was found in parameter 1, no need to continue
        return
        
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    reg2 = GetReg()
    
    if dec.Flags.ErrorInLine:
        # An error was found in parameter 1, no need to continue
        return            
            
    if dec.Asm.Mnemonic[-1] != 'I':
        # LDC or LDE
        if (reg1[0] == 'r' or reg1[0] == 'R') and  (reg2[0] == '@rr' or reg2[0] == '@R' or reg2[0] == '@r'):
            index = 0
        elif (reg1[0] == '@rr' or reg1[0] == '@R' or reg1[0] == '@r') and (reg2[0] == 'r' or reg2[0] == 'R'):
            index = 1
            temp = reg1
            reg1 = reg2
            reg2 = temp
        else:
            errors.DoError('badoper',False)
            return

        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16))
        target.CodeByte((reg1[1] << 4) + (reg2[1] & 15))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
        if dec.Asm.Pass == 2 and (reg2[1] & 1) != 0:
            errors.DoError('range',False)       
            
    else:
        # LDCI or LDEI
        if reg1[0] == '@rr':
            # First operand is @rr, no doubt
            if reg2[0] == '@rr' or reg2[0][0] != '@':
                # Can't be both @rr and must be indirect mode
                errors.DoError('badoper', False)
                return
            if (reg2[1] & 240) != 224:
                # Must have been a working register!
                errors.DoError('range', False)
            index = 1
            
        elif reg2[0] == '@rr':
            # Second operand is @rr, no doubt
            if reg1[0] == '@rr' or reg1[0][0] != '@':
                # Can't be both @rr and must be indirect mode
                errors.DoError('badoper', False)
                return
            if (reg1[1] & 240) != 224:
                # Must have been a working register!
                errors.DoError('range', False)
            index = 0
            
        else:
            # There may be some doubt about who's who
            if reg1[0][0] != '@' or reg2[0][0] != '@':
                # Both operands should be indirect mode
                errors.DoError('badoper',False)
                return
            if ((reg1[1] & 240) != 224) or ((reg2[1] & 240) != 224):
                # Must have been a working register!
                errors.DoError('range', False)
            if (reg1[1] & 1 != 0) and (reg2[1] & 1 != 0):
                # Can't have 2 odd addresses, one should have been an even pair
                errors.DoError('range', False)
                index = 0
            elif (reg1[1] & 1 == 0) and (reg2[1] & 1 == 0):
                # Both arguments are even, so we have no way of telling, assume @r,@rr now
                index = 0
            elif (reg1[1] & 1 == 0): 
                # First operand is even, second is odd. Assume the first one to be a @rr
                index = 1
            else:
                # Second operand is even, first is odd. Assume the second one to be a @rr
                index = 0
                
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16))
        if index == 0:
            target.CodeByte((reg1[1] << 4) + (reg2[1] & 15))
        else:
            target.CodeByte((reg2[1] << 4) + (reg1[1] & 15))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]

    NoMore()

#-----------------------------------------------------------------------------

def GetReg():

    """
    Possible parameters:
    Name:       Returns:
    #           ('#',value)
    4-bit r     ('r',regnr)
    8-bit R     ('R',regnr)
    4-bit @r    ('@r',regnr)
    8-bit @R    ('@R,'regnr)
    4-bit rr    ('rr',regnr)
    8-bit RR    ('R',regnr)
    4-bit @rr   ('@rr',regnr)
    8-bit @RR   ('@R',regnr)
    indexed     ('X',regnr,offset)
    error       ('!',0)

    Registers are returned as an 8 bit value.
    In case it was a 4 bit address $E0 is added to the register number
    This indicates 4-bit r mode.
    In case it was a 8 bit address we can not know whether it was a register
    or a register pair. We should let the instruction decide which it should
    have been. That's why the returned code for registers and pairs is both
    R or @R.
    """
        
    global Asm
    
    pointer = dec.Asm.Parse_Pointer
    param = assem.GetWord().upper()
    allregisters = ('R0','R1','R2','R3','R4','R5','R6','R7','R8','R9','R10','R11','R12','R13','R14','R15')
    
    if len(param) == 0:
        errors.DoError('badoper',False)
        return ('!',0)

    if param[0] in ('#/=\\'):
        # Parameter is an immediate prefix
        dec.Asm.Parse_Pointer = pointer
        prefix = assem.NowChar(True)
        value = assem.EvalExpr()
        if prefix == '#':
            data = value[0]
        elif prefix == '/':
            data = value[0] >> 8
        elif prefix == '=':
            data = value[0] >> 16
        else:
            data = value[0] >> 24
        return ('#',data)

    elif '(' in param:
        # Should be index mode
        dec.Asm.Parse_Pointer = pointer
        offset = assem.EvalExpr()
        if assem.NowChar(True) != '(':
            errors.DoError('badoper',False)
            return ('1',0)
        pointer = dec.Asm.Parse_Pointer
        param = assem.GetWord().upper()
        if param[:-1] in allregisters:
            regnr = int(param[1:-1])
            if param[-1] != ')':
                errors.DoError('badoper',False)
                return ('!',0)
        else:
            # Address must resolve to a 4 bit register
            dec.Asm.Parse_Pointer = pointer
            value = assem.EvalExpr()
            if dec.Asm.Pass == 2:
                if value[0] < 0 or value[0] > 255 or (value[0] & 240) == 224:
                    errors.DoError('range',False)
                    regnr = 0       # use dummy value
                else:
                    if (value[0] & 240) != dec.Asm.Z8rp:
                        errors.DoError('range',False)
                        regnr = 0   # us dummy value if it's not a working register
                    else:
                        regnr = value[0] & 15
            else:
                regnr = 0           # use dummy value during pass 1
            if assem.NowChar(True) != ')':
                errors.DoError('badoper',False)
                return ('!',0)
        return ('X',regnr | 224,offset[0])

    elif param in allregisters:
        # Parameter is a register
        regnr = int(param[1:]) | 224
        return ('r',regnr)

    elif param in ('@R0','@R1','@R2','@R3','@R4','@R5','@R6','@R7','@R8','@R9','@R10','@R11','@R12','@R13','@R14','@R15'):
        # Parameter is an indirect register
        regnr = int(param[2:]) | 224
        return ('@r',regnr)
        
    elif param in ('RR0','RR2','RR4','RR6','RR8','RR10','RR12','RR14'):
        # Parameter is a register pair
        regnr = int(param[2:]) | 224
        return ('rr',regnr)
    
    elif param in ('@RR0','@RR2','@RR4','@RR6','@RR8','@RR10','@RR12','@RR14'):
        # Parameter is an indirect register pair
        regnr = int(param[3:]) | 224
        return ('@rr',regnr)
        
    else:
        # Must be a normal expression now (8-bit register or pair)
        if param[0] == '@':
            # Can be either indirect mode or an octal number
            if len(param) > 1 and (param[1] in '01234567'):
                # Treat this as an octal number
                prefix = ''
                dec.Asm.Parse_Pointer = pointer
            else:
                # Treat it as an indirect prefix
                prefix = '@'
                dec.Asm.Parse_Pointer = pointer + 1
        else:
            prefix = ''
            dec.Asm.Parse_Pointer = pointer
        
        value = assem.EvalExpr()
        
        if dec.Asm.Pass == 2:
            # Only do range checks during pass 2
            # Legal values are from $00 to $FF, excluding $E0 to $EF
            if value[0] < 0 or value[0] > 255 or (value[0] & 240) == 224:
                errors.DoError('range',False)
                return ('!',0)

        bank = value[0] & 240    # Mask value with $F0
        if not value[1] and dec.Asm.Z8rp == bank:
            # Make it a 4-bit register if not forward referenced and in current bank
            return (prefix+'r',value[0]&15 | 224)
        else:
            return (prefix+'R',value[0])
        
#-----------------------------------------------------------------------------

def DirRP():

    global Asm
    
    if MissingOperand():
        return

    value = assem.EvalExpr()
    
    if value[1]:
        # Forward referenced labels are not allowed
        errors.DoError('',False)
    else:
        # Check range
        if value[0] < 0 or value[0] > 255 or (value[0] & 15) != 0 or (value[0] & 240) == 224:
            errors.DoError('range',False)
        else:
            dec.Asm.Z8rp = value[0]

    NoMore()    

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    

