#------------------------------------------------------------------------------
#
#   crace1202.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   This cross overlay will handle the assembling of ace1202
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags
    
    assem.CheckVersions(crossversion, minversion)
    
    dec.Asm.Instructions = {
        'IFC'   : (Inherent, int('19',16), '1'),
        'IFNC'  : (Inherent, int('1F',16), '1'),
        'INTR'  : (Inherent, int('00',16), '5'),
        'INVC'  : (Inherent, int('12',16), '1'),
        'NOP'   : (Inherent, int('1C',16), '1'),
        'RC'    : (Inherent, int('1E',16), '1'),
        'RET'   : (Inherent, int('17',16), '5'),
        'RETI'  : (Inherent, int('18',16), '5'),
        'SC'    : (Inherent, int('1D',16), '1'),

        'JP'    : (Relative, int('C0',16), '1'),
        
        'JMP'   : (Jumps, ('24','7E'), ('4','3')),
        'JSR'   : (Jumps, ('23','7F'), ('5','3')),

        'CLR'   : (Singles, ('16','0F','7D'), ('1','1','2')),
        'DEC'   : (Singles, ('1A','0C','7B'), ('1','1','2')),
        'INC'   : (Singles, ('1B','0D','7C'), ('1','1','2')),
        'RLC'   : (Singles, ('15','00','79'), ('1','','2')),
        'RRC'   : (Singles, ('13','00','7A'), ('1','','2')),

        'ADC'   : (Multiple, ('60','42','02','70','00','00','00'),('2','2','1','3','','','')),
        'ADD'   : (Multiple, ('66','43','03','71','00','00','00'),('2','2','1','3','','','')),
        'AND'   : (Multiple, ('61','50','04','72','00','00','00'),('2','2','1','3','','','')),
        'IFEQ'  : (Multiple, ('65','56','09','76','26','20','00'),('2','2','1','2','3','3','')),
        'IFGT'  : (Multiple, ('67','55','0A','77','27','00','00'),('2','2','1','2','3','','')),
        'IFLT'  : (Multiple, ('00','00','00','00','28','00','00'),('','','','','3','','')),
        'IFNE'  : (Multiple, ('57','54','0B','78','00','00','00'),('2','2','1','2','','','')),
        'LD'    : (Multiple, ('51','46','0E','52','25','21','22'),('2','2','1','3','3','3','3')),
        'OR'    : (Multiple, ('62','44','05','73','00','00','00'),('2','2','1','3','','','')),
        'ST'    : (Multiple, ('00','47','11','40','00','00','00'),('','2','2','3','','','')),
        'SUBC'  : (Multiple, ('63','53','06','74','00','00','00'),('2','2','1','3','','','')),
        'XOR'   : (Multiple, ('64','45','07','75','00','00','00'),('2','2','1','3','','','')),

        'IFBIT' : (Bits, ('A0','58','00'),('1','2','')),
        'LDC'   : (Bits, ('00','80','00'),('','2','')),
        'RBIT'  : (Bits, ('00','68','B8'),('','2','2')),
        'SBIT'  : (Bits, ('00','48','B0'),('','2','2')),
        'STC'   : (Bits, ('00','88','00'),('','2',''))
        
    }

    dec.Asm.Timing_Length = 1

    dec.Asm.Memory = 0              # Select code memory as default
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = (1 << 12) - 1
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = False
    
    dec.Ace_Maxjmp = int('0FFF',16)
    dec.Ace_Minjmp = int('0800',16)

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    return False     # No extra directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    return
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)
    
#-----------------------------------------------------------------------------

def MissingOperand():

    """
    A useful function which raises an error if no operand is given.
    """

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    """
    A useful function which tests if no more parameters are given when we
    don't expect any more at the end of the operand parsing.
    """

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)


#-----------------------------------------------------------------------------

def Inherent():

    global Asm

    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

#-----------------------------------------------------------------------------

def Relative():

    global Asm

    if MissingOperand():
        return
        
    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1]

    value = assem.EvalExpr()[0]

    offset = value - dec.Asm.BOL_Address - 1
    
    if dec.Asm.Pass == 2 and (offset < -32 or offset > 31):
        errors.DoError('range', False)
    
    if dec.Asm.Pass == 2:
        if offset < 0:
            offset = offset * -1
        else:
            opcode = opcode + 32
    else:
        offset = 0    
    
    offset = (offset & 63)
    
    target.CodeByte(opcode + offset)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

    NoMore()    

#-----------------------------------------------------------------------------

def Jumps():

    """
    Jump instructions
    - Absolute
    - [#,X]
    """

    global Asm

    if MissingOperand():
        return
    
    if assem.NowChar() == '[':
        # Should be [#,X] now
        assem.IncParsePointer()
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16)
        if opcode == 0:
            errors.DoError('badoper', False)
            return
        else:
            if assem.NowChar() == '#':
                # Ignore leading #
                assem.IncParsePointer()
            value = assem.EvalExpr()[0]
            target.CodeByte(opcode)
            target.CodeByte(value)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
            if not assem.MoreParameters():
                errors.DoError('missoper', False)
            if dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+3].upper() != 'X] ':
                errors.DoError('badoper', False)
            return
    
    else:
        # Must be absolute now
        dest = assem.EvalExpr()[0]
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16))
        target.CodeWord(dest)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][1][1]
        
        if dec.Asm.Pass == 2 and (dest < dec.Ace_Minjmp or dest > dec.Ace_Maxjmp):
            errors.DoError('range', False)
    
    NoMore()

#-----------------------------------------------------------------------------

def Multiple():

    """
    Multiple operand instructions
    - #
    - Direct
    - [X]
    - [#,X]
    - X,#
    - Direct,#
    - Direct,Direct
    """
    
    global Asm

    if MissingOperand():
        return

    param = dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper()
    
    if param == 'A,':
        # First operand is A
        assem.NowChar(True)
        assem.MoreParameters()
        
        if assem.NowChar() in '#/=\\':
            # It is direct mode
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16)
            if opcode == 0:
                errors.DoError('badoper', False)
            else:
                prefix = assem.NowChar(True)
            
                value = assem.EvalExpr()[0]
            
                if prefix == '/':
                    value = value >> 8
                elif prefix == '=':
                    value = value >> 16
                elif prefix == '\\':
                    value = value >> 24
                
                target.CodeByte(opcode)
                target.CodeByte(value)
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        
        elif assem.NowChar() == '[':
            # It's some kind of indexed mode
            assem.IncParsePointer()
            
            param = dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper()
            if param == 'X]':
                # Non offset indexed mode
                opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16)
                if opcode == 0:
                    errors.DoError('badoper', False)
                else:
                    target.CodeByte(opcode)
                    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
                    dec.Asm.Parse_Pointer = dec.Asm.Parse_Pointer + 2
            else:
                # Must be offset indexed mode
                opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][3],16)
                if opcode == 0:
                    errors.DoError('badoper', False)
                else:
                    if assem.NowChar() == '#':
                        # Ignore leading #
                        assem.IncParsePointer()
                    value = assem.EvalExpr()[0]
                    target.CodeByte(opcode)
                    target.CodeByte(value)
                    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][3]
                    if not assem.MoreParameters():
                        errors.DoError('missoper', False)
                    if dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+3].upper() != 'X] ':
                        errors.DoError('badoper', False)
                    return
        else:
            # Second parameter must be direct mode
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16)
            if opcode == 0:
                errors.DoError('badoper', False)
            else:
                value = assem.EvalExpr()[0]
                target.CodeByte(opcode)
                target.CodeByte(value)
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][1][1]
                if dec.Asm.Pass == 2 and (value < 0 or value > 255):
                    errors.DoError('range', False)
            
    elif param == 'X,':
        # First operand is X
        assem.NowChar(True)
        assem.MoreParameters()
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][4],16)
        if opcode == 0:
            errors.DoError('badoper', False)
        else:
            prefix = assem.NowChar(True)

            value = assem.EvalExpr()[0]

            if prefix == '/':
                value = value >> 8
            elif prefix == '=':
                value = value >> 16
            elif prefix == '\\':
                value = value >> 24

            target.CodeByte(opcode)
            target.CodeWord(value)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][4]
        
    else:
        # Must be direct mode
        
        parm1 = assem.EvalExpr()[0]
        
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
        
        if assem.NowChar() in '#/=\\':
            # Second parameter is immediate
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][5],16)
            if opcode == 0:
                errors.DoError('badoper', False)
            else:
                prefix = assem.NowChar(True)
                parm2 = assem.EvalExpr()[0]
                
                if prefix == '/':
                    parm2 = parm2 >> 8
                elif prefix == '=':
                    parm2 = parm2 >> 16
                elif prefix == '\\':
                    parm2 = parm2 >> 24
                
                if dec.Asm.Pass == 2 and (parm1 < 0 or parm1 > 255):
                    errors.DoError('range', False)
                target.CodeByte(opcode)
                target.CodeByte(parm1)
                target.CodeByte(parm2)
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][5]
                
        else:
            # Second operand should be direct now
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][6],16)
            if opcode == 0:
                errors.DoError('badoper', False)
            else:
                parm2 = assem.EvalExpr()[0]
                if dec.Asm.Pass == 2 and (parm1 < 0 or parm1 > 255 or parm2 < 0 or parm2 > 255):
                    errors.DoError('range', False)
                target.CodeByte(opcode)
                target.CodeByte(parm2)
                target.CodeByte(parm1)
                dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][6]

    NoMore()
        
#-----------------------------------------------------------------------------
def Singles():

    """
    Single operand instructions
    - A
    - X
    - Direct
    """

    global Asm

    if MissingOperand():
        return
    
    param = dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper()
    
    if param == 'A ':
        # A mode
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
    elif param == 'X ':
        # X mode
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16)
        if opcode != 00:
            target.CodeByte(opcode)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
        else:
            errors.DoError('badoper', False)
    
    else:
        # Must be direct mode now
        value = assem.EvalExpr()[0]
        
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16))
        target.CodeByte(value)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
        
        if dec.Asm.Pass == 2 and (value < 0 or value > 255):
            errors.DoError('range', False)
        
        NoMore()
    
#-----------------------------------------------------------------------------
def Bits():

    """
    Bit instructions
    - A
    - Direct
    - [X]
    """
    
    global Asm
    
    if MissingOperand():
        return
    
    if assem.NowChar() == '#':
        # This is optional
        assem.IncParsePointer()
        
    bit = assem.EvalExpr()[0]

    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    param = dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper()
    
    if param == 'A ':
        # Second operand is A
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16)
        if opcode == 0:
            errors.DoError('badoper', False)
            return
        else:
            assem.IncParsePointer()
            target.CodeByte(opcode + bit)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
    
    elif assem.NowChar() == '[':
        # Secnd parameter should be [X]
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16)
        if opcode == 0:
            errors.DoError('badoper', False)
            return
        else:
            assem.GetWord()
            target.CodeByte(opcode + bit)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
    
    else:
        # Second parameter is Direct
        direct = assem.EvalExpr()[0]
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16)
        target.CodeByte(opcode + bit)
        target.CodeByte(direct)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
        
        if dec.Asm.Pass == 2 and (direct < 0 or direct > 255):
            errors.DoError('range', False)

    if dec.Asm.Pass == 2 and (bit < 0 or bit > 7):
        errors.DoError('range', False)
    
    NoMore()        

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    
