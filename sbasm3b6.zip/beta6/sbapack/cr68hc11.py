#------------------------------------------------------------------------------
#
#   cr68hc11.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   This cross overlay will handle the assembling of 68HC11
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    """
    Initialize this cross overlay.
    """

    global Asm, Flags
    
    assem.CheckVersions(crossversion, minversion)

    dec.Asm.Instructions = {
        'ABA'  : (Implied,'1B','2'),
        'ABX'  : (Implied,'3A','3'),
        'ABY'  : (Implied,'183A','4'),
        'ASLA' : (Implied,'48','2'),
        'ASLB' : (Implied,'58','2'),
        'ASLD' : (Implied,'05','3'),
        'ASRA' : (Implied,'47','2'),
        'ASRB' : (Implied,'57','2'),
        'CBA'  : (Implied,'11','2'),
        'CLC'  : (Implied,'0C','2'),
        'CLI'  : (Implied,'0E','2'),
        'CLRA' : (Implied,'4F','2'),
        'CLRB' : (Implied,'5F','2'),
        'CLRD' : (Implied,'4F5F','4'),
        'CLV'  : (Implied,'0A','2'),
        'COMA' : (Implied,'43','2'),
        'COMB' : (Implied,'53','2'),
        'COMD' : (Implied,'4353','4'),
        'DAA'  : (Implied,'19','2'),
        'DECA' : (Implied,'4A','2'),
        'DECB' : (Implied,'5A','2'),
        'DES'  : (Implied,'34','3'),
        'DEX'  : (Implied,'09','3'),
        'DEY'  : (Implied,'1809','4'),
        'FDIV' : (Implied,'03','41'),
        'IDIV' : (Implied,'02','41'),
        'INCA' : (Implied,'4C','2'),
        'INCB' : (Implied,'5C','2'),
        'INS'  : (Implied,'31','3'),
        'INX'  : (Implied,'08','3'),
        'INY'  : (Implied,'1808','4'),
        'LSLA' : (Implied,'48','2'),
        'LSLB' : (Implied,'58','2'),
        'LSLD' : (Implied,'05','3'),
        'LSRA' : (Implied,'44','2'),
        'LSRB' : (Implied,'54','2'),
        'LSRD' : (Implied,'04','3'),
        'MUL'  : (Implied,'3D','10'),
        'NEGA' : (Implied,'40','2'),
        'NEGB' : (Implied,'50','2'),
        'NOP'  : (Implied,'01','2'),
        'PSHA' : (Implied,'36','3'),
        'PSHB' : (Implied,'37','3'),
        'PSHD' : (Implied,'3736','6'),
        'PSHX' : (Implied,'3C','4'),
        'PSHY' : (Implied,'183C','5'),
        'PULA' : (Implied,'32','4'),
        'PULB' : (Implied,'33','4'),
        'PULD' : (Implied,'3233','8'),
        'PULX' : (Implied,'38','5'),
        'PULY' : (Implied,'1838','6'),
        'ROLA' : (Implied,'49','2'),
        'ROLB' : (Implied,'59','2'),
        'ROLD' : (Implied,'5949','4'),
        'RORA' : (Implied,'46','2'),
        'RORB' : (Implied,'56','2'),
        'RORD' : (Implied,'4656','4'),
        'RTI'  : (Implied,'3B','12'),
        'RTS'  : (Implied,'39','5'),
        'SBA'  : (Implied,'10','2'),
        'SEC'  : (Implied,'0D','2'),
        'SEI'  : (Implied,'0F','2'),
        'SEV'  : (Implied,'0B','2'),
        'STOP' : (Implied,'CF','2'),
        'SWI'  : (Implied,'3F','14'),
        'TAB'  : (Implied,'16','2'),
        'TAP'  : (Implied,'06','2'),
        'TBA'  : (Implied,'17','2'),
        'TEST' : (Implied,'00','5+'),
        'TPA'  : (Implied,'07','2'),
        'TSTA' : (Implied,'4D','2'),
        'TSTB' : (Implied,'5D','2'),
        'TSX'  : (Implied,'30','3'),
        'TSY'  : (Implied,'1830','4'),
        'TXS'  : (Implied,'35','3'),
        'TYS'  : (Implied,'1835','4'),
        'WAI'  : (Implied,'3E','14'),
        'XGDX' : (Implied,'8F','3'),
        'XGDY' : (Implied,'188F','4'),

        'BCC'  : (Branch,'24','3'),
        'BCS'  : (Branch,'25','3'),
        'BEQ'  : (Branch,'27','3'),
        'BGE'  : (Branch,'2C','3'),
        'BGT'  : (Branch,'2E','3'),
        'BHI'  : (Branch,'22','3'),
        'BHS'  : (Branch,'24','3'),
        'BLE'  : (Branch,'2F','3'),
        'BLO'  : (Branch,'25','3'),
        'BLS'  : (Branch,'23','3'),
        'BLT'  : (Branch,'2D','3'),
        'BMI'  : (Branch,'2B','3'),
        'BNE'  : (Branch,'26','3'),
        'BPL'  : (Branch,'2A','3'),
        'BRA'  : (Branch,'20','3'),
        'BRN'  : (Branch,'21','3'),
        'BSR'  : (Branch,'8D','6'),
        'BVC'  : (Branch,'28','3'),
        'BVS'  : (Branch,'29','3'),

        'ADCA' : (Multi,('89','99','B9','A9','18A9'),('2','3','4','4','5'),False),
        'ADCB' : (Multi,('C9','D9','F9','E9','18E9'),('2','3','4','4','5'),False),
        'ADDA' : (Multi,('8B','9B','BB','AB','18AB'),('2','3','4','4','5'),False),
        'ADDB' : (Multi,('CB','DB','FB','EB','18EB'),('2','3','4','4','5'),False),
        'ADDD' : (Multi,('C3','D3','F3','E3','18E3'),('4','5','6','6','7'),True),
        'ANDA' : (Multi,('84','94','B4','A4','18A4'),('2','3','4','4','5'),False),
        'ANDB' : (Multi,('C4','D4','F4','E4','18E4'),('2','3','4','4','5'),False),
        'ASL'  : (Multi,('00','00','78','68','1868'),('','','6','6','7'),False),
        'ASR'  : (Multi,('00','00','77','67','1867'),('','','6','6','7'),False),
        'BITA' : (Multi,('85','95','B5','A5','18A5'),('2','3','4','4','5'),False),
        'BITB' : (Multi,('C5','D5','F5','E5','18E5'),('2','3','4','4','5'),False),
        'CLR'  : (Multi,('00','00','7F','6F','186F'),('','','6','6','7'),False),
        'CMPA' : (Multi,('81','91','B1','A1','18A1'),('2','3','4','4','5'),False),
        'CMPB' : (Multi,('C1','D1','F1','E1','18E1'),('2','3','4','4','5'),False),
        'COM'  : (Multi,('00','00','73','63','1863'),('','','6','6','7'),False),
        'CPD'  : (Multi,('1A83','1A93','1AB3','1AA3','CDA3'),('5','6','7','7','7'),True),
        'CPX'  : (Multi,('8C','9C','BC','AC','CDAC'),('4','5','6','6','7'),True),
        'CPY'  : (Multi,('188C','189C','18BC','1AAC','18AC'),('5','6','7','7','7'),True),
        'DEC'  : (Multi,('00','00','7A','6A','186A'),('','','6','6','7'),False),
        'EORA' : (Multi,('88','98','B8','A8','18A8'),('2','3','4','4','5'),False),
        'EORB' : (Multi,('C8','D8','F8','E8','18E8'),('2','3','4','4','5'),False),
        'INC'  : (Multi,('00','00','7C','6C','186C'),('','','6','6','7'),False),
        'JMP'  : (Multi,('00','00','7E','6E','186E'),('','','3','3','4'),False),
        'JSR'  : (Multi,('00','9D','BD','AD','18AD'),('','5','6','6','7'),False),
        'LDA'  : (Multi,('86','96','B6','A6','18A6'),('2','3','4','4','5'),False),
        'LDAA' : (Multi,('86','96','B6','A6','18A6'),('2','3','4','4','5'),False),
        'LDB'  : (Multi,('C6','D6','F6','E6','18E6'),('2','3','4','4','5'),False),
        'LDAB' : (Multi,('C6','D6','F6','E6','18E6'),('2','3','4','4','5'),False),
        'LDD'  : (Multi,('CC','DC','FC','EC','18EC'),('3','4','5','5','6'),True),
        'LDAD' : (Multi,('CC','DC','FC','EC','18EC'),('3','4','5','5','6'),True),
        'LDS'  : (Multi,('8E','9E','BE','AE','18AE'),('3','4','5','5','6'),True),
        'LDX'  : (Multi,('CE','DE','FE','EE','CDEE'),('3','4','5','5','6'),True),
        'LDY'  : (Multi,('18CE','18DE','18FE','1AEE','18EE'),('4','5','6','6','6'),True),
        'LSL'  : (Multi,('00','00','78','68','1868'),('','','6','6','7'),False),
        'LSR'  : (Multi,('00','00','74','64','1864'),('','','6','6','7'),False),
        'NEG'  : (Multi,('00','00','70','60','1860'),('','','6','6','7'),False),
        'ORAA' : (Multi,('8A','9A','BA','AA','18AA'),('2','3','4','4','5'),False),
        'ORAB' : (Multi,('CA','DA','FA','EA','18EA'),('2','3','4','4','5'),False),
        'ROL'  : (Multi,('00','00','79','69','1869'),('','','6','6','7'),False),
        'ROR'  : (Multi,('00','00','76','66','1866'),('','','6','6','7'),False),
        'SBCA' : (Multi,('82','92','B2','A2','18A2'),('2','3','4','4','5'),False),
        'SBCB' : (Multi,('C2','D2','F2','E2','18E2'),('2','3','4','4','5'),False),
        'STA'  : (Multi,('00','97','B7','A7','18A7'),('','3','4','4','5'),False),
        'STAA' : (Multi,('00','97','B7','A7','18A7'),('','3','4','4','5'),False),
        'STB'  : (Multi,('00','D7','F7','E7','18E7'),('','3','4','4','5'),False),
        'STAB' : (Multi,('00','D7','F7','E7','18E7'),('','3','4','4','5'),False),
        'STD'  : (Multi,('00','DD','FD','ED','18ED'),('','4','5','5','6'),False),
        'STAD' : (Multi,('00','DD','FD','ED','18ED'),('','4','5','5','6'),False),
        'STS'  : (Multi,('00','9F','BF','AF','18AF'),('','4','5','5','6'),False),
        'STX'  : (Multi,('00','DF','FF','EF','CDEF'),('','4','5','5','6'),False),
        'STY'  : (Multi,('00','18DF','18FF','1AEF','18EF'),('','5','6','6','6'),False),
        'SUBA' : (Multi,('80','90','B0','A0','18A0'),('2','3','4','4','5'),False),
        'SUBB' : (Multi,('C0','D0','F0','E0','18E0'),('2','3','4','4','5'),False),
        'SUBD' : (Multi,('83','93','B3','A3','18A3'),('4','5','6','6','7'),True),
        'TST'  : (Multi,('00','00','7D','6D','186D'),('','','6','6','7'),False),

        'BRCLR': (Bits,('13','1F','181F'),('6','7','8')),
        'BRSET': (Bits,('12','1E','181E'),('6','7','8')),
        'BCLR' : (Bits,('15','1D','181D'),('6','7','8')),
        'BSET' : (Bits,('14','1C','181C'),('6','7','8'))

    }

    dec.Asm.Timing_Length = 2

    dec.Asm.Memory = 0
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = dec.MAX16
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = True

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    """
    No extra directives for this Cross overlay
    """

    return False     # We didn't handle any directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    """
    No need to do any cleaning.
    """

    return    
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    """
    Find and decode the current mnemonic.
    """

    global Asm

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def MissingOperand():

    """
    An operand must follow. Raise an error if it's not.
    """
    
    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    """
    No more operands shoudl follow. Raise a warning if more parameters follow.
    """

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)
        
#-----------------------------------------------------------------------------

def Implied():

    """
    Handle implied addressing mode.
    Simply save the opcode and we're done with it.
    """

    global Asm

    opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16)
    Code(opcode)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

#-----------------------------------------------------------------------------

def Branch():

    """
    Handle branch instructions.
    Displacement is destinaiton - current address - 2
    """

    global Asm

    if MissingOperand():
        return

    value = assem.EvalExpr()
    offset = value[0] - dec.Asm.BOL_Address - 2
    
    if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
        errors.DoError('range', False)

    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16))
    target.CodeByte(offset)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
    NoMore()

#-----------------------------------------------------------------------------

def Multi():

    """
    Handle multiple operand type instructions
    - Immediate mode
    - Direct page mode
    - Extended mode
    - Indexed X mode
    - Indexed Y mode
    """
    
    global Asm

    if MissingOperand():
        return

    if assem.NowChar() in '#/=\\':
        # It is direct addressing mode
        prefix = assem.NowChar(True)
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][0]
        if opcode == '00':
            errors.DoError('badoper', False)
            return
        
        value = assem.EvalExpr()[0]
        if prefix == '/':
            value = value >> 8
        elif prefix == '=':
            value = value >> 16
        elif prefix == '\\':
            value = value >> 24
        
        Code(int(opcode,16))
        if dec.Asm.Instructions[dec.Asm.Mnemonic][3]:
            target.CodeWord(value)
        else:
            target.CodeByte(value)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        
        NoMore()
        return
    
    if assem.NowChar() == ',':
        # zero offset indexed mode
        value = 0
        length = 1
        assem.MoreParameters()
        indexreg = assem.NowChar(True).upper()
        if indexreg == 'X':
            index = 3
        elif indexreg == 'Y':
            index = 4
        else:
            errors.DoError('badoper', False)
            return

    elif dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper() == 'X ':
        # Zero offset indexed X mode
        value = 0
        length = 1
        index = 3
        assem.IncParsePointer()
        
    elif dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper() == 'Y ':
        # Zero offset indexed Y mode
        value = 0
        length = 1
        index = 4
        assem.IncParsePointer()

    else:
        # Can be direct mode, extended mode or offset,indexed mode from here
        prefix = ''
        if assem.NowChar() in '<>':
            prefix = assem.NowChar(True)
        
        dest = assem.EvalExpr()
        value = dest[0]
        
        if assem.MoreParameters():
            # Handle indexed mode
            length = 1
            indexreg = assem.NowChar(True).upper()
            if indexreg == 'X':
                index = 3
            elif indexreg == 'Y':
                index = 4
            else:
                errors.DoError('badoper', False)
                index = 3
            if dec.Asm.Pass == 2 and (value > 255 or value < 0):
                errors.DoError('range', False)
            
        else:
            # Direct or extended mode
            if dec.Asm.Instructions[dec.Asm.Mnemonic][1][1] == '00' or prefix == '>':
                # Use extended mode because direct mode doesn't exist or forced extended
                index = 2
                length = 2
            elif prefix == '<':
                # Forced direct mode
                index = 1
                length = 1
                if dec.Asm.Pass == 2 and value > 255:
                    errors.DoError('range', False)
            else:
                # Let the assembler deside whether it's direct or extended
                if dest[1]:
                    # Forward referenced label used, use extended
                    index = 2
                    length = 2
                else:
                    if value > 255:
                        index = 2
                        length = 2
                    else:
                        index = 1
                        length = 1
        
    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][index]
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]
    Code(int(opcode,16))
    if length == 1:
        target.CodeByte(value)
    else:
        target.CodeWord(value)
        
    NoMore()

#-----------------------------------------------------------------------------

def Bits():

    """
    Handle Bit instructions
    Both bit set/clr as well as branch bit set/clr instructions are handled
    by this routine.
    """

    global Asm

    if MissingOperand():
        return
        
    index = 0
    if assem.NowChar() == ',':
        # Zero offset indexed
        memory = 0
        assem.MoreParameters()
    else:
        # If first parameter is X or Y we still have 0 offset
        if dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper() in ('X,','Y,'):
            memory = 0
            index = -1
        else:
            # direct address or 8-bit unsigned offset
            memory = assem.EvalExpr()[0]
            if not assem.MoreParameters():
                # We expected more parameters
                errors.DoError('missoper', False)
                return
    
    if dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper() == 'X,':
        # It is index register X mode
        index = 1
        assem.IncParsePointer()
        if not assem.MoreParameters():
            # We expected more parameters
            errors.DoError('missoper', False)
            return
    elif dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper() == 'Y,':
        # It is index register Y mode
        index = 2
        assem.IncParsePointer()
        if not assem.MoreParameters():
            # We expected more parameters
            errors.DoError('missoper', False)
            return
    else:
        # It was not an indexed mode
        if index == -1:
            # We expected indexed mode, but didn't get it
            errors.DoError('badoper', False)
            return
        index = 0    
    # Get immediate data mask
    prefix = assem.NowChar()
    if prefix in '#/=\\':
        # An immediate prefix was present
        assem.IncParsePointer()
    else:
        # No prefix was given, asume # 
        prefix = '#'
    value = assem.EvalExpr()[0]
    
    if prefix == '/':
        value = value >> 8
    elif prefix == '=':
        value = value >> 16
    elif prefix == '\\':
        value = value >> 24
    
    if dec.Asm.Mnemonic[1] == 'R':
        # It's one of the branch instructions
        if not assem.MoreParameters():
            # We expected more parameters
            errors.DoError('missoper', False)
            return
        
        dest = assem.EvalExpr()[0]
        offset = dest - dec.Asm.BOL_Address - 4
        if index == 2:
            offset = offset - 1
        if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
            errors.DoError('range', False)
        
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16))
        target.CodeByte(memory)
        target.CodeByte(value)
        target.CodeByte(offset)
    else:
        Code(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][index],16))
        target.CodeByte(memory)
        target.CodeByte(value)

    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][index]        
    
    if dec.Asm.Pass == 2 and (memory < 0 or memory > 255):
        # Test this way back here, because it is not very important
        errors.DoError('range', False)

    NoMore()

#-----------------------------------------------------------------------------

def Code(opcode):

    """
    Write an opcode to the target file.
    If the opcode > 255 then a pre-byte must be saved first
    """
    
    if opcode > 255:
        target.CodeByte(opcode >> 8)
    target.CodeByte(opcode)

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    
