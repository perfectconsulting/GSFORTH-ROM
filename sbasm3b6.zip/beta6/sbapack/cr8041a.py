#------------------------------------------------------------------------------
#
#   cr8041a.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   Cross Overlay for the 8048A family of processors
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target
import cr8048

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags, Error_List

    assem.CheckVersions(crossversion, minversion)
    crlib = cr8048
    
    # Declare the tuples for the MOV instruction seperately, otherwise the line gets sooooooo long
    movparams  = ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','R0,A','R1,A','R2,A','R3,A','R4,A','R5,A','R6,A','R7,A','@R0,A','@R1,A','A,#','R0,#','R1,#','R2,#','R3,#','R4,#','R5,#','R6,#','R7,#','@R0,#','@R1,#','A,PSW','PSW,A','A,T','T,A','STS,A')
    movopcodes = ('F8',  'F9',  'FA',  'FB',  'FC',  'FD',  'FE',  'FF',  'F0',   'F1',   'A8',  'A9',  'AA',  'AB',  'AC',  'AD',  'AE',  'AF',  'A0',   'A1',   '23', 'B8',  'B9',  'BA',  'BB',  'BC'  ,'BD',  'BE',  'BF',  'B0',   'B1',   'C7',   'D7',   '42', '62' ,'90')
    movtimes   = ('1',   '1',   '1',   '1',   '1',   '1',   '1',   '1',   '1',    '1',    '1',   '1',   '1',   '1',   '1',   '1',   '1',   '1',   '1',    '1',    '2',  '2',   '2',   '2',   '2',   '2',   '2',   '2',   '2',   '2',    '2',    '1',    '1',    '1',  '1'  ,'1')
    
    dec.Asm.Instructions = {
    'JB0'  : (crlib.Branch, int('12',16),'2'),
    'JB1'  : (crlib.Branch, int('32',16),'2'),
    'JB2'  : (crlib.Branch, int('52',16),'2'),
    'JB3'  : (crlib.Branch, int('72',16),'2'),
    'JB4'  : (crlib.Branch, int('92',16),'2'),
    'JB5'  : (crlib.Branch, int('B2',16),'2'),
    'JB6'  : (crlib.Branch, int('D2',16),'2'),
    'JB7'  : (crlib.Branch, int('F2',16),'2'),
    'JC'   : (crlib.Branch, int('F6',16),'2'),
    'JF0'  : (crlib.Branch, int('B6',16),'2'),
    'JF1'  : (crlib.Branch, int('76',16),'2'),
    'JNC'  : (crlib.Branch, int('E6',16),'2'),
    'JNT0' : (crlib.Branch, int('26',16),'2'),
    'JNT1' : (crlib.Branch, int('46',16),'2'),
    'JNZ'  : (crlib.Branch, int('96',16),'2'),
    'JTF'  : (crlib.Branch, int('16',16),'2'),
    'JT0'  : (crlib.Branch, int('36',16),'2'),
    'JT1'  : (crlib.Branch, int('56',16),'2'),
    'JZ'   : (crlib.Branch, int('c6',16),'2'),
    'JNIBF': (crlib.Branch, int('D6',16),'2'),
    'JOBF' : (crlib.Branch, int('86',16),'2'),

    'CLR'  : (crlib.Singles, ('A','C','F0','F1'),('27','97','85','A5'),('1','1','1','1')),
    'CPL'  : (crlib.Singles, ('A','C','F0','F1'),('37','A7','95','B5'),('1','1','1','1')),
    'DA'   : (crlib.Singles, ('A',),('57',),('1',)),    
    'DEC'  : (crlib.Singles, ('A','R0','R1','R2','R3','R4','R5','R6','R7'),('07','C8','C9','CA','CB','CC','CD','CE','CF'),('1','1','1','1','1','1','1','1','1')),    
    'INC'  : (crlib.Singles, ('A','R0','R1','R2','R3','R4','R5','R6','R7','@R0','@R1'),('17','18','19','1A','1B','1C','1D','1E','1F','10','11'),('1','1','1','1','1','1','1','1','1','1','1')),    
    'RL'   : (crlib.Singles, ('A',),('E7',),('1',)),
    'RLC'  : (crlib.Singles, ('A',),('F7',),('1',)),
    'RR'   : (crlib.Singles, ('A',),('77',),('1',)),
    'RRC'  : (crlib.Singles, ('A',),('67',),('1',)),
    'SWAP' : (crlib.Singles, ('A',),('47',),('1',)),
    'DIS'  : (crlib.Singles, ('I','TCNTI'),('15','35'),('1','1')),
    'EN'   : (crlib.Singles, ('I','TCNTI','DMA','FLAGS'),('05','25','E5','F5'),('1','1','1','1')),
    'JMPP' : (crlib.Singles, ('@A',),('B3',),('2',)),
    'SEL'  : (crlib.Singles, ('RB0','RB1'),('C5','D5'),('1','1')),
    'STOP' : (crlib.Singles, ('TCNT',),('65',),('1',)),
    'STRT' : (crlib.Singles, ('T','CNT'),('55','45'),('1','1')),

    'ADD'  : (crlib.Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','A,#'),('68','69','6A','6B','6C','6D','6E','6F','60','61','03'),('1','1','1','1','1','1','1','1','1','1','2')),
    'ADDC' : (crlib.Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','A,#'),('78','79','7A','7B','7C','7D','7E','7F','70','71','13'),('1','1','1','1','1','1','1','1','1','1','2')),
    'ANL'  : (crlib.Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','A,#','P1,#','P2,#'),('58','59','5A','5B','5C','5D','5E','5F','50','51','53','99','9A'),('1','1','1','1','1','1','1','1','1','1','2','2','2')),
    'ORL'  : (crlib.Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','A,#','P1,#','P2,#'),('48','49','4A','4B','4C','4D','4E','4F','40','41','43','89','8A'),('1','1','1','1','1','1','1','1','1','1','2','2','2')),
    'XCH'  : (crlib.Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1'),('28','29','2A','2B','2C','2D','2E','2F','20','21'),('1','1','1','1','1','1','1','1','1','1')),
    'XCHD' : (crlib.Pairs, ('A,@R0','A,@R1'),('30','31'),('1','1')),
    'XRL'  : (crlib.Pairs, ('A,R0','A,R1','A,R2','A,R3','A,R4','A,R5','A,R6','A,R7','A,@R0','A,@R1','A,#'),('D8','D9','DA','DB','DC','DD','DE','DF','D0','D1','D3'),('1','1','1','1','1','1','1','1','1','1','2')),
    'MOV'  : (crlib.Pairs, movparams, movopcodes, movtimes),
    'ANLD' : (crlib.Pairs, ('P4,A','P5,A','P6,A','P7,A'),('9C','9D','9E','9F'),('2','2','2','2')),
    'IN'   : (crlib.Pairs, ('A,DBB','A,P1','A,P2'),('22','09','0A'),('1','2','2')),
    'MOVP' : (crlib.Pairs, ('A,@A',),('A3',),('2',)),
    'MOVP3': (crlib.Pairs, ('A,@A',),('E3',),('2',)),
    'ORLD' : (crlib.Pairs, ('P4,A','P5,A','P6,A','P7,A'),('8C','8D','8E','8F'),('1','1','1','1')),
    'OUTL' : (crlib.Pairs, ('DBB,A','P1,A','P2,A'),('02','39','3A'),('2','2','2')),
    'MOVD' : (crlib.Pairs, ('A,P4','A,P5','A,P6','A,P7','P4,A','P5,A','P6,A','P7,A'),('0C','0D','0E','0F','3C','3D','3E','3F'),('2','2','2','2','2','2','2','2')),
    
    'NOP'  : (crlib.Implied, int('00',16),'1'),
    'RET'  : (crlib.Implied, int('83',16),'2'),
    'RETR' : (crlib.Implied, int('93',16),'2'),
    
    'CALL' : (crlib.Absolute, int('14',16),'2'),
    'JMP'  : (crlib.Absolute, int('04',16),'2'),
    
    'DJNZ' : (crlib.Djnz, (int('E8',16),int('00',16)),'2')
    }

    dec.Asm.Timing_Length = 1
    
    errors.Error_List[dec.Cross.Name + 'tcrossed'] = 'Table crossed page boundary'
 
    dec.Asm.Memory = 0
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = (1 << 11)-1
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = False
    
    dec.Asm.Table8048 = -1

    return

#------------------------------------------------------------------------------

def CrossDirective():

    return cr8048.CrossDirective()

#------------------------------------------------------------------------------

def CrossCleanUp():

    cr8048.CrossCleanUp()
    """
    No need to do any cleaning.
    """

    return    

#------------------------------------------------------------------------------

def CrossMnemonic():

    cr8048.CrossMnemonic()

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print

