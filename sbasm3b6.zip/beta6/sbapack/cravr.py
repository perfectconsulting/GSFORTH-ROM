#------------------------------------------------------------------------------
#
#   cravr.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   Cross Overlay for the AVR family of processors
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target
import cravr    # Make my function names visible to dir()

crossversion = '3.00.00'
minversion = '3.00.00'
avrdirlist = {}

dec.Asm.AVR_Family = 0
dec.Asm.AVR_RAM_End = 0
dec.Asm.AVR_Flash_End = 0

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags, avrdirlist
    
    assem.CheckVersions(crossversion, minversion)
    
    dec.Asm.Instructions = {
    'ADC'   : (RegReg,4+2+1,int('1C00',16),'1'),
    'ADD'   : (RegReg,4+2+1,int('0C00',16),'1'),
    'AND'   : (RegReg,4+2+1,int('2000',16),'1'),
    'CP'    : (RegReg,4+2+1,int('1400',16),'1'),
    'CPC'   : (RegReg,4+2+1,int('0400',16),'1'),
    'CPSE'  : (RegReg,4+2+1,int('1000',16),'1/2/3'),
    'EOR'   : (RegReg,4+2+1,int('2400',16),'1'),
    'FMUL'  : (RegReg,4+0+0,int('0308',16),'2'),
    'FMULS' : (RegReg,4+0+0,int('0380',16),'2'),
    'FMULSU': (RegReg,4+0+0,int('0388',16),'2'),
    'MOV'   : (RegReg,4+2+1,int('2C00',16),'1'),
    'MOVW'  : (RegReg,4+0+0,int('0100',16),'1'),
    'MUL'   : (RegReg,4+0+0,int('9C00',16),'2'),
    'MULS'  : (RegReg,4+0+0,int('0200',16),'2'),
    'MULSU' : (RegReg,4+0+0,int('0300',16),'2'),
    'OR'    : (RegReg,4+2+1,int('2800',16),'1'),
    'SBC'   : (RegReg,4+2+1,int('0800',16),'1'),
    'SUB'   : (RegReg,4+2+1,int('1800',16),'1'),
    
    'ADIW'  : (RegImm,4+0+0,int('9600',16),'2'),
    'ANDI'  : (RegImm,4+2+1,int('7000',16),'1'),
    'CBR'   : (RegImm,4+2+1,int('7000',16),'1'),
    'CPI'   : (RegImm,4+2+1,int('3000',16),'1'),
    'LDI'   : (RegImm,4+2+1,int('E000',16),'1'),
    'ORI'   : (RegImm,4+2+1,int('6000',16),'1'),
    'SBCI'  : (RegImm,4+2+1,int('4000',16),'1'),
    'SBIW'  : (RegImm,4+0+0,int('9700',16),'2'),
    'SBR'   : (RegImm,4+2+1,int('6000',16),'1'),
    'SUBI'  : (RegImm,4+2+1,int('5000',16),'1'),
    
    'ASR'   : (RegOnly,4+2+1,int('9405',16),'1'),
    'CLR'   : (RegOnly,4+2+1,int('2400',16),'1'),
    'COM'   : (RegOnly,4+2+1,int('9400',16),'1'),
    'DEC'   : (RegOnly,4+2+1,int('940A',16),'1'),
    'INC'   : (RegOnly,4+2+1,int('9403',16),'1'),
    'LSL'   : (RegOnly,4+2+1,int('0C00',16),'1'),
    'LSR'   : (RegOnly,4+2+1,int('9406',16),'1'),
    'NEG'   : (RegOnly,4+2+1,int('9401',16),'1'),
    'POP'   : (RegOnly,4+0+0,int('900F',16),'2'),
    'PUSH'  : (RegOnly,4+0+0,int('920F',16),'2'),
    'ROL'   : (RegOnly,4+2+1,int('1C00',16),'1'),
    'ROR'   : (RegOnly,4+2+1,int('9407',16),'1'),
    'SER'   : (RegOnly,4+2+1,int('EF0F',16),'1'),
    'SWAP'  : (RegOnly,4+2+1,int('9402',16),'1'),
    'TST'   : (RegOnly,4+2+1,int('2000',16),'1'),
    
    'BRBC'  : (RelJmp,4+2+1,int('F400',16),'1/2'),
    'BRBS'  : (RelJmp,4+2+1,int('F000',16),'1/2'),
    'BRCC'  : (RelJmp,4+2+1,int('F400',16),'1/2'),
    'BRCS'  : (RelJmp,4+2+1,int('F000',16),'1/2'),
    'BREQ'  : (RelJmp,4+2+1,int('F001',16),'1/2'),
    'BRGE'  : (RelJmp,4+2+1,int('F404',16),'1/2'),
    'BRHC'  : (RelJmp,4+2+1,int('F405',16),'1/2'),
    'BRHS'  : (RelJmp,4+2+1,int('F005',16),'1/2'),
    'BRID'  : (RelJmp,4+2+1,int('F407',16),'1/2'),
    'BRIE'  : (RelJmp,4+2+1,int('F007',16),'1/2'),
    'BRLO'  : (RelJmp,4+2+1,int('F000',16),'1/2'),
    'BRLT'  : (RelJmp,4+2+1,int('F004',16),'1/2'),
    'BRMI'  : (RelJmp,4+2+1,int('F002',16),'1/2'),
    'BRNE'  : (RelJmp,4+2+1,int('F401',16),'1/2'),
    'BRPL'  : (RelJmp,4+2+1,int('F402',16),'1/2'),
    'BRSH'  : (RelJmp,4+2+1,int('F400',16),'1/2'),
    'BRTC'  : (RelJmp,4+2+1,int('F406',16),'1/2'),
    'BRTS'  : (RelJmp,4+2+1,int('F006',16),'1/2'),
    'BRVC'  : (RelJmp,4+2+1,int('F403',16),'1/2'),
    'BRVS'  : (RelJmp,4+2+1,int('F003',16),'1/2'),
    'RCALL' : (RelJmp,4+2+1,int('D000',16),'3/4'),
    'RJMP'  : (RelJmp,4+2+1,int('C000',16),'2'),
    
    'CALL'  : (CallJmp,4+0+0,int('940E',16),'4/5'),
    'JMP'   : (CallJmp,4+0+0,int('940C',16),'3'),
    
    'BLD'   : (BitInst,4+2+1,int('F800',16),'1'),
    'BST'   : (BitInst,4+2+1,int('FA00',16),'1'),
    'SBRC'  : (BitInst,4+2+1,int('FC00',16),'1/2/3'),
    'SBRS'  : (BitInst,4+2+1,int('FE00',16),'1/2/3'),
    
    'CBI'   : (IOBits,4+2+1,int('9800',16),'2*'),
    'SBI'   : (IOBits,4+2+1,int('9A00',16),'2*'),
    'SBIC'  : (IOBits,4+2+1,int('9900',16),'2/3/4*'),
    'SBIS'  : (IOBits,4+2+1,int('9B00',16),'2/3/4*'),
    
    'LD'    : (LDIndexed,4+2+1,0,'2'),
    'LDD'   : (LDIndexed,4+2+1,0,'2'),
     
    'ST'    : (STIndexed,4+2+1,0,'2'),
    'STD'   : (STIndexed,4+2+1,0,'2'),
    
    'LDS'   : (LdsSts,4+0+0,int('9000',16),'2'),
    'STS'   : (LdsSts,4+0+0,int('9200',16),'2'),
    
    'ELPM'  : (ELpm,4+0+0,int('95D8',16),'3'),
    'LPM'   : (ELpm,4+2+1,int('95C8',16),'3'),
     
    'SPM'   : (Spm,4+0+1,int('95E8',16),'*'),

    'IN'    : (InOut,4+2+1,int('B000',16),'1'),
    'OUT'   : (InOut,4+2+1,int('B800',16),'1'),
    
    'BCLR'  : (Sreg,4+2+1,int('9488',16),'1'),
    'BSET'  : (Sreg,4+2+1,int('9408',16),'1'),
    
    'BREAK' : (Inherent,4+0+0,int('9598',16),'1'),
    'CLC'   : (Inherent,4+2+1,int('9488',16),'1'),
    'CLH'   : (Inherent,4+2+1,int('94D8',16),'1'),
    'CLI'   : (Inherent,4+2+1,int('94F8',16),'1'),
    'CLN'   : (Inherent,4+2+1,int('94A8',16),'1'),
    'CLS'   : (Inherent,4+2+1,int('94C8',16),'1'),
    'CLT'   : (Inherent,4+2+1,int('94E8',16),'1'),
    'CLV'   : (Inherent,4+2+1,int('94B8',16),'1'),
    'CLZ'   : (Inherent,4+2+1,int('9498',16),'1'),
    'EICALL': (Inherent,4+0+0,int('9519',16),'4'),
    'EIJMP' : (Inherent,4+0+0,int('9419',16),'2'),
    'ICALL' : (Inherent,4+0+0,int('9509',16),'3/4*'),
    'IJMP'  : (Inherent,4+0+0,int('9409',16),'2'),
    'NOP'   : (Inherent,4+2+1,int('0000',16),'1'),
    'RET'   : (Inherent,4+2+1,int('9508',16),'4/5*'),
    'RETI'  : (Inherent,4+2+1,int('9518',16),'4/5*'),
    'SEC'   : (Inherent,4+2+1,int('9408',16),'1'),
    'SEH'   : (Inherent,4+2+1,int('9458',16),'1'),
    'SEI'   : (Inherent,4+2+1,int('9478',16),'1'),
    'SEN'   : (Inherent,4+2+1,int('9428',16),'1'),
    'SES'   : (Inherent,4+2+1,int('9448',16),'1'),
    'SET'   : (Inherent,4+2+1,int('9468',16),'1'),
    'SEV'   : (Inherent,4+2+1,int('9438',16),'1'),
    'SEZ'   : (Inherent,4+2+1,int('9418',16),'1'),
    'SLEEP' : (Inherent,4+2+1,int('9588',16),'1'),
    'WDR'   : (Inherent,4+2+1,int('95A8',16),'1')
    }

    length = 0
    for i in dec.Asm.Instructions:
        if len(dec.Asm.Instructions[i][3]) > length:
            length = len(dec.Asm.Instructions[i][3])
    dec.Asm.Timing_Length = length

    dec.Asm.Memory = 0
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = (1 << 22) - 1
    dec.Asm.PP_TA_Factor = 2
    dec.Flags.BigEndian = False
    
    dec.Asm.AVR_Family = 0
    
    errors.Error_List[dec.Cross.Name + 'nofamily'] = 'AVR Family not set. Assuming XMega family.'
    
    # Fill dictionary with all available directive handlers
    for i in dir(cravr):
        if len(i) == 5 and i[:3] == 'Dir':
           avrdirlist[i[-2:]] = eval(i)

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    global Asm

    directive = dec.Asm.Mnemonic[1:3].upper()
    
    wedidit = False
    if directive in avrdirlist:
        dirfunc = avrdirlist[directive]
        dirfunc()
        wedidit = True # Indicate that directive is already handled.
    
    return wedidit     # return "" if directive handled by cross!

#------------------------------------------------------------------------------

def CrossCleanUp():

    """
    Ensure that the Code Memory ends on a word boundary.
    """

    global Asm
    
    dec.Asm.Memory = 0
    target.BoundarySync()
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm
    
    target.BoundarySync()

    if dec.Asm.AVR_Family == 0:
        errors.DoWarning(dec.Cross.Name + 'nofamily', False)
        dec.Asm.AVR_Family = 4

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        family = dec.Asm.AVR_Family
        if family >= 3:
            # Xmega is almost the same as Mega, only minor differences exist
            family = 4
        # Now family is either 1, 2 or 4 which makes it easier to see whether
        # this particular instruction is supported or not
        
        if not (family & dec.Asm.Instructions[dec.Asm.Mnemonic][1]):
            # Opcode not supported by this family
            errors.DoError('badopco', False)
        else:
            func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][3]
            func()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def MissingOperand():

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)
        
#-----------------------------------------------------------------------------

def GetReg():
    
    global Asm
    
    pointer = dec.Asm.Parse_Pointer
    reg = assem.GetWord().upper()
    
    if reg == '':
        errors.DoError('missoper', False)
        return 0
        
    if (len(reg) == 2 or len(reg) == 3) and reg[0] == 'R':
        reg = reg[1:]
        if reg.isdigit:
            if len(reg) == 1 or reg[0] != '0':
                register = int(reg)
                if register < 32:
                    return register
    
    dec.Asm.Parse_Pointer = pointer
    value = assem.EvalExpr()
    register = value[0]

    if dec.Asm.Pass == 2 or (not value[1]):
        # Test range only if in pass 2, or pass 1 if not forward referenced
        if register < 0 or register > 31:
            # It's a range error, simply ignore everything which doesn't fit
            errors.DoError('range', False)
            register = 0
    return register & 31

#-----------------------------------------------------------------------------

def RegReg():

    global Asm

    if MissingOperand():
        return
        
    reg1 = GetReg()
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        target.CodeWord(0)     # Write dummy word
        return
    
    reg2 = GetReg()
    
    if ('MUL' in dec.Asm.Mnemonic) and (dec.Asm.Mnemonic != 'MUL'):
        if dec.Asm.Pass == 1:
            # Don't test range during pass 1, to ignore forward references
            # Set dummy registers instead
            reg1 = 0
            reg2 = 0
        else:
            reg1 = reg1 - 16
            reg2 = reg2 - 16
            if reg1 < 0 or reg2 < 0:
                errors.DoError('range', False)
                reg1 = 0
                reg2 = 0
            if dec.Asm.Mnemonic != 'MULS':
                if reg1 > 7 or reg2 > 7:
                    errors.DoError('range', False)
                    reg1 = 0
                    reg2 = 0
            reg1 = reg1 << 4
    elif dec.Asm.Mnemonic == 'MOVW':
        # Either register of the register pair can be used
        reg1 = (reg1 & 30) << (4-1)
        reg2 = (reg2 & 30) >> 1
    else:
        reg1 = reg1 << 4
        if reg2 > 15:
            reg2 = reg2 - 16 + 512
    
    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + reg1 + reg2)
    
    NoMore()

#-----------------------------------------------------------------------------

def RegImm():

    global Asm

    if MissingOperand():
        return

    reg = GetReg()
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        target.CodeWord(0)     # Write dummy word
        return
    
    prefix = '#'
    if assem.NowChar() in '#/=\\':
        prefix = assem.NowChar(True)
    
    value = assem.EvalExpr()
    
    if prefix == '#':
        val = value[0] & 255
    elif prefix == '/':
        val = (value[0] >> 8) & 255
    elif prefix == '/':
        val = (value[0] >> 16) & 255
    else:
        val = (value[0] >> 24) & 255

    if dec.Asm.Mnemonic in ('ADIW', 'SBIW'):
        if dec.Asm.Pass == 2:
            # Don't check range during pass 1, may be forward referenced
            if (not reg in (24, 26, 28, 30)) or (val > 63):
                errors.DoError('range', False)
        reg = (reg << 3) & 48
        val = (val & 15) + ((val & 48) << 2)
    else:
        if dec.Asm.Pass == 2:
            # Don't check range during pass 1, may be forward referenced
            if reg < 16:
                errors.DoError('range', False)
        reg = (reg << 4) & 240
        val = (val & 15) + ((val & 240) << 4)
        
    if dec.Asm.Mnemonic == 'CBR':
        val = val ^ 3855    # Invert bits of constant (11110000111)
    
    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + reg + val)
    
    NoMore()

#-----------------------------------------------------------------------------

def RegOnly():

    global Asm

    if MissingOperand():
        return

    reg = GetReg()
    
    if dec.Asm.Mnemonic in ('CLR', 'LSL', 'ROL', 'TST'):
        reg1 = reg << 4
        if reg > 15:
            reg = reg - 16 + 512
        reg = reg + reg1
    elif dec.Asm.Mnemonic == 'SER':
        if dec.Asm.Pass == 2 and reg < 16:
            errors.DoError('range', False)
        reg = (reg & 15) << 4
    else:
        reg = reg << 4
    
    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + reg)
    
    NoMore()

#-----------------------------------------------------------------------------

def RelJmp():

    global Asm

    if MissingOperand():
        return

    if dec.Asm.Mnemonic in ('BRBC', 'BRBS'):
        # Get bit number first
        value = assem.EvalExpr()
        bit = value[0]
        if dec.Asm.Pass == 2 and (bit < 0 or bit > 7):
            errors.DoError('range', False)
        bit = bit & 7
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
    else:
        bit = 0
        
    value = assem.EvalExpr()
    offset = value[0] - dec.Asm.BOL_Address - 1
    
    if dec.Asm.Mnemonic in ('RCALL', 'RJMP'):
        if dec.Asm.Pass == 2 and (offset < -2048 or offset > 2047):
            errors.DoError('range', False)
        offset = offset & 4095
    else:
        if dec.Asm.Pass == 2 and (offset < -64 or offset > 63):
            errors.DoError('range', False)
        offset = (offset & 127) << 3

    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + offset + bit)
    
    NoMore()

#-----------------------------------------------------------------------------

def CallJmp():

    global Asm

    if MissingOperand():
        return
        
    maxadd = dec.Asm.Max_Address
    value = assem.EvalExpr()
    
    if dec.Asm.Pass == 2 or (not value[1]):
        if value[0] < 0 or value[0] > maxadd:
            errors.DoError('range', False)
    
    destinationl = value[0] & dec.MAX16
    destinationh = (value[0] >> 16) & 63
    destinationh = ((destinationh & 62) << 3) + (destinationh & 1)      

    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + destinationh)
    target.CodeWord(destinationl)
    
    NoMore()

#-----------------------------------------------------------------------------

def BitInst():

    global Asm

    if MissingOperand():
        return
        
    reg = GetReg() << 4
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        target.CodeWord(0)     # Write dummy word
        return
    
    value = assem.EvalExpr()
    bitno = value[0]
    
    if dec.Asm.Pass == 2 and (bitno < 0 or bitno > 7):
        errors.DoError('range', False)
        bitno = 0
        
    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + reg + bitno)
    
    NoMore()

#-----------------------------------------------------------------------------

def IOBits():

    global Asm

    if MissingOperand():
        return
        
    value = assem.EvalExpr()
    ioreg = value[0]

    if dec.Asm.Pass == 2 and (ioreg < 0 or ioreg > 31):
        errors.DoError('range', False)
        ioreg = 0
    
    ioreg = ioreg << 3
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        target.CodeWord(0)     # Write dummy word
        return
    
    value = assem.EvalExpr()
    bitno = value[0]
    
    if dec.Asm.Pass == 2 and (bitno < 0 or bitno > 7):
        errors.DoError('range', False)
        bitno = 0
        
    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + ioreg + bitno)
    
    NoMore()

#-----------------------------------------------------------------------------

def LDIndexed():

    global Asm

    if MissingOperand():
        return
    
    reg = GetReg() << 4
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        target.CodeWord(0)     # Write dummy word
        return
 
    value = GetIndex()
    
    if value[1] == 'X':
        opcode = int('900C',16)
    elif value[1] == 'Y':
        opcode = int('8008',16) + value[2]
        if value[0] != 0 and len(dec.Asm.Mnemonic) == 2:
            opcode = opcode + int('1000',16)
    else:
        opcode = int('8000',16) + value[2]
        if value[0] != 0 and len(dec.Asm.Mnemonic) == 2:
            opcode = opcode + int('1000',16)
    
    if len(dec.Asm.Mnemonic) == 2:
        opcode = opcode + value[0]
    
    target.CodeWord(opcode + reg)
    
    NoMore()

#-----------------------------------------------------------------------------

def STIndexed():

    global Asm

    if MissingOperand():
        return
    
    value = GetIndex()
    
    if value[1] == 'X':
        opcode = int('920C',16)
    elif value[1] == 'Y':
        opcode = int('8208',16) + value[2]
        if value[0] != 0 and len(dec.Asm.Mnemonic) == 2:
            opcode = opcode + int('1000',16)
    else:
        opcode = int('8200',16) + value[2]
        if value[0] != 0 and len(dec.Asm.Mnemonic) == 2:
            opcode = opcode + int('1000',16)
    
    if len(dec.Asm.Mnemonic) == 2:
        opcode = opcode + value[0]
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        target.CodeWord(0)     # Write dummy word
        return
 
    reg = GetReg() << 4
    
    target.CodeWord(opcode + reg)
    
    NoMore()

#-----------------------------------------------------------------------------

def LdsSts():

    global Asm

    if MissingOperand():
        return

    if dec.Asm.Mnemonic == 'LDS':
        reg = GetReg() << 4
        
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            target.CodeWord(0)     # Write dummy words
            target.CodeWord(0)  
            return
            
        value = assem.EvalExpr()
        
    else:
        value = assem.EvalExpr()
        
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            target.CodeWord(0)    # Write dummy words
            target.CodeWord(0)
            return
            
        reg = GetReg() << 4
 
    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + reg)
    target.CodeWord(value[0])
    
    NoMore()

#-----------------------------------------------------------------------------

def ELpm():

    """
    Not all variants may be available on all devices. AT90S1200 doesn't have
    an LPM instruction at all.
    """

    global Asm

    if dec.Asm.Parse_Pointer == 0 or not dec.Asm.Optional:
        # No operand, use implied addressing mode
        if dec.Asm.Mnemonic == 'ELPM' and dec.Asm.AVR_Family == 3:
            # Doesn't exist on Mega devices
            errors.DoError('badopco', False)
        target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2])
    else:
        if dec.Asm.Mnemonic == 'ELPM':
            opcode = int('9006',16)
        else:
            opcode = int('9004',16)
        
        reg = GetReg() << 4
        
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            target.CodeWord(0)     # Write dummy word
            return
     
        value = GetIndex()
        
        if value[1] != 'Z' or value[0] == 2 or value[2] != 0:
            errors.DoError('badoper', False)
            reg = 0     # Dummy register
            index = 0   # and dummy mode
        else:
            if dec.Asm.Mnemonic == 'ELPM' and dec.Asm.AVR_Family == 3:
                # Only ELPM Rd,Z exists on Atmega devices
                if value[0] != 1:
                    errors.DoError('badoper', False)
            index = value[0]
        
        target.CodeWord(opcode + reg + index)
        
        NoMore()

#-----------------------------------------------------------------------------

def Spm():

    global Asm

    if dec.Asm.AVR_Family != 4 or dec.Asm.Parse_Pointer == 0 or not dec.Asm.Optional:
        # No operand, use implied addressing mode
        target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2])
    else:
        # Only if Xmega family and an operand is detected
        value = GetIndex()

        if value[1] != 'Z' or value[0] == 2 or value[2] != 0:
            errors.DoError('badoper', False)
            index = 0   # Dummy mode
        else:
            index = value[0]
        
        target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + (index << 4))
        
        NoMore()

#-----------------------------------------------------------------------------

def InOut():
        
    global Asm

    if MissingOperand():
        return

    if dec.Asm.Mnemonic == 'IN':
        reg = GetReg() << 4
        
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            target.CodeWord(0)     # Write dummy word
            return
     
        value = assem.EvalExpr()
        
    else:
        value = assem.EvalExpr()
        
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            target.CodeWord(0)     # Write dummy word
            return
     
        reg = GetReg() << 4
   
    ioreg = value[0]    
    if dec.Asm.Pass == 2 and (ioreg < 0 or ioreg > 63):
        errors.DoError('range', False)
        ioreg = 0

    ioreg = (ioreg & 15) + ((ioreg & 48) << 5)
              
    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + reg + ioreg)
       
    NoMore()

#-----------------------------------------------------------------------------

def Sreg():
        
    global Asm

    if MissingOperand():
        return

    value = assem.EvalExpr()
    
    sregbit = value[0]
    
    if dec.Asm.Pass == 2 and (sregbit < 0 or sregbit > 7):
        errors.DoError('range', False)
        sregbit = 0
              
    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2] + (sregbit << 4))
       
    NoMore()

#-----------------------------------------------------------------------------

def Inherent():
        
    global Asm

    target.CodeWord(dec.Asm.Instructions[dec.Asm.Mnemonic][2])

#-----------------------------------------------------------------------------

def GetIndex():

    global Asm

    index = assem.NowChar(True).upper()
    
    if index == ' ':
        errors.DoError('missoper', False)
        return (0, 'Z', 0)  # Return dummy values
    
    incdec = 0
    if index == '-':
        incdec = 2
        index = assem.NowChar(True).upper()
    
    if not index in ('X', 'Y', 'Z'):
        errors.DoError('badoper', False)
        return (0, 'Z', 0)    # Return dummy values
    
    if incdec == 0:
        if assem.NowChar() == '+':
            incdec = 1
            assem.NowChar(True)

    offset = 0
    if dec.Asm.Mnemonic in ('LDD', 'STD') and incdec == 1:
        # An offset q must follow
        if index == 'X':
            errors.DoError('badoper', False)   # X+q doesn't exist
        value = assem.EvalExpr()
        offset = value[0]
        
        if dec.Asm.Pass == 2 and (offset < 0 or offset > 63):
            errors.DoError('range', False)
            offset = 0
        
        offset = (offset & 7) + ((offset & 24) << 7) + ((offset & 32) << 8)
    
    return (incdec, index, offset)

#-----------------------------------------------------------------------------

def DirCS():

    """
    Change to Code segment.
    Equivalent to .SM CODE
    - Boundary Sync
    """

    global Asm
    
    target.BoundarySync()
            
    dec.Asm.Memory = 0
    dec.Asm.BOL_Address = dec.Asm.PH_Address
    dec.Asm.List_Address = dec.Asm.PH_Address

#-----------------------------------------------------------------------------

def DirDE():
    
    """
    Assign a name to a register.
    - Boundary Sync will be automatic because of the label in the label field
    """
    
    global Asm
    
    if dec.Asm.Parse_Pointer == 0:
        # No parameter given
        errors.DoError('missoper', False)
        dec.Asm.New_Label = ''
        return

    register = -1
    reg = assem.GetWord().upper()
    if (len(reg) == 2 or len(reg) == 3) and reg[0] == 'R':
        reg = reg[1:]
        if reg.isdigit:
            if len(reg) == 1 or reg[0] != '0':
                register = int(reg)
    if register < 0 or register > 31:
        errors.DoError('badoper', False)
        dec.Asm.New_Label = ''
    else:
        dec.Asm.BOL_Address = register
        dec.Asm.List_Address = register
    dec.Asm.Mnemonic = '.SE'    # Handle rest like .SE

    # Ignore more parameters this time (like .EQ).
    
#-----------------------------------------------------------------------------

def DirDS():

    """
    Change to RAM segment.
    Equivalent to .SM RAM
    - Boundary Sync
    """

    global Asm
    
    target.BoundarySync()
            
    dec.Asm.Memory = 1
    dec.Asm.BOL_Address = dec.Asm.RM_Address
    dec.Asm.List_Address = dec.Asm.RM_Address

#-----------------------------------------------------------------------------

def DirES():

    """
    Change to EEPROM segment.
    Equivalent to .SM EERPOM
    - Boundary Sync
    """

    global Asm
    
    target.BoundarySync()
            
    dec.Asm.Memory = 2
    dec.Asm.BOL_Address = dec.Asm.EM_Address
    dec.Asm.List_Address = dec.Asm.EM_Address

#-----------------------------------------------------------------------------

def DirEV():

    """
    Force a Boundary Sync.
    """
    
    target.BoundarySync()    
    
#-----------------------------------------------------------------------------

def DirFA():

    """
    Set the device's family.
    If this is not used in a program a warning is given and the assembler
    defaults to the XMega family.
    - Boundary Sync.
    """
    
    global Asm

    target.BoundarySync()    

    families = ['TINY', 'AVR', 'MEGA', 'XMEGA']

    if dec.Asm.Parse_Pointer == 0:
        # No parameter given
        errors.DoError('missoper', False)
        return

    family = assem.GetWord().upper()
    if not family in families:
        errors.DoError('badoper', False)
        return
        
    dec.Asm.AVR_Family = families.index(family) + 1
    
    NoMore()

#-----------------------------------------------------------------------------

def DirMS():

    """
    Set the maximum ROM memory size.
    Jumps beyond that size will result in a range error.
    Code can not be saved to a target address which is > maximum size.
    Forward reference values are not allowed.
    Thus for a 64k word device, .MS must be set to $FFFF (not to $10000)
    Note: Any size can be set between 0 and $3FFFFF, even silly sizes!
    - Boundary Sync
    """
    
    global Asm
    
    target.BoundarySync()    

    if dec.Asm.Parse_Pointer == 0:
        # No parameter given
        errors.DoError('missoper', False)
        return

    value = assem.EvalExpr()
    
    if value[1]:
        errors.DoError('forwref', False)
    else:
        if value[0] < 0 or value[0] > ((1 << 22) - 1):
            errors.DoError('range', False)
            return
        dec.Asm.Max_Address = value[0]
        NoMore()

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print

