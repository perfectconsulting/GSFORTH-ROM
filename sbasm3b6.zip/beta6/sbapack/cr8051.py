#------------------------------------------------------------------------------
#
#   cr8051.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   Cross Overlay for the 8051 family of processors
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.01'
minversion = '3.00.00'

dec.Asm.RB8051 = 0      # Hold the current working register bank

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'
    # New versions of the 8051 may have considerably different timing values.
    # @ prefix may be confused with inderect mode
    # < prefix means forced register mode (only lower 3 bits of any value are used)
    # > prefix means forced direct mode

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags
    
    assem.CheckVersions(crossversion, minversion)
    
    dec.Asm.Instructions = {
    'MOV'  : (MovInst, '0'),
    'MOVC' : (MovCInst,'0'),
    'MOVX' : (MovXInst,'0'),
    
    # A    C    BIT
    'CLR'  : (BitInst, ('E4','C3','C2'),('1','1','1')),
    'CPL'  : (BitInst, ('F4','B3','B2'),('1','1','1')),
    'SETB' : (BitInst, ('00','D3','D2'),('0','1','1')),
    
    'DA'   : (Specials, 'D4', '1'),
    'DIV'  : (Specials, '84', '4'),
    'MUL'  : (Specials, 'A4', '4'),
    'NOP'  : (Specials, '00', '1'),
    'RET'  : (Specials, '22', '2'),
    'RETI' : (Specials, '32', '2'),
    'RL'   : (Specials, '23', '1'),
    'RLC'  : (Specials, '33', '1'),
    'RR'   : (Specials, '03', '1'),
    'RRC'  : (Specials, '13', '1'),
    'SWAP' : (Specials, 'C4', '1'),
    
    # DIR    A    R0..R7    @R0..@R1    DPTR 
    'DEC'  : (Singles, ('15','14','18','16','00'), ('1','1','1','1','0')),
    'INC'  : (Singles, ('05','04','08','06','A3'), ('1','1','1','1','2')),
    'POP'  : (Singles, ('D0','00','00','00','00'), ('2','0','0','0','0')),
    'PUSH' : (Singles, ('C0','00','00','00','00'), ('2','0','0','0','0')),
    
    'ACALL': (Jumps, '11', '2'),
    'AJMP' : (Jumps, '01', '2'),
    'LCALL': (Jumps, '12', '2'),
    'LJMP' : (Jumps, '02', '2'),
    'CALL' : (Jumps, '91', '0'),
    'JMP'  : (Jumps, '81', '0'),

    # A,Rn    A,DIR    A,@Ri   A,#   DIR,A    DIR,#    C,BIT    C,/BIT    
    'ADD'  : (Math, ('28','25','26','24','00','00','00','00'),
                    ('1', '1', '1', '1', '0', '0', '0', '0')),
    'ADDC' : (Math, ('38','35','36','34','00','00','00','00'),
                    ('1', '1', '1', '1', '0', '0', '0', '0')),
    'ANL'  : (Math, ('58','55','56','54','52','53','82','B0'),
                    ('1', '1', '1', '1', '1', '2', '2', '2')),
    'ORL'  : (Math, ('48','45','46','44','42','43','72','A0'),
                    ('1', '1', '1', '1', '1', '2', '2', '2')),
    'SUBB' : (Math, ('98','95','96','94','00','00','00','00'),
                    ('1', '1', '1', '1', '0', '0', '0', '0')),
    'XCH'  : (Math, ('C8','C5','C6','00','00','00','00','00'),
                    ('1', '1', '1', '0', '0', '0', '0', '0')),
    'XRL'  : (Math, ('68','65','66','64','62','63','00','00'),
                    ('1', '1', '1', '1', '1', '2', '0', '0')),

    # A,DIR,REL    A,#,REL    Rn,#,REL    @Ri,#,REL   
    'CJNE' : (BranchTest, 'B5','B4','B8','B6'),
    
    # Rn,REL    DIR,REL
    'DJNZ' : (BranchLoop, 'D8','D5'),
    'JB'   : (BranchBit, '20', '2'),
    'JBC'  : (BranchBit, '10', '2'),
    'JC'   : (Branch, '40', '2'),
    'JNB'  : (BranchBit, '30', '2'),
    'JNC'  : (Branch, '50', '2'),
    'JNZ'  : (Branch, '70', '2'),
    'JZ'   : (Branch, '60', '2'),
    'SJMP' : (Branch, '80', '2'),
    
    'XCHD' : (XchdInst,'D6')
    }

    dec.Asm.Timing_Length = 1

    dec.Asm.Memory = 0
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = dec.MAX16
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = True
    
    dec.Asm.RB8051 = 0

    return

#------------------------------------------------------------------------------

def CrossDirective():

    """
    Three directives are handled by this cross overlay.
    One new directive .RB is used to indicate the working register bank
    The existing directive .EQ (and it's equivalent = ) is altered to allow
    bit address labels.
    """

    global Asm

    if len(dec.Asm.Mnemonic) > 1:
        directive = dec.Asm.Mnemonic[1:3].upper()
    else:
        directive = dec.Asm.Mnemonic
    
    if directive == 'RB':
        DirRB()
        return True
        
    if directive == '=' or directive == 'EQ':
        return DirEQ()
        
    return False

#------------------------------------------------------------------------------

def CrossCleanUp():

    """
    No need to do any cleaning.
    """

    return    
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    """
    Jump to the mnemonic handling routine.
    """

    global Asm
    
    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def MissingOperand():

    """
    An operand is mandatory, so it's an error if one is missing.
    Returns True if the operand is indeed missing.
    """

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------

def NoMore():

    """
    This must be the end of the line. Raise an error if it's not. Or a warning
    if more parameters follow.
    """

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)

#-----------------------------------------------------------------------------

def GetReg():

    """
    Return a tupple with a value and register mode.
    The value may not always have a true meaning, in which case it's value
    must be 0.
    Mode = 0:   Not used, reserved for direct mode, which is not tested here.
    Mode = 1:   A mode (value[0] has no meaning)
    Mode = 2:   R0..R7 mode (value[0] is register number 0..7)
    Mode = 3:   @R0..@R1 mode (value[0] is register number 0..1)
    Mode = 4:   DPTR mode (value[0] has no meaning)
    Mode = 5:   @A+PC mode (value[0] has no meaning)
    Mode = 6:   @A+DPTR mode (value[0] has no meaning)
    Mode = 7:   @DPTR mode (value[0] has no meaning)
    Mode = 8:   # immediate mode (value[0] is the immediate value)
    """

    global Asm
    
    if assem.NowChar() in '#/=\\':
        # It's immediate mode
        mode = 8
        prefix = assem.NowChar(True)
        value = assem.EvalExpr()
        if prefix == '#':
            register = value[0]
        elif prefix == '/':
            register = value[0] >> 8
        elif prefix == '=':
            register = value[0] >> 16
        else:
            register = value[0] >> 24
        return (register, mode)

    begpntr = dec.Asm.Parse_Pointer
    regname = assem.GetWord().upper()

    if regname == 'A':
        register = 0    # Doesn't really matter
        mode = 1        # Indicate accu mode
    elif regname in ('R0','R1','R2','R3','R4','R5','R6','R7'):
        register = int(regname[1])
        mode = 2        # Indicate register mode
    elif regname in ('@R0','@R1'):
        register = int(regname[2])
        mode = 3        # Indicate @register mode
    elif regname == 'DPTR':
        register = 0    # Doesn't really matter
        mode = 4        # Indicate DPTR mode
    elif regname == '@A+PC':
        register = 0    # Doesn't really matter
        mode = 5        # Indicate @A+PC mode
    elif regname == '@A+DPTR':
        register = 0    # Doesn't really matter
        mode = 6        # Indicate @A+DPTR mode
    elif regname == '@DPTR':
        register = 0    # Doesn't really matter
        mode = 7        # Indicate @DPTR mode
    else:    
        dec.Asm.Parse_Pointer = begpntr     # Restore parse pointer
        register = 0    # Doesn't really matter
        mode = 0        # Indicate DIR mode, but this is not confirmed yet!
        
    return (register, mode)

#-----------------------------------------------------------------------------

def GetRegDir():

    """
    Return a tupple with a value and register mode.
    The value may not always have a true meaningm, in which case it's value
    must be 0.
    Mode = 0:   Direct addressing mode (value[0] is direct address)
    Mode = 1:   A mode (value[0] has no meaning)
    Mode = 2:   R0..R7 mode (value[0] is register number 0..7)
    Mode = 3:   @R0..@R1 mode (value[0] is register number 0..1)
    Mode = 4:   DPTR mode (value[0] has no meaning)
    Mode = 5:   @A+PC mode (value[0] has no meaning)
    Mode = 6:   @A+DPTR mode (value[0] has no meaning)
    Mode = 7:   @DPTR mode (value[0] has no meaning)
    Mode = 8:   # immediate mode (value[0] is the immediate value)
    """

    global Asm
    
    value = GetReg()
    register = value[0]
    mode = value[1]
    
    if mode != 0:
        # A valid register was found, don't bother looking any further
        return (register, mode)
        
    prefix = assem.NowChar()
    
    if prefix in '@<>':
        assem.IncParsePointer()
        
    value = assem.EvalExpr()
    
    if prefix == '<':
        if dec.Asm.Pass == 2 and (value[0] >> 5) != 0:
            errors.DoError('range', False)
            
        register = value[0] & 7
        mode = 2            # Indicate register mode
        return (register, mode)
        
    if prefix == '>':
        if dec.Asm.Pass == 2 and (value[0] >> 8 != 0):
            errors.DoError('range', False)
        return (value[0], 0)    # Indicate direct mode
        
    if prefix == '@':
        # Only @R0 or @R1 allowed now, regardless of forward referencing
        register = value[0] & 31
        if dec.Asm.Pass == 2:
            if (value[0] >> 5) !=0:
                # Value is a lot bigger than any register could be
                errors.DoError('range', False)
            if (register >> 3) != dec.Asm.RB8051:
                # Address is not a member of the current register bank
                errors.DoError('range', False)
            if (register & 6) != 0:
                # Only register 0 and 1 allowed being used as index
                errors.DoError('range', False)
        
        register = value[0] & 1
        mode = 3            # Indicate @ mode
        
    if dec.Asm.Pass == 2 and (value[0] >> 8 != 0):
        errors.DoError('range', False)
        
    if not value[1]:
        # No forward referenced label was used, so value is know in both passes
        if value[0] >> 5 != 0:
            # Value is too big to be a register
            register = value[0]
            mode = 0        # Indicate direct mode
        else:
            # Compare bank of direct address with current bank
            if dec.Asm.RB8051 == (value[0] >> 3):
                # Same bank! Make it a real register
                register = value[0] & 7
                mode = 2    # Indicate register mode
            else:
                # Not the same bank, use direct mode now
                register = value[0]
                mode = 0    # Indicate direct mode
    else:
        # Forward referenced label was used, be on the safe side and use direct mode
        register = value[0]
        mode = 0            # Indicate direct mode
    
    return (register, mode)

#-----------------------------------------------------------------------------

def MovInst():

    """
    Handle MOV, MOVC and MOVX instructions.
    Expected operand modes:
    MOV    DIR,DIR    DIR,#    DIR,Rn    DIR,@Ri    DIR,A
    MOV    A,DIR      A,#      A,Rn      A,@Ri
    MOV    Rn,DIR     Rn,A     Rn,#      Rn,Rn
    MOV    @Ri,DIR    @Ri,#    @Ri,A
    MOV    DPTR,#
    MOV    BIT,C      C,BIT
    
    Note: MOV Rn,Rn doesn't exist. It is translated by the assembler to
    MOV Rn,DIR, where register Rn is translated to a direct address according
    to the current working register bank.
    """

    global Asm

    if MissingOperand():
        return

    if MovBit():
        return
    
    par1 = GetRegDir()
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    par2 = GetRegDir()
    
    if par1[1] == 0:
        # DIR,something
        if par2[1] == 8:
            # It's DIR,#
            target.CodeByte(int('75',16))
            target.CodeByte(par1[0])
            target.CodeByte(par2[0])
            dec.Asm.Timing = '2'
        elif par2[1] == 0:
            # It's DIR,DIR
            target.CodeByte(int('85',16))
            target.CodeByte(par2[0])
            target.CodeByte(par1[0])
            dec.Asm.Timing = '2'
        elif par2[1] == 1:
            # It's DIR,A
            target.CodeByte(int('F5',16))
            target.CodeByte(par1[0])
            dec.Asm.Timing = '1'
        elif par2[1] == 2:
            # It's DIR,Rn
            target.CodeByte(int('88',16)+par2[0])
            target.CodeByte(par1[0])
            dec.Asm.Timing = '2'
        elif par2[1] == 3:
            # It's DIR,@Ri
            target.CodeByte(int('86',16)+par2[0])
            target.CodeByte(par1[0])
            dec.Asm.Timing = '2'
        else:
            errors.DoError('badoper', False)

    elif par1[1] == 1:
        # A,something
        if par2[1] == 8:
            # It's A,#
            target.CodeByte(int('74',16))
            target.CodeByte(par2[0])
            dec.Asm.Timing = '1'
        elif par2[1] == 0:
            # It's A,DIR
            target.CodeByte(int('E5',16))
            target.CodeByte(par2[0])
            dec.Asm.Timing = '1'
        elif par2[1] == 2:
            # It's A,Rn
            target.CodeByte(int('E8',16)+par2[0])
            dec.Asm.Timing = '1'
        elif par2[1] == 3:
            # It's A,@Ri
            target.CodeByte(int('E6',16)+par2[0])
            dec.Asm.Timing = '1'
        else:
            errors.DoError('badoper', False)
                
    elif par1[1] == 2:
        # Rn,something
        if par2[1] == 8:
            # It's Rn,#
            target.CodeByte(int('78',16)+par1[0])
            target.CodeByte(par2[0])
            dec.Asm.Timing = '1'
        elif par2[1] == 0:
            # It's Rn,DIR
            target.CodeByte(int('A8',16)+par1[0])
            target.CodeByte(par2[0])
            dec.Asm.Timing = '2'
        elif par2[1] == 1:
            # It's Rn,A
            target.CodeByte(int('F8',16)+par1[0])
            dec.Asm.Timing = '1'
        elif par2[1] == 2:
            # It's Rn,Rn (doesn't exist, fake it)
            target.CodeByte(int('A8',16)+par1[0])
            target.CodeByte(par2[0]+(dec.Asm.RB8051 << 3))
            dec.Asm.Timing = '2'
        else:
            errors.DoError('badoper', False)
        
    elif par1[1] == 3:
        # @Ri,something
        if par2[1] == 8:
            # It's @Ri,#
            target.CodeByte(int('76',16)+par1[0])
            target.CodeByte(par2[0])
            dec.Asm.Timing = '1'
        elif par2[1] == 0:
            # It's @Ri,DIR
            target.CodeByte(int('A6',16)+par1[0])
            target.CodeByte(par2[0])
            dec.Asm.Timing = '2'
        elif par2[1] == 1:
            # It's @Ri,A
            target.CodeByte(int('F6',16)+par1[0])
            dec.Asm.Timing = '1'
        else:
            errors.DoError('badoper', False)
    
    elif par1[1] == 4:
        # DPTR,something
        if par2[1] == 8:
            # It's DPTR,#
            target.CodeByte(int('90',16))
            target.CodeWord(par2[0])
            dec.Asm.Timing = '2'
        else:
            errors.DoError('badoper', False)
        
    else:
        # It was none of the above
        errors.DoError('badoper', False)
    
    NoMore()
        
#-----------------------------------------------------------------------------

def MovBit():
    
    """
    See if first or second operand is a C.
    If it is it is a bit MOV.
    If it is not return False and parse normal MOV.
    """
    
    global Asm
    
    pntr = dec.Asm.Parse_Pointer
    par1 = assem.GetWord().upper()
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    if par1 == 'C':
        # First parameter is a C
        
        bitreg = GetBit()
 
        target.CodeByte(int('A2',16))
        target.CodeByte(bitreg)
        dec.Asm.Timing = '1'
        
        NoMore()
        
        return True
    
    par2 = assem.GetWord().upper()
    if par2 == 'C':
        # Second parameter is a C

        endpntr = dec.Asm.Parse_Pointer
        dec.Asm.Parse_Pointer = pntr
        bitreg = GetBit()
        dec.Asm.Parse_Pointer = endpntr

        target.CodeByte(int('92',16))
        target.CodeByte(bitreg)
        dec.Asm.Timing = '2'
                
        NoMore()
        
        return True
    
    dec.Asm.Parse_Pointer = pntr
    
    return False
        
#-----------------------------------------------------------------------------

def GetBit():
    
    """
    Legal bit addresses are:
    Direct addresses from 020H.0 to 02FH.7
    SFR addresses which can be devided by 8, followed by .0 to .7
    If the address is not followed by .0 to .7 it is handled as a normal address.
    In which case it's value should be below 256.
    """
    
    global Asm
    
    pntr = dec.Asm.Parse_Pointer
    par1 = assem.GetWord().upper()
    regbit = 0

    if len(par1) > 2 and par1[-2] == '.' and par1[-1] in '01234567':
        # operand.bit notation. Hide bit number temporarily
        bitno = int(par1[-1])
        parseline = dec.Asm.Parse_Line
        dec.Asm.Parse_Line = parseline[:dec.Asm.Parse_Pointer-2] + ' '
        dec.Asm.Parse_Pointer = pntr
        value = assem.EvalExpr()
        dec.Asm.Parse_Line = parseline
        dec.Asm.Parse_Pointer = dec.Asm.Parse_Pointer + 2

        if dec.Asm.Pass == 2:
            # Only check rage during pass 2
            if value[0] in range(int('20',16),int('30',16)):
                regbit = ((value[0] & 15) << 3) + bitno
            elif value[0] in range(int('80',16),int('FF',16),8):
                regbit = value[0] + bitno
            else:
                errors.DoError('range', False)

    else:
        # No operand.bit notation, evaluate normally
        dec.Asm.Parse_Pointer = pntr
        value = assem.EvalExpr()
        regbit = value[0]

        if dec.Asm.Pass == 2 and (value[0] >> 8) != 0:
            errors.DoError('range', False)
    
    return regbit
        
#-----------------------------------------------------------------------------

def MovCInst():

    """
    MOVC   A,@A+PC    A,@+DPTR
    """

    global Asm
    
    if MissingOperand():
        return

    par1 = GetReg()

    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    par2 = GetReg()
    
    if par1[1] != 1 or (par2[1] != 5 and par2[1] != 6):
        errors.DoError('badoper', False)
        return
    
    if par2[1] == 5:
        target.CodeByte(int('83',16))
        dec.Asm.Timing = '2'
    else:
        target.CodeByte(int('93',16))
        dec.Asm.Timing = '2'
    
    NoMore()

#-----------------------------------------------------------------------------

def MovXInst():

    """
    MOVX   A,@DPTR    A,@Ri    @DPTR,A   @Ri,A
    """

    global Asm

    if MissingOperand():
        return

    par1 = GetReg()

    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    par2 = GetReg()

    dec.Asm.Timing = '2'
    if par1[1] == 1:
        # Can be either A,@DPTR or A,@Ri
        if par2[1] == 7:
            # It's A,@DPTR for sure
            target.CodeByte(int('E0',16))
        elif par2[1] == 3:
            # It's A,@Ri
            target.CodeByte(int('E2',16)+par2[0])
        else:
            errors.DoError('badoper', False)
            return
    elif par1[1] == 7:
        # It's @DPTR,A mode
        if par2[1] != 1:
            errors.DoError('badoper', False)
            return
        target.CodeByte(int('F0',16))
    elif par1[1] == 3:
        # It's @Ri,A mode
        if par2[1] != 1:
            errors.DoError('badoper', False)
            return
        target.CodeByte(int('F2',16)+par1[0])
    else:
        errors.DoError('badoper', False)
        return
        
    NoMore()
        
#-----------------------------------------------------------------------------

def BitInst():    

    """
    Handle CLR, CPL and SETB instructions.
    """
            
    global Asm
    
    if MissingOperand():
        return

    pntr = dec.Asm.Parse_Pointer
    par1 = assem.GetWord().upper()
    
    if par1 == 'A':
        # A parameter
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
        if opcode == 0:
            errors.DoError('badoper', False)
        else:
            target.CodeByte(opcode)
        
    elif par1 == 'C':
        # C parameter
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16))
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
      
    else:
        dec.Asm.Parse_Pointer = pntr
        par1 = GetBit()
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16))
        target.CodeByte(par1)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
    
    NoMore()
        
#-----------------------------------------------------------------------------

def Specials():
    
    """
    Handle all sorts of inherent and one operand instructions. Each instruction
    has only one addressing mode.
    """
     
    global Asm

    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16))
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
    if dec.Asm.Mnemonic in ('NOP', 'RET', 'RETI'):
        return
    
    if MissingOperand():
        return

    pl = dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:].upper()
    if dec.Asm.Mnemonic in ('DIV', 'MUL'):
        if pl[0:3] != 'AB ':
            errors.DoError('badoper', False)
    else:
        if pl[0:2] != 'A ':
            errors.DoError('badoper', False)
        
#-----------------------------------------------------------------------------

def Singles():
       
    """
    Handle single operand instructions, where multiple addressing modes are
    allowed per instruction.
    """
     
    global Asm
    
    if MissingOperand():
        return

    value = GetRegDir()
    register = value[0]
    mode = value[1]
    
    opcode = 0
    
    if mode <= 4:
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][mode],16)
        timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][mode]
        
    if opcode == 0 and mode == 2:
        # Translate non existing Register opcode back to direct opcode
        register = register + (dec.Asm.RB8051 << 3)
        mode = 0
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][mode],16)
        timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][mode]
        
    if opcode == 0:
        errors.DoError('badoper', False)
    else:
        if mode == 0:
            target.CodeByte(opcode)
            target.CodeByte(register)
        else:
            target.CodeByte(opcode+register)
        dec.Asm.Timing = timing
        
    NoMore()
        
#-----------------------------------------------------------------------------

def Jumps():

    """
    Handle xJMP and xCALL instructions. The intelligent JMP and CALL instructions
    determine the addressing mode to be used depending on the current location
    and the destination.
    """
        
    global Asm
        
    if MissingOperand():
        return

    opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16)
    
    if dec.Asm.Mnemonic == 'JMP' and assem.NowChar() == '@':
        # Could be JUMP @A+DPTR
        pntr = dec.Asm.Parse_Pointer
        if assem.GetWord().upper() == '@A+DPTR':
            # It is JMP @A+DPTR indeed
            opcode = int('73',16)
            target.CodeByte(opcode)
            dec.Asm.Timing = '2'
            NoMore()
            return
        dec.Asm.Parse_Pointer = pntr
        
    value = assem.EvalExpr()
    addrpage = (value[0] >> 11) & 31
    pcpage = ((dec.Asm.BOL_Address + 2) >> 11) & 31
    
    if dec.Asm.Mnemonic in ('JMP', 'CALL'):
        # It's smart JMP or CALL, see if we can use A version
        uselong = False
        if value[1]:
            # A forward referenced label was used, always use long version
            uselong = True
        else:
            if addrpage != pcpage:
                # Destination is at different page
                uselong = True
        if uselong:
            dec.Asm.Mnemonic = 'L' + dec.Asm.Mnemonic
        else:
            dec.Asm.Mnemonic = 'A' + dec.Asm.Mnemonic

    opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16)

    if dec.Asm.Mnemonic[0] == 'L':
        # Long JUMP or CALL
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
        target.CodeByte(opcode)
        target.CodeWord(value[0])
    else:
        # AJMP or ACALL, check and prepare destination
        if dec.Asm.Pass == 2:
            # Only test range during pass 2 when we're sure of the destination
            if addrpage != pcpage:
                errors.DoError('range', False)
        addrh = (value[0] >> 8) & 7
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
        target.CodeByte(opcode + (addrh << 5))
        target.CodeByte(value[0])
        
    if dec.Asm.Pass == 2 and value[0] >> 16 != 0:
        # Destination is beyond 64kB
        errors.DoError('range', False)
        
    NoMore()

#-----------------------------------------------------------------------------

def Math():    
       
    """
    Handle the math instructions.
    """
     
    global Asm

    if MissingOperand():
        return

    pntr = dec.Asm.Parse_Pointer
    par1 = assem.GetWord().upper()
    
    if par1 == 'C':
        # Handle bit math instruction
        if not assem.MoreParameters():
            errors.DoError('missoper', False)
            return
        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][6],16)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][6]
        if assem.NowChar() == '/':
            # It's inverse bit mode
            assem.IncParsePointer()
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][7],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][7]
        par2 = GetBit()
        
        if opcode == 0:
            errors.DoError('badoper', False)
        else:
            target.CodeByte(opcode)
            target.CodeByte(par2)

        NoMore()
        return
        
    dec.Asm.Parse_Pointer = pntr
    par1 = GetRegDir()
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    par2 = GetRegDir()

    if par1[1] == 2:
        # First operand can't be register, translate it to  direct address
        par1 = (dec.Asm.RB8051 * 8 + par1[0], 0)    
    
    if par1[1] == 0:
        # First operand is a direct address
        if par2[1] == 1:
            # DIR,A
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][4],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][4]
            if opcode == 0:
                errors.DoError('badoper', False)
            else:
                target.CodeByte(opcode)
                target.CodeByte(par1[0])
        
        elif par2[1] == 8:
            # DIR,#
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][5],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][5]
            if opcode == 0:
                errors.DoError('badoper', False)
            else:
                target.CodeByte(opcode)
                target.CodeByte(par1[0])
                target.CodeByte(par2[0])
                        
        else:
            errors.DoError('badoper', False)
    
    elif par1[1] == 1:
        # First operand is A
        if par2[1] == 0:
            # A,DIR
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
            target.CodeByte(opcode)
            target.CodeByte(par2[0])
        
        elif par2[1] == 2:
            # A,Rn
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][0],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]
            target.CodeByte(opcode+par2[0])
            
        elif par2[1] == 3:
            # A,@Ri
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]
            target.CodeByte(opcode+par2[0])
            
        elif par2[1] == 8:
            # A,#
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][3],16)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][3]
            if opcode == 0:
                errors.DoError('badoper', False)
            else:
                target.CodeByte(opcode)
                target.CodeByte(par2[0])
            
        else:
            errors.DoError('badoper', False)
        
    else:
        errors.DoError('badoper', False)

    NoMore()
        
#-----------------------------------------------------------------------------

def Branch():
    
    """
    Handle the simple branch instructions.
    """
     
    global Asm
        
    if MissingOperand():
        return
        
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

    value = assem.EvalExpr()
    offset = value[0] - dec.Asm.BOL_Address - 2

    if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
        errors.DoError('range', False)

    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16))
    target.CodeByte(offset)
    
    NoMore()

#-----------------------------------------------------------------------------

def BranchBit():
    
    """
    Handle the bit test branch instructions.
    """
     
    global Asm

    if MissingOperand():
        return
        
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

    par1 = GetBit()
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    value = assem.EvalExpr()
    offset = value[0] - dec.Asm.BOL_Address - 3

    if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
        errors.DoError('range', False)

    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16))
    target.CodeByte(par1)
    target.CodeByte(offset)
    
    NoMore()

#-----------------------------------------------------------------------------

def BranchTest():
    
    """
    Handle the test and branch instructions.
    """
     
    global Asm
        
    if MissingOperand():
        return
        
    dec.Asm.Timing = '2'

    par1 = GetReg()
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    par2 = GetRegDir()

    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    value = assem.EvalExpr()
    offset = value[0] - dec.Asm.BOL_Address - 3

    if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
        errors.DoError('range', False)

    regoffset = 0

    if par1[1] == 1:
        # First parameter is A
        if par2[1] == 0:
            # It's A,DIR,REL
            index = 1
        
        elif par2[1] == 8:
            # It's A,#,REL
            index = 2
        
        elif par2[1] == 2:
            # It's A,Rn,REL which must be translated to A,DIR,REL
            index = 1
            regoffset = dec.Asm.RB8051 << 3

        else:
            index = 0
            
    elif par1[1] == 2:
        # First parameter is Rn
        if par2[1] == 8:
            # It's Rn,#,REL
            index = 3
        else:
            index = 0
        
    elif par1[1] == 3:
        # First parameter is @Ri
        if par2[1] == 8:
            # It's @Ri,#,REL
            index = 4
        else:
            index = 0
        
    else:
        index = 0
        
    if index == 0:
        errors.DoError('badoper', False)
        return

    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][index],16)+par1[0])
    target.CodeByte(par2[0] + regoffset)
    target.CodeByte(offset)
    
    NoMore()

#-----------------------------------------------------------------------------

def BranchLoop():
    
    """
    Handle the loop instruction.
    """
        
    global Asm
        
    if MissingOperand():
        return
        
    dec.Asm.Timing = '2'

    par1 = GetRegDir()
    
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    value = assem.EvalExpr()
    
    if par1[1] == 2:
        # It's Rn,REL
        offset = value[0] - dec.Asm.BOL_Address - 2
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16)+par1[0])
        target.CodeByte(offset)
        
    elif par1[1] == 0:
        # It's DIR,REL
        offset = value[0] - dec.Asm.BOL_Address - 3
        target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][2],16))
        target.CodeByte(par1[0])
        target.CodeByte(offset)

    else:
        errors.DoError('badoper', False)
        return
        
    if dec.Asm.Pass == 2 and (offset < -128 or offset > 127):
        errors.DoError('range', False)

    NoMore()

#-----------------------------------------------------------------------------

def XchdInst():

    """
    Handle the XCHD instruction.
    """

    global Asm
        
    if MissingOperand():
        return
        
    dec.Asm.Timing = '1'

    if assem.NowChar(True).upper() != 'A':
        errors.DoError('badoper', False)
        return
        
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return

    par2 = GetReg()
    
    if par2[1] != 3:
        errors.DoError('badoper', False)
        return

    target.CodeByte(int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16)+par2[0])

    NoMore()

#-----------------------------------------------------------------------------

def DirRB():

    """
    Select a register bank (0 to 3)
    """

    global Asm
    
    if MissingOperand():
        return

    value = assem.EvalExpr()

    if value[1]:
        # Forward reference labels are not allowed.
        errors.DoError('forwref', False)    
    
    if value[0] >> 2 != 0:
        errors.DoError('range', False)
        
    dec.Asm.RB8051 = value[0] & 3

#-----------------------------------------------------------------------------

def DirEQ():
    
    """
    The normal .EQ directive can't handle bit addresses. Bit address names end
    in .0 to .7
    If the parameter doesn't end in .0 to .7 the normal EQ directive is used
    to handle the request.
    Please keep in mind that .0 to .7 may end any evaluatable value.
    Thus SFR.7 is legal, as is 5+SFR*3.5, as long as it results in a legal
    bit address that is.
    This is new behaviour for version 3. So if you want to keep your programs
    compatible with version 2 you'd better not use labels ending in .0 to .7
    using the .EQ directive.
    """
    
    global Asm
    
    if dec.Asm.Parse_Pointer == 0:
        # No parameter given
        errors.DoError('missoper', False)
        dec.Asm.New_Label = ""
        return True
        
    pntr= dec.Asm.Parse_Pointer
    arg = assem.GetWord()
    if not(len(arg) > 2 and arg[-2] == '.' and arg[-1] in '01234567'):
        # It is not a bit notation. No need to DIY
        dec.Asm.Parse_Pointer = pntr
        return False
    
    bitno = int(arg[-1])
    parseline = dec.Asm.Parse_Line
    dec.Asm.Parse_Line = parseline[:dec.Asm.Parse_Pointer-2] + ' '
    dec.Asm.Parse_Pointer = pntr
    value = assem.EvalExpr()
    dec.Asm.Parse_Line = parseline
    dec.Asm.Parse_Pointer = dec.Asm.Parse_Pointer + 2
    
    if dec.Flags.ErrorInLine:
        # Don't assing label if errors found
        dec.Asm.New_Label = ""
    else:
        # No errors found, so far
        if dec.Asm.Pass == 1:
            # Pass 1
            if value[1]:
                errors.DoError('forwref', False)
                dec.Asm.New_Label = ""
            else:
                if value[0] in range(int('20',16), int('30',16)):
                    val = ((value[0] & 15) << 3) + bitno
                elif value[0] in range(int('80',16), int('FF',16),8):
                    val = value[0] + bitno
                else:
                    errors.DoError('range', False)
                    val = 0
                   
                dec.Asm.BOL_Address = val
                dec.Asm.List_Address = val
                if not assem.NowChar() in ' ,':
                    errors.DoError('badoper', False)
        else:
            # Pass 2
            if value[1]:
                # If the user hasn't done anything stupid, this can never happen
                errors.DoError('forwref', False)
                dec.Asm.New_Label = ""
            else:
                if value[0] in range(int('20',16), int('30',16)):
                    val = ((value[0] & 15) << 3) + bitno
                elif value[0] in range(int('80',16), int('FF',16),8):
                    val = value[0] + bitno
                else:
                    errors.DoError('range', False)
                    val = 0

                dec.Asm.BOL_Address = val
                dec.Asm.List_Address = val
                if not assem.NowChar() in ' ,':
                    errors.DoError('badoper', False)

    return True
                    
#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print

