#------------------------------------------------------------------------------
#
#   crz180.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   Cross Overlay for the Z180 family of processors
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target
import crz80

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags

    assem.CheckVersions(crossversion, minversion)
    
    dec.Asm.Instructions = {
        'CCF'  : (crz80.Inherent,int('3F',16),'3'),
        'CPL'  : (crz80.Inherent,int('2F',16),'3'),
        'DAA'  : (crz80.Inherent,int('27',16),'4'),
        'DI'   : (crz80.Inherent,int('F3',16),'3'),
        'EI'   : (crz80.Inherent,int('FB',16),'3'),
        'EXX'  : (crz80.Inherent,int('D9',16),'3'),
        'HALT' : (crz80.Inherent,int('76',16),'3'),
        'NOP'  : (crz80.Inherent,int('00',16),'3'),
        'RLA'  : (crz80.Inherent,int('17',16),'3'),
        'RLCA' : (crz80.Inherent,int('07',16),'3'),
        'RRA'  : (crz80.Inherent,int('1F',16),'3'),
        'RRCA' : (crz80.Inherent,int('0F',16),'3'),
        'SCF'  : (crz80.Inherent,int('37',16),'3'),
        'CPD'  : (crz80.Inherent,int('EDA9',16),'12'),
        'CPDR' : (crz80.Inherent,int('EDB9',16),'12+'),
        'CPI'  : (crz80.Inherent,int('EDA1',16),'12'),
        'CPIR' : (crz80.Inherent,int('EDB1',16),'12+'),
        'IND'  : (crz80.Inherent,int('EDAA',16),'12'),
        'INDR' : (crz80.Inherent,int('EDBA',16),'12+'),
        'INI'  : (crz80.Inherent,int('EDA2',16),'12'),
        'INIR' : (crz80.Inherent,int('EDB2',16),'12+'),
        'LDD'  : (crz80.Inherent,int('EDA8',16),'12'),
        'LDDR' : (crz80.Inherent,int('EDB8',16),'12+'),
        'LDI'  : (crz80.Inherent,int('EDA0',16),'12'),
        'LDIR' : (crz80.Inherent,int('EDB0',16),'12+'),
        'NEG'  : (crz80.Inherent,int('ED44',16),'6'),
        'OTDR' : (crz80.Inherent,int('EDBB',16),'14+'),
        'OTDM' : (crz80.Inherent,int('ED8B',16),'14'),
        'OTDMR': (crz80.Inherent,int('ED9B',16),'14+'),
        'OTIR' : (crz80.Inherent,int('EDB3',16),'12+'),
        'OTIM' : (crz80.Inherent,int('ED83',16),'12'),
        'OTIMR': (crz80.Inherent,int('ED93',16),'12+'),
        'OUTD' : (crz80.Inherent,int('EDAB',16),'12'),
        'OUTI' : (crz80.Inherent,int('EDA3',16),'12'),
        'RCF'  : (crz80.Inherent,int('373F',16),'6'),
        'RETI' : (crz80.Inherent,int('ED4D',16),'12+'),
        'RETN' : (crz80.Inherent,int('ED45',16),'12'),
        'RLD'  : (crz80.Inherent,int('ED6F',16),'16'),
        'RRD'  : (crz80.Inherent,int('ED67',16),'16'),
        'SLP'  : (crz80.Inherent,int('ED76',16),'8'),
        'IM0'  : (crz80.Inherent,int('ED46',16),'6'),
        'IM1'  : (crz80.Inherent,int('ED56',16),'6'),
        'IM2'  : (crz80.Inherent,int('ED5E',16),'6'),

        'LD'     : (crz80.Load,),
        'LD.A'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)','(BC)','(DE)','(M)','I','R'),('7F','78','79','7A','7B','7C','7D','7E','3E','DD7E','FD7E','0A','1A','3A','ED57','ED5F'),('4','4','4','4','4','4','4','6','6','14','14','6','6','12','6','6'),(0,0,0,0,0,0,0,0,1,1,1,0,0,2,0,0)),
        'LD.B'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('47','40','41','42','43','44','45','46','06','DD46','FD46'),('4','4','4','4','4','4','4','6','6','14','14'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.C'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('4F','48','49','4A','4B','4C','4D','4E','0E','DD4E','FD4E'),('4','4','4','4','4','4','4','6','6','14','14'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.D'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('57','50','51','52','53','54','55','56','16','DD56','FD56'),('4','4','4','4','4','4','4','6','6','14','14'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.E'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('5F','58','59','5A','5B','5C','5D','5E','1E','DD5E','FD5E'),('4','4','4','4','4','4','4','6','6','14','14'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.H'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('67','60','61','62','63','64','65','66','26','DD66','FD66'),('4','4','4','4','4','4','4','6','6','14','14'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.L'   : (('A','B','C','D','E','H','L','(HL)','#','(IX)','(IY)'),('6F','68','69','6A','6B','6C','6D','6E','2E','DD6E','FD6E'),('4','4','4','4','4','4','4','6','6','14','14'),(0,0,0,0,0,0,0,0,1,1,1)),
        'LD.I'   : (('A',),('ED47',),('6',),(0,)),
        'LD.R'   : (('A',),('ED4F',),('6',),(0,)),
        'LD.(HL)': (('#','A','B','C','D','E','H','L'),('36','77','70','71','72','73','74','75'),('9','7','7','7','7','7','7','7'),(1,0,0,0,0,0,0,0)),
        'LD.(IX)': (('#','A','B','C','D','E','H','L'),('DD36','DD77','DD70','DD71','DD72','DD73','DD74','DD75'),('15','15','15','15','15','15','15','15'),(4,3,3,3,3,3,3,3)),
        'LD.(IY)': (('#','A','B','C','D','E','H','L'),('FD36','FD77','FD70','FD71','FD72','FD73','FD74','FD75'),('15','15','15','15','15','15','15','15'),(4,3,3,3,3,3,3,3)),
        'LD.(BC)': (('A',),('02',),('7',),(0,)),
        'LD.(DE)': (('A',),('12',),('7',),(0,)),
        'LD.(M)' : (('A','BC','DE','HL','SP','IX','IY'),('32','ED43','ED53','22','ED73','DD22','FD22'),('13','20','20','20','20','20','20'),(5,5,5,5,5,5,5)),
        'LD.BC'  : (('#','(M)'),('01','ED4B'),('9','18'),(2,2)),
        'LD.DE'  : (('#','(M)'),('11','ED5B'),('9','18'),(2,2)),
        'LD.HL'  : (('#','(M)'),('21','2A'),('9','15'),(2,2)),
        'LD.SP'  : (('#','(M)','HL','IX','IY'),('31','ED7B','F9','DDF9','FDF9'),('9','18','4','7','7'),(2,2,0,0,0)),
        'LD.IX'  : (('#','(M)'),('DD21','DD2A'),('12','18'),(2,2)),
        'LD.IY'  : (('#','(M)'),('FD21','FD2A'),('12','18'),(2,2)),

        'POP' : (crz80.Stack, int('C1',16), ('9','12')),
        'PUSH': (crz80.Stack, int('C5',16), ('11','14')),
        'MLT' : (crz80.Mult, int('ED4C',16),'17'),
        
        'ADC' : (crz80.Math, ('88','DD8E','FD8E','CE','ED4A'), ('4/6','14','14','6','10')),
        'ADD' : (crz80.Math, ('80','DD86','FD86','C6','09','DD09','FD09'), ('4/6','14','14','6','7','10','10')),
        'AND' : (crz80.Math, ('A0','DDA6','FDA6','E6'), ('4/6','14','14','6')),
        'CP'  : (crz80.Math, ('B8','DDBE','FDBE','FE'), ('4/6','14','14','6')),
        'OR'  : (crz80.Math, ('B0','DDB6','FDB6','F6'), ('4/6','14','14','6')),
        'SBC' : (crz80.Math, ('98','DD9E','FD9E','DE','ED42'), ('4/6','14','14','6','10')),
        'SUB' : (crz80.Math, ('90','DD96','FD96','D6'), ('4/6','14','14','6')),
        'XOR' : (crz80.Math, ('A8','DDAE','FDAE','EE'), ('4/6','14','14','6')),
        'TST' : (crz80.Math, ('ED04','0','0','ED64'), ('7/10','0','0','9')),
        
        'DEC' : (crz80.IncDec, ('05','35','DD35','FD35','0B','DD2B','FD2B'),('4','10','18','18','4','7','7')),
        'INC' : (crz80.IncDec, ('04','34','DD34','FD34','03','DD23','FD23'),('4','10','18','18','4','7','7')),

        'CALL': (crz80.Jumps, ('CD','C4'),('16','6+')),
        'JP'  : (crz80.Jumps, ('C3','C2','E9','DDE9','FDE9'),('9','6+','3','6','6')),

        'JR'  : (crz80.Branch, ('18','38','30','28','20'),('8','6+','6+','6+','6+')),
        'DJNZ': (crz80.Branch, ('10',),('7+',)),

        'RET' : (crz80.Returns, ('C9','C0'),('9','5+')),

        'RLC' : (crz80.Singles, ('CB00','CB06','06'),('7','13','19')),
        'RL'  : (crz80.Singles, ('CB10','CB16','16'),('7','13','19')),
        'RRC' : (crz80.Singles, ('CB08','CB0E','0E'),('7','13','19')),
        'RR'  : (crz80.Singles, ('CB18','CB1E','1E'),('7','13','19')),
        'SLA' : (crz80.Singles, ('CB20','CB26','26'),('7','13','19')),
        'SRA' : (crz80.Singles, ('CB28','CB2E','2E'),('7','13','19')),
        'SRL' : (crz80.Singles, ('CB38','CB3E','3E'),('7','13','19')),
        'BIT' : (crz80.Bits, ('CB40','CB46','46'),('6','9','15')),
        'RES' : (crz80.Bits, ('CB80','CB86','86'),('7','13','19')),
        'SET' : (crz80.Bits, ('CBC0','CBC6','C6'),('7','13','19')),
        
        'IN'  : (crz80.InOut, ('ED40','DB'),('9','9')),
        'OUT' : (crz80.InOut, ('ED41','D3'),('10','10')),
        'INO' : (crz80.InOut, ('ED00','0'),('12','0')),
        'OUTO': (crz80.InOut, ('ED01','0'),('13','0')),
        'TSTIO': (crz80.InOut, ('ED74','00'),('12','0')),

        'EX'  : (crz80.Exch, ('EB','08','E3','DDE3','FDE3'),('3','4','16','19','19')),
        'IM'  : (crz80.IM, ('ED46','ED56','ED5E'),'6'),

        'RST' : (crz80.Restart,int('C7',16),'11')
        }

    dec.Asm.Memory = 0
    length = 0

    dec.Asm.Timing_Length = 3

    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = dec.MAX16
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = False
    
    return

#------------------------------------------------------------------------------

def CrossDirective():

    # This cross overlay has no extra/changed directives
    
    return False    # We didn't handle any directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    # This cross overlay does not need any clean up
    
    return

#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm

    if '.' in dec.Asm.Mnemonic:
        # Avoid mnemonics like LD.A from being accepted
        errors.DoError('badopco',False)
        return

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    

