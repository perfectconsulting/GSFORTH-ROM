#------------------------------------------------------------------------------
#
#   cr8008.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   8008 Cross Overlay
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags

    assem.CheckVersions(crossversion, minversion)
    
    # The instructions directory contains a tuple with:
    #   function which handles this opcode,
    #   integer value of opcode
    #   string with cycle time(s) of this instruction on an 8085

    dec.Asm.Instructions = {
        'MOV' : (MovInst,int('C0',16),'5'),
        'MVI' : (MviInst,int('06',16),'8'),

        'INR' : (IncDec,int('08',16),'5'),
        'DCR' : (IncDec,int('09',16),'5'),

        'ADD' : (Math,int('80',16),'5'),
        'ADC' : (Math,int('88',16),'5'),
        'SUB' : (Math,int('90',16),'5'),
        'SBB' : (Math,int('98',16),'5'),
        'ANA' : (Math,int('A0',16),'5'),
        'XRA' : (Math,int('A8',16),'5'),
        'ORA' : (Math,int('B0',16),'5'),
        'CMP' : (Math,int('B8',16),'5'),

        'JMP' : (Jumps,int('44',16),'11'),
        'JFC' : (Jumps,int('40',16),'9/11'),
        'JNC' : (Jumps,int('40',16),'9/11'),
        'JFZ' : (Jumps,int('48',16),'9/11'),
        'JNZ' : (Jumps,int('48',16),'9/11'),
        'JFS' : (Jumps,int('50',16),'9/11'),
        'JP'  : (Jumps,int('50',16),'9/11'),
        'JFP' : (Jumps,int('58',16),'9/11'),
        'JPO' : (Jumps,int('58',16),'9/11'),
        'JTC' : (Jumps,int('60',16),'9/11'),
        'JC'  : (Jumps,int('60',16),'9/11'),
        'JTZ' : (Jumps,int('68',16),'9/11'),
        'JZ'  : (Jumps,int('68',16),'9/11'),
        'JTS' : (Jumps,int('70',16),'9/11'),
        'JM'  : (Jumps,int('70',16),'9/11'),
        'JTP' : (Jumps,int('78',16),'9/11'),
        'JPE' : (Jumps,int('78',16),'9/11'),
        'CAL' : (Jumps,int('46',16),'11'),
        'CALL': (Jumps,int('46',16),'11'),
        'CFC' : (Jumps,int('42',16),'9/11'),
        'CNC' : (Jumps,int('42',16),'9/11'),
        'CFZ' : (Jumps,int('4A',16),'9/11'),
        'CNZ' : (Jumps,int('4A',16),'9/11'),
        'CFS' : (Jumps,int('52',16),'9/11'),
        'CP'  : (Jumps,int('52',16),'9/11'),
        'CFP' : (Jumps,int('5A',16),'9/11'),
        'CPO' : (Jumps,int('5A',16),'9/11'),
        'CTC' : (Jumps,int('62',16),'9/11'),
        'CC'  : (Jumps,int('62',16),'9/11'),
        'CTZ' : (Jumps,int('6A',16),'9/11'),
        'CZ'  : (Jumps,int('6A',16),'9/11'),
        'CTS' : (Jumps,int('72',16),'9/11'),
        'CM'  : (Jumps,int('72',16),'9/11'),
        'CTP' : (Jumps,int('7A',16),'9/11'),
        'CPE' : (Jumps,int('7A',16),'9/11'),

        'LAA' : (Inherent,int('C0',16),'5'),
        'LAB' : (Inherent,int('C1',16),'5'),
        'LAC' : (Inherent,int('C2',16),'5'),
        'LAD' : (Inherent,int('C3',16),'5'),
        'LAE' : (Inherent,int('C4',16),'5'),
        'LAH' : (Inherent,int('C5',16),'5'),
        'LAL' : (Inherent,int('C6',16),'5'),
        'LAM' : (Inherent,int('C7',16),'8'),
        'LBA' : (Inherent,int('C8',16),'5'),
        'LBB' : (Inherent,int('C9',16),'5'),
        'LBC' : (Inherent,int('CA',16),'5'),
        'LBD' : (Inherent,int('CB',16),'5'),
        'LBE' : (Inherent,int('CC',16),'5'),
        'LBH' : (Inherent,int('CD',16),'5'),
        'LBL' : (Inherent,int('CE',16),'5'),
        'LBM' : (Inherent,int('CF',16),'8'),
        'LCA' : (Inherent,int('D0',16),'5'),
        'LCB' : (Inherent,int('D1',16),'5'),
        'LCC' : (Inherent,int('D2',16),'5'),
        'LCD' : (Inherent,int('D3',16),'5'),
        'LCE' : (Inherent,int('D4',16),'5'),
        'LCH' : (Inherent,int('D5',16),'5'),
        'LCL' : (Inherent,int('D6',16),'5'),
        'LCM' : (Inherent,int('D7',16),'8'),
        'LDA' : (Inherent,int('D8',16),'5'),
        'LDB' : (Inherent,int('D9',16),'5'),
        'LDC' : (Inherent,int('DA',16),'5'),
        'LDD' : (Inherent,int('DB',16),'5'),
        'LDE' : (Inherent,int('DC',16),'5'),
        'LDH' : (Inherent,int('DD',16),'5'),
        'LDL' : (Inherent,int('DE',16),'5'),
        'LDM' : (Inherent,int('DF',16),'8'),
        'LEA' : (Inherent,int('E0',16),'5'),
        'LEB' : (Inherent,int('E1',16),'5'),
        'LEC' : (Inherent,int('E2',16),'5'),
        'LED' : (Inherent,int('E3',16),'5'),
        'LEE' : (Inherent,int('E4',16),'5'),
        'LEH' : (Inherent,int('E5',16),'5'),
        'LEL' : (Inherent,int('E6',16),'5'),
        'LEM' : (Inherent,int('E7',16),'8'),
        'LHA' : (Inherent,int('E8',16),'5'),
        'LHB' : (Inherent,int('E9',16),'5'),
        'LHC' : (Inherent,int('EA',16),'5'),
        'LHD' : (Inherent,int('EB',16),'5'),
        'LHE' : (Inherent,int('EC',16),'5'),
        'LHH' : (Inherent,int('ED',16),'5'),
        'LHL' : (Inherent,int('EE',16),'5'),
        'LHM' : (Inherent,int('EF',16),'8'),
        'LLA' : (Inherent,int('F0',16),'5'),
        'LLB' : (Inherent,int('F1',16),'5'),
        'LLC' : (Inherent,int('F2',16),'5'),
        'LLD' : (Inherent,int('F3',16),'5'),
        'LLE' : (Inherent,int('F4',16),'5'),
        'LLH' : (Inherent,int('F5',16),'5'),
        'LLL' : (Inherent,int('F6',16),'5'),
        'LLM' : (Inherent,int('F7',16),'8'),
        'LMA' : (Inherent,int('F8',16),'7'),
        'LMB' : (Inherent,int('F9',16),'7'),
        'LMC' : (Inherent,int('FA',16),'7'),
        'LMD' : (Inherent,int('FB',16),'7'),
        'LME' : (Inherent,int('FC',16),'7'),
        'LMH' : (Inherent,int('FD',16),'7'),
        'LML' : (Inherent,int('FE',16),'7'),

        'INB' : (Inherent,int('08',16),'5'),
        'INC' : (Inherent,int('10',16),'5'),
        'IND' : (Inherent,int('18',16),'5'),
        'INE' : (Inherent,int('20',16),'5'),
        'INH' : (Inherent,int('28',16),'5'),
        'INL' : (Inherent,int('30',16),'5'),
        'DCB' : (Inherent,int('09',16),'5'),
        'DCC' : (Inherent,int('11',16),'5'),
        'DCD' : (Inherent,int('19',16),'5'),
        'DCE' : (Inherent,int('21',16),'5'),
        'DCH' : (Inherent,int('29',16),'5'),
        'DCL' : (Inherent,int('31',16),'5'),

        'ADA' : (Inherent,int('80',16),'5'),
        'ADB' : (Inherent,int('81',16),'5'),
#        'ADC' : (Inherent,int('82',16),'5'),
#        'ADD' : (Inherent,int('83',16),'5'),
        'ADE' : (Inherent,int('84',16),'5'),
        'ADH' : (Inherent,int('85',16),'5'),
        'ADL' : (Inherent,int('86',16),'5'),
        'ADM' : (Inherent,int('87',16),'8'),
        'ACA' : (Inherent,int('88',16),'5'),
        'ACB' : (Inherent,int('89',16),'5'),
        'ACC' : (Inherent,int('8A',16),'5'),
        'ACD' : (Inherent,int('8B',16),'5'),
        'ACE' : (Inherent,int('8C',16),'5'),
        'ACH' : (Inherent,int('8D',16),'5'),
        'ACL' : (Inherent,int('8E',16),'5'),
        'ACM' : (Inherent,int('8F',16),'8'),
        'SUA' : (Inherent,int('90',16),'5'),
#        'SUB' : (Inherent,int('91',16),'5'),
        'SUC' : (Inherent,int('92',16),'5'),
        'SUD' : (Inherent,int('93',16),'5'),
        'SUE' : (Inherent,int('94',16),'5'),
        'SUH' : (Inherent,int('95',16),'5'),
        'SUL' : (Inherent,int('96',16),'5'),
        'SUM' : (Inherent,int('97',16),'8'),
        'SBA' : (Inherent,int('98',16),'5'),
#        'SBB' : (Inherent,int('99',16),'5'),
        'SBC' : (Inherent,int('9A',16),'5'),
        'SBD' : (Inherent,int('9B',16),'5'),
        'SBE' : (Inherent,int('9C',16),'5'),
        'SBH' : (Inherent,int('9D',16),'5'),
        'SBL' : (Inherent,int('9E',16),'5'),
        'SBM' : (Inherent,int('9F',16),'8'),
        'NDA' : (Inherent,int('A0',16),'5'),
        'NDB' : (Inherent,int('A1',16),'5'),
        'NDC' : (Inherent,int('A2',16),'5'),
        'NDD' : (Inherent,int('A3',16),'5'),
        'NDE' : (Inherent,int('A4',16),'5'),
        'NDH' : (Inherent,int('A5',16),'5'),
        'NDL' : (Inherent,int('A6',16),'5'),
        'NDM' : (Inherent,int('A7',16),'8'),
#        'XRA' : (Inherent,int('A8',16),'5'),
        'XRB' : (Inherent,int('A9',16),'5'),
        'XRC' : (Inherent,int('AA',16),'5'),
        'XRD' : (Inherent,int('AB',16),'5'),
        'XRE' : (Inherent,int('AC',16),'5'),
        'XRH' : (Inherent,int('AD',16),'5'),
        'XRL' : (Inherent,int('AE',16),'5'),
        'XRM' : (Inherent,int('AF',16),'8'),
#        'ORA' : (Inherent,int('B0',16),'5'),
        'ORB' : (Inherent,int('B1',16),'5'),
        'ORC' : (Inherent,int('B2',16),'5'),
        'ORD' : (Inherent,int('B3',16),'5'),
        'ORE' : (Inherent,int('B4',16),'5'),
        'ORH' : (Inherent,int('B5',16),'5'),
        'ORL' : (Inherent,int('B6',16),'5'),
        'ORM' : (Inherent,int('B7',16),'8'),
        'CPA' : (Inherent,int('B8',16),'5'),
        'CPB' : (Inherent,int('B9',16),'5'),
        'CPC' : (Inherent,int('BA',16),'5'),
        'CPD' : (Inherent,int('BB',16),'5'),
#        'CPE' : (Inherent,int('BC',16),'5'),
        'CPH' : (Inherent,int('BD',16),'5'),
        'CPL' : (Inherent,int('BE',16),'5'),
        'CPM' : (Inherent,int('BF',16),'8'),
        
        'RLC' : (Inherent,int('02',16),'5'),
        'RRC' : (Inherent,int('0A',16),'5'),
        'RAL' : (Inherent,int('12',16),'5'),
        'RAR' : (Inherent,int('1A',16),'5'),
        
        'HLT' : (Inherent,int('00',16),'4'),

        'RET' : (Inherent,int('07',16),'5'),
        'RFC' : (Inherent,int('03',16),'3/5'),
        'RNC' : (Inherent,int('03',16),'3/5'),
        'RFZ' : (Inherent,int('0B',16),'3/5'),
        'RNZ' : (Inherent,int('0B',16),'3/5'),
        'RFS' : (Inherent,int('13',16),'3/5'),
        'RP'  : (Inherent,int('13',16),'3/5'),
        'RFP' : (Inherent,int('1B',16),'3/5'),
        'RPO' : (Inherent,int('1B',16),'3/5'),

        'RTC' : (Inherent,int('23',16),'3/5'),
        'RC'  : (Inherent,int('23',16),'3/5'),
        'RTZ' : (Inherent,int('2B',16),'3/5'),
        'RZ'  : (Inherent,int('2B',16),'3/5'),
        'RTS' : (Inherent,int('33',16),'3/5'),
        'RM'  : (Inherent,int('33',16),'3/5'),
        'RTP' : (Inherent,int('3B',16),'3/5'),
        'RPE' : (Inherent,int('3B',16),'3/5'),

        'LAI' : (Immediate,int('06',16),'8'),
        'LBI' : (Immediate,int('0E',16),'8'),
        'LCI' : (Immediate,int('16',16),'8'),
        'LDI' : (Immediate,int('1E',16),'8'),
        'LEI' : (Immediate,int('26',16),'8'),
        'LHI' : (Immediate,int('2E',16),'8'),
        'LLI' : (Immediate,int('36',16),'8'),
        'LMI' : (Immediate,int('3E',16),'9'),

        'ADI' : (Immediate,int('04',16),'8'),
        'ACI' : (Immediate,int('0C',16),'8'),
        'SUI' : (Immediate,int('14',16),'8'),
        'SBI' : (Immediate,int('1C',16),'8'),
        'NDI' : (Immediate,int('24',16),'8'),
        'ANI' : (Immediate,int('24',16),'8'),
        'XRI' : (Immediate,int('2C',16),'8'),
        'ORI' : (Immediate,int('34',16),'8'),
        'CPI' : (Immediate,int('3C',16),'8'),

        'IN'  : (InOut,int('41',16),'8'),
        'INP' : (InOut,int('41',16),'8'),
        'OUT' : (InOut,int('41',16),'6'),

        'RST' : (Restart,int('05',16),'5')
        }

    dec.Asm.Memory = 0
    dec.Asm.Timing_Length = 4

    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = (1 << 14)-1
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = False
    
    return

#------------------------------------------------------------------------------

def CrossDirective():

    # This cross overlay has no extra/changed directives
    
    return False    # We didn't handle any directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    # This cross overlay does not need any clean up
    
    return

#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
        func()
    else:
        errors.DoError('badopco', False)

#-----------------------------------------------------------------------------

def MissingOperand():

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)

#-----------------------------------------------------------------------------

def MovInst():

    global Asm
    
    if MissingOperand():
        return

    registers = 'ABCDEHLM'
        
    reg1 = registers.find(assem.NowChar(True).upper())
    
    if reg1 < 0:
        errors.DoError('badoper', False)
        return
        
    if reg1 == 7:
        # timing is different if first operand is M
        dec.Asm.Timing = '7'
     
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    if assem.NowChar() == ' ':
        errors.DoError('missoper', False)
        return
    
    reg2 = registers.find(assem.NowChar(True).upper())
    
    if reg2 < 0:
        errors.DoError('badoper', False)
        return
        
    if reg1 == 7 and reg2 == 7:
        # mov m,m is not allowed, that his the hlt instruction
        errors.DoError('badoper', False)
        return
        
    if reg2 == 7:
        # timing is different if second operand is M
        dec.Asm.Timing = '8'
    
    NoMore()

    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (reg1 << 3) + reg2
    
    target.CodeByte(opcode)

#-----------------------------------------------------------------------------

def MviInst():

    global Asm
    
    if MissingOperand():
        return

    registers = 'ABCDEHLM'
        
    reg1 = registers.find(assem.NowChar(True).upper())
    
    if reg1 < 0:
        errors.DoError('badoper', False)
        return
        
    if reg1 == 7:
        # timing is different if first operand is M
        dec.Asm.Timing = '9'
     
    if not assem.MoreParameters():
        errors.DoError('missoper', False)
        return
    
    if assem.NowChar() == ' ':
        errors.DoError('missoper', False)
        return
    
    prefix = assem.NowChar()
    
    if prefix in '#/=\\':
        prefix = assem.NowChar(True)
    else:
        prefix = '#'
        
    value = assem.EvalExpr()
    
    if prefix == '#':
        byte = value[0]
    elif prefix == '/':
        byte = value[0] >> 8
    elif prefix == '=':
        byte = value[0] >> 16
    else:
        byte = value[0] >> 24
    
    NoMore()

    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (reg1 << 3)
    
    target.CodeByte(opcode)
    target.CodeByte(byte)

#-----------------------------------------------------------------------------

def Inherent():

    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])

#-----------------------------------------------------------------------------

def Immediate():

    global Asm

    if MissingOperand():
        return
    
    prefix = assem.NowChar()
    
    if prefix in '#/=\\':
        prefix = assem.NowChar(True)
    else:
        prefix = '#'
        
    value = assem.EvalExpr()
    
    if prefix == '#':
        byte = value[0]
    elif prefix == '/':
        byte = value[0] >> 8
    elif prefix == '=':
        byte = value[0] >> 16
    else:
        byte = value[0] >> 24
        
    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    target.CodeByte(byte)
    
    NoMore()

#-----------------------------------------------------------------------------

def IncDec():

    global Asm

    registers = "BCDEHL"

    if MissingOperand():
        return
    
    reg = registers.find(assem.NowChar(True).upper())
    
    if reg < 0:
        errors.DoError('badoper', False)
        return
    
    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (reg << 3)
        
    target.CodeByte(opcode)
    
    NoMore()

#-----------------------------------------------------------------------------

def Math():

    global Asm

    registers = "ABCDEHLM"
    exceptions = ('ADC','ADD','SUB','SBB','ORA','XRA')

    if dec.Asm.Mnemonic in exceptions:
        # These mnemonics may or may not have a register as operand
        # Depending on the 1972 or 1976 syntax
        if not dec.Asm.Optional:
            # No parameter was following within 10 spaces
            opcodes = ['82','83','91','99','B0','A8']
            ind = 0
            for t in exceptions:
                if t == dec.Asm.Mnemonic:
                    break
                ind = ind + 1
            opcode = opcodes[ind]
            target.CodeByte(int(opcode,16))
            return

    reg = registers.find(assem.NowChar(True).upper())
    
    if reg < 0:
        errors.DoError('badoper', False)
        return
    
    if reg == 7:
        # Timing is different for M
        dec.Asm.Timing = '8'
    
    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1] + reg
        
    target.CodeByte(opcode)
    
    NoMore()

#-----------------------------------------------------------------------------

def Jumps():

    global Asm

    if dec.Asm.Mnemonic == 'CPE':
        # This mnemonics may or may not have an address as operand
        # Depending on the 1972 or 1976 syntax
        if not dec.Asm.Optional:
            # No parameter was following within 10 spaces
            target.CodeByte(int('BC',16))
            dec.Asm.Timing = "5"
            return

    dest = assem.EvalExpr()

    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    target.CodeWord(dest[0])
    
    if dec.Asm.Pass == 2 and (dest[0] >> 14) != 0:
        errors.DoError('range', False)
    
    NoMore()

#-----------------------------------------------------------------------------

def InOut():

    global Asm
    
    if MissingOperand():
        return    
        
    dest = assem.EvalExpr()[0]

    if dec.Asm.Pass == 2:
        if dec.Asm.Mnemonic == "OUT":
            if dest < 8 or dest > 31:
                errors.DoError('range',False)
        else:
            if dest < 0 or dest > 7:
                errors.DoError('range',False)

    dest = dest & 31

    target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1] + dest * 2)
    
    NoMore()

#-----------------------------------------------------------------------------

def Restart():

    global Asm

    if MissingOperand():
        return

    value = assem.EvalExpr()
    
    if dec.Flags.ErrorInLine:
        # Save dummy bute to keep passes in sync
        target.CodeByte(0)
    else:
        # No errors were found
        vector = value[0]
        if value[1] and dec.Asm.Pass == 1:
            # Don't bother about range in case of forward referenced in pass 1
            vector = 0
        if vector > 8:
            if not vector in (16,24,32,40,48,56):
                errors.DoError('range', False)
                vector = 0
        if vector > 7:
            vector = vector >> 3
            
        target.CodeByte(dec.Asm.Instructions[dec.Asm.Mnemonic][1] + (vector << 3))

    NoMore()

#-----------------------------------------------------------------------------


if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    

