#------------------------------------------------------------------------------
#
#   cr80c48.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   Cross Overlay for the 80C48 family of processors
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target
import cr8048

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm

    cr8048.CrossInit()
    # This is the only difference between the 8048 and the 80C48
    dec.Asm.Instructions['HALT'] = (cr8048.Implied, int('01',16),'1')
    dec.Asm.Instructions['IDL']  = (cr8048.Implied, int('01',16),'1')

#------------------------------------------------------------------------------

def CrossDirective():

    return cr8048.CrossDirective()

#------------------------------------------------------------------------------

def CrossCleanUp():

    cr8048.CrossCleanUp()
    """
    No need to do any cleaning.
    """

    return    

#------------------------------------------------------------------------------

def CrossMnemonic():

    cr8048.CrossMnemonic()

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print

