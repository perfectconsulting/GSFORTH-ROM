#------------------------------------------------------------------------------
#
#   cr6804.py
#
#   Package module file for the SB-Assembler sbasm
#   See www.sbprojects.com for details
#
#   This cross overlay will handle the assembling of 6804
#
#------------------------------------------------------------------------------

import sys, os
import assem, dec, errors, target

crossversion = '3.00.00'
minversion = '3.00.00'

#------------------------------------------------------------------------------

def Help():

    print 'Tell a little story about this cross overlay'

#------------------------------------------------------------------------------

def CrossInit():

    global Asm, Flags
    
    assem.CheckVersions(crossversion, minversion)
    
    dec.Asm.Instructions = {
        'ASLA'  : (Inherent, int('FAFF',16), '4'),
        'CLRA'  : (Inherent, int('FBFF',16), ''),
        'CLRX'  : (Inherent, int('B08000',16), '4'),
        'CLRY'  : (Inherent, int('B08100',16), '4'),
        'CLX'   : (Inherent, int('B08000',16), '4'),
        'CLY'   : (Inherent, int('B08100',16), '4'),
        'COMA'  : (Inherent, int('B4',16), '4'),
        'DECA'  : (Inherent, int('FFFF',16), '4'),
        'DECX'  : (Inherent, int('B8',16), '4'),
        'DECY'  : (Inherent, int('B9',16), '4'),
        'DEX'   : (Inherent, int('B8',16), '4'),
        'DEY'   : (Inherent, int('B9',16), '4'),
        'INCA'  : (Inherent, int('FEFF',16), '4'),
        'INCX'  : (Inherent, int('A8',16), '4'),
        'INCY'  : (Inherent, int('A9',16), '4'),
        'INX'   : (Inherent, int('A8',16), '4'),
        'INY'   : (Inherent, int('A9',16), '4'),
        'NOP'   : (Inherent, int('20',16), '2'),
        'ROLA'  : (Inherent, int('B5',16), '4'),
        'RTI'   : (Inherent, int('B2',16), '2'),
        'RTS'   : (Inherent, int('B3',16), '2'),
        'TAX'   : (Inherent, int('BC',16), '1'),
        'TAY'   : (Inherent, int('BD',16), '1'),
        'TXA'   : (Inherent, int('AC',16), '1'),
        'TYA'   : (Inherent, int('AD',16), '1'),

        'BCC'   : (Branch, int('40',16), '2'),
        'BCS'   : (Branch, int('60',16), '2'),
        'BEQ'   : (Branch, int('20',16), '2'),
        'BNE'   : (Branch, int('00',16), '2'),
        'BHS'   : (Branch, int('40',16), '2'),
        'BLO'   : (Branch, int('60',16), '2'),
        
        'JMP'   : (Jumps, int('90',16), '4'),
        'JSR'   : (Jumps, int('80',16), '4'),

        'LDA'   : (Multiple, ('E8','AC','F8','E0'),('4','4','4','4')),
        'STA'   : (Multiple, ('00','BC','F9','E1'),('','4','4','4')),
        'ADD'   : (Multiple, ('EA','00','FA','E2'),('4','','4','4')),
        'SUB'   : (Multiple, ('EB','00','FB','E3'),('4','','4','4')),
        'CMP'   : (Multiple, ('EC','00','FC','E4'),('4','','4','4')),
        'AND'   : (Multiple, ('ED','00','FD','E5'),('4','','4','4')),
        'INC'   : (Multiple, ('00','A8','FE','E6'),('','4','4','4')),
        'DEC'   : (Multiple, ('00','B8','FF','E7'),('','4','4','4')),
        'LDXI'  : (Multiple, ('B080','00','00','00'),('4','','','')),
        'LDYI'  : (Multiple, ('B081','00','00','00'),('4','','','')),
        'LDX'   : (Multiple, ('B080','00','00','00'),('4','','','')),
        'LDY'   : (Multiple, ('B081','00','00','00'),('4','','','')),

        'MVI'   : (Move, int('B0',16), '4'),
        
        'BCLR'  : (Bits, 'D0', '4'),
        'BSET'  : (Bits, 'D8', '4'),
        'BRCLR' : (Bits, 'C0', '5'),
        'BRSET' : (Bits, 'C8', '5')

    }

    dec.Asm.Timing_Length = 1

    dec.Asm.Memory = 0              # Select code memory as default
    if dec.Asm.Pass == 1:
        sys.stdout.write('Loaded ' + dec.Cross.Name[2:] + ' overlay version ' + crossversion + dec.EOL)

    dec.Asm.Max_Address = (1 << 12)-1
    dec.Asm.PP_TA_Factor = 1
    dec.Flags.BigEndian = True

    return
    
#------------------------------------------------------------------------------

def CrossDirective():

    return False     # No extra directives

#------------------------------------------------------------------------------

def CrossCleanUp():

    return
    
#------------------------------------------------------------------------------

def CrossMnemonic():

    global Asm

    if dec.Asm.Mnemonic in dec.Asm.Instructions:
        func = dec.Asm.Instructions[dec.Asm.Mnemonic][0]
        func()
    else:
        errors.DoError('badopco', False)
    
#-----------------------------------------------------------------------------

def MissingOperand():

    """
    A useful function which raises an error if no operand is given.
    """

    if dec.Asm.Parse_Pointer == 0:
        errors.DoError('missoper', False)
        return True
    else:
        return False

#-----------------------------------------------------------------------------


def NoMore():

    """
    A useful function which tests if no more parameters are given when we
    don't expect any more at the end of the operand parsing.
    """

    if assem.MoreParameters():
        errors.DoWarning('extrign', False)

#-----------------------------------------------------------------------------

def Inherent():

    global Asm

    Code(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

#-----------------------------------------------------------------------------

def Branch():

    global Asm

    if MissingOperand():
        return
        
    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1]

    value = assem.EvalExpr()[0]

    offset = value - dec.Asm.BOL_Address - 1
    
    if dec.Asm.Pass == 2 and (offset < -16 or offset > 15):
        errors.DoError('range', False)
    
    offset = (offset & 31)
    
    target.CodeByte(opcode + offset)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

    NoMore()    

#-----------------------------------------------------------------------------

def Jumps():

    global Asm

    if MissingOperand():
        return

    opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1]
    value = assem.EvalExpr()[0]
    
    if dec.Asm.Pass == 2 and (value >> 12) != 0:
        errors.DoError('range', False)
    
    target.CodeByte(opcode + ((value >> 8) & 15))
    target.CodeByte(value)
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]

    NoMore()

#-----------------------------------------------------------------------------

def Multiple():

    global Asm

    if MissingOperand():
        return
    
    if assem.NowChar() in '#/=\\':
        # It is direct addressing mode
        prefix = assem.NowChar(True)
        opcode = dec.Asm.Instructions[dec.Asm.Mnemonic][1][0]
        if opcode == '00':
            errors.DoError('badoper', False)
            return
        
        value = assem.EvalExpr()[0]
        if prefix == '/':
            value = value >> 8
        elif prefix == '=':
            value = value >> 16
        elif prefix == '\\':
            value = value >> 24
        
        Code(int(opcode,16))
        target.CodeByte(value)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][0]

    elif assem.NowChar() == ',':
        # It is an indexed addressing mode
        
        assem.MoreParameters()
        
        index = assem.GetWord().upper()

        opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][3],16)
        
        if opcode == 0:
            errors.DoError('badoper',False)
            return
            
        if index == 'Y':
            opcode = opcode + 16
        elif index != 'X':
            errors.DoError('badoper',False)
            return
            
        Code(opcode)
        dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][3]
    
    else:
        # short or direct mode
        if assem.NowChar() in '<>':
            prefix = assem.NowChar(True)
        else:
            prefix = ''
        
        param = dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper()    

        if param in ('A ', 'X ', 'Y '):
            assem.NowChar(True)
            if param == 'A ':
                value = (255, False)
            elif param == 'X ':
                value = (128, False)
            else:
                value = (129, False)
        else:
            value = assem.EvalExpr()
        
        if dec.Asm.Instructions[dec.Asm.Mnemonic][1][1] == '00':
            # We've got no choise, short mode simply doesn't exit
            short = False
        elif prefix == '<':
            # Use short mode, even if it doesn't fit
            short = True
            if dec.Asm.Pass == 2 and (value[0] < 128 or value[0] > 131):
                errors.DoError('range', False)
        elif value[1] or prefix == '>':
            # forward referenced label used or prefix was >
            short = False
        elif value[0] < 128 or value[0] > 131:
            # Target is not within range, use long mode
            short = False
        else:
            # Phwe, we can use short mode at last
            short = True
        
        if short:
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][1],16)
            opcode = opcode + (value[0] & 3)
            Code(opcode)
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][1]
        else:
            opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1][2],16)
            if opcode == 0:
                errors.DoError('badoper', False)
                return
            Code(opcode)
            target.CodeByte(value[0])
            dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2][2]

        if dec.Asm.Pass == 2 and (value[0] < 0 or value[0] > 255):
            errors.DoError('range', False)
        
    NoMore()

#-----------------------------------------------------------------------------
def Move():

    global Asm
    
    if MissingOperand():
        return

    param = dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper()    

    if param in ('A,', 'X,', 'Y,'):
        assem.NowChar(True)
        if param == 'A,':
            dest = 255
        elif param == 'X,':
            dest = 128
        else:
            dest = 129
    else:
        dest = assem.EvalExpr()[0]

    if not assem.MoreParameters():
        # We expected more parameters        errors.DoError('missoper', False)
        return

    prefix = assem.NowChar(True)

    if not prefix in '#/=\\':
        errors.DoError('badoper', False)
        return
    
    value = assem.EvalExpr()[0]
    
    if prefix == '/':
        value = value >> 8
    elif prefix == '=':
        value = value >> 16
    elif prefix == '\\':
        value = value >> 24
    
    Code(dec.Asm.Instructions[dec.Asm.Mnemonic][1])
    target.CodeByte(dest)
    target.CodeByte(value)

    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]    
    
    if dest < 0 or dest > 255:
        errors.DoError('range', False)
    
    NoMore()

#-----------------------------------------------------------------------------

def Bits():

    """
    Handle Bit instructions
    Both bit set/clr as well as branch bit set/clr instructions are handled
    by this routine.
    """

    global Asm

    if MissingOperand():
        return
        
    bitno = assem.EvalExpr()[0]
    opcode = int(dec.Asm.Instructions[dec.Asm.Mnemonic][1],16) + ((bitno & 7))
    dec.Asm.Timing = dec.Asm.Instructions[dec.Asm.Mnemonic][2]
    
    if not assem.MoreParameters():
        # We expected more parameters        errors.DoError('missoper', False)        return

    param = dec.Asm.Parse_Line[dec.Asm.Parse_Pointer:dec.Asm.Parse_Pointer+2].upper()    

    if param in ('A,', 'X,', 'Y,', 'A ', 'X ', 'Y '):
        assem.NowChar(True)
        if param[0] == 'A':
            mem = 255
        elif param[0] == 'X':
            mem = 128
        else:
            mem = 129
    else:
        mem = assem.EvalExpr()[0]
    
    if dec.Asm.Mnemonic[1] == 'R':
        # It's a branch instruction
        if not assem.MoreParameters():
            # We expected more parameters            errors.DoError('missoper', False)            return
        dest = assem.EvalExpr()[0]
        offset = dest - dec.Asm.BOL_Address - 3
        
        target.CodeByte(opcode)
        target.CodeByte(mem)
        target.CodeByte(offset)
        if dec.Asm.Pass == 2 and (offset < -128 or offset > +127):
            errors.DoError('range',False)
    
    else:
        # It wasn't a branch instruction
        target.CodeByte(opcode)
        target.CodeByte(mem)
    
    if dec.Asm.Pass == 2:
        if (bitno < 0 or bitno > 7) or (mem < 0 or mem > 255):
            errors.DoError('range',False)
        
    NoMore()

#-----------------------------------------------------------------------------
def Code(opcode):

    """
    Write an opcode to the target file.
    If the opcode > 255 then a pre-byte must be saved first
    """

    if (opcode >> 16) != 0:
        target.CodeByte(opcode >> 16)
        target.CodeByte(opcode >> 8)    
    elif opcode > 255:
        target.CodeByte(opcode >> 8)
    target.CodeByte(opcode)

#-----------------------------------------------------------------------------

if __name__ == '__main__':
    print
    print "This is a python module, it's not a program."
    print "This module is part of the sbasm package."
    print "Run sbasm instead."
    print
    
